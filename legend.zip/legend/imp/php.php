HTTP/1.1 302 Found
Date: Mon, 10 Nov 2025 15:06:34 GMT
Content-Type: text/html; charset=utf-8
Content-Length: 0
Connection: keep-alive
x-sorting-hat-podid: 56
x-sorting-hat-shopid: 2442
x-frame-options: DENY
x-shopid: 2442
x-shardid: 56
content-language: en-US
location: https://example.myshopify.com/checkouts/cn/hWN58P5vnP5f3mFNyIRk9QBu/en-us?_r=AQABqjIc39Hwtua9FfBpjPwDhOdYU35Bi-Fp3JcFyyD5&cart_link_id=jllaeLKt
x-liquid-rendered-at: 2025-11-10T15:06:34.264035446Z
set-cookie: _shopify_essential=:AZpuTfZjAAEAL1Yy13YXSAipJmbektLSbSMtBbvm5JwRWkWTSxm6auZJTOJspUv8pyKO5T4kRi8UhTkXqHmpJKqCYioKLJPMca1jsxo5QyLfsDc6o5pILU8ax9dFYXUsrKm-Txh118QSYh-I2Kux6rHPZHX8TZ8Zm0Hz7trxMqq0KkZwWjzTvHBNVLSnUFlzm0IZZrdTx01PfNvCizkE_xCPk6UmJThZX7yl-VCxuvhvwjIiWjXz0V1MiDOGuQTvPK9m9v8y0gAFB8K197QTMZEZ9tbaecx4cN-tiaU0nADrBCXl6ob-kGev0WPaOAoSUtOE8frlKsKsgELDFy0is_713IwRgYBA8Ad5bHv1Z1fADLnY1Ol2mC8gWlVwqZaBmkdQKNladMdMJxmerEgWlLOcz8Vqws2fu3AAah0gdmHTbwZ5z1NdhbcfelpHMH_vxw5gmaa_ijWeOIm0zPh-NBdghaeAfL7PZqeQNQwqBXDzO7Pfiz7OZ35_xlJx74D9aT-4arAe3WG-TiI:; Max-Age=31536000; Path=/; HttpOnly; Secure; Priority=High; SameSite=Lax
set-cookie: _shopify_analytics=:AZpuTfZlAAEAVlZogaYcHvWh8CRKUd0X-OxkHkFP5VYGO0nW0vHhUQhNtHEOlqXQ8CmLZMErDzYrtS9K:; Max-Age=31536000; Path=/; HttpOnly; Secure; Priority=High; SameSite=Lax
set-cookie: _shopify_y=e3989244-ebd6-40f8-af55-8460f326c30a; domain=example.myshopify.com; path=/; expires=Tue, 10 Nov 2026 21:06:34 GMT; SameSite=Lax
set-cookie: _shopify_s=1e81b0d9-72cb-4324-a64c-5e7f94fdaf30; domain=example.myshopify.com; path=/; expires=Mon, 10 Nov 2025 15:36:34 GMT; SameSite=Lax
set-cookie: localization=US; path=/; expires=Tue, 10 Nov 2026 15:06:34 GMT; SameSite=Lax
set-cookie: cart=hWN58P5vnP5f3mFNyIRk9QBu%3Fkey%3Da6247335115a4c8c83fc096110fbd355; path=/; expires=Thu, 11 Dec 2025 15:06:34 GMT; SameSite=Lax
set-cookie: cart_currency=USD; path=/; expires=Thu, 11 Dec 2025 15:06:34 GMT; SameSite=Lax
x-request-id: c69358ba-18ed-46b4-afe9-ba454f73fddc-1762787193
server-timing: processing;dur=438, edge_cart;desc="count=1";dur=9.87, verdict_flag_enabled;desc="count=294";dur=23.568, _y;desc="cdff5796-486d-4660-80c2-182f28ede49a", _s;desc="3c38249a-3a20-4804-b469-3464b716cab0", _cmp;desc="3.AMPS_USCA___cl3qnDZUQ*6WrFhe33WaPA"
content-security-policy: frame-ancestors 'none'; upgrade-insecure-requests; report-uri /csp-report?source%5Baction%5D=permalink&source%5Bapp%5D=Shopify&source%5Bcontroller%5D=storefront_section%2Fcart&source%5Bsection%5D=storefront&source%5Buuid%5D=c69358ba-18ed-46b4-afe9-ba454f73fddc-1762787193; report-to shopify-csp
x-content-type-options: nosniff
x-download-options: noopen
x-permitted-cross-domain-policies: none
x-xss-protection: 1; mode=block
reporting-endpoints: shopify-csp="/csp-report?source%5Baction%5D=permalink&source%5Bapp%5D=Shopify&source%5Bcontroller%5D=storefront_section%2Fcart&source%5Bsection%5D=storefront&source%5Buuid%5D=c69358ba-18ed-46b4-afe9-ba454f73fddc-1762787193"
x-dc: gcp-us-east1,gcp-us-east1,gcp-us-east1
cf-cache-status: DYNAMIC
Report-To: {"endpoints":[{"url":"https:\/\/a.nel.cloudflare.com\/report\/v4?s=NmI%2F9%2BmyJZPNwAofZvLzA%2Fv4FUM6yuL6CNHGpCr%2BLJSyKZPVnmIo8iGpdDlMb9%2Fklky2xHXCoJMVpGgedlD8y5yHU6wD0%2BcQA7DQBoYKxRo1Tbg%2FRLKqhUHhharyh0dwmzccbSX%2F%2Fw%3D%3D"}],"group":"cf-nel","max_age":604800}
NEL: {"success_fraction":0.01,"report_to":"cf-nel","max_age":604800}
Server-Timing: cfRequestDuration;dur=549.999952
Server: cloudflare
CF-RAY: 99c6745a4f1ef7a9-LAX

HTTP/1.1 200 OK
Date: Mon, 10 Nov 2025 15:06:34 GMT
Content-Type: text/html; encoding=utf-8
Transfer-Encoding: chunked
Connection: keep-alive
Cache-Control: no-cache, no-store, must-revalidate
Content-Language: en-US
Strict-Transport-Security: max-age=7889238
Content-Security-Policy: block-all-mixed-content; upgrade-insecure-requests; frame-ancestors 'self' example.myshopify.com admin.shopify.com; report-to shopify-csp
Referrer-Policy: strict-origin-when-cross-origin
Reporting-Endpoints: shopify-csp="/csp-report?source%5Bapp%5D=checkout_web_worker"
Server-Timing: _cmp;desc=3.AMPS_USCA_f_f_cl3qnDZUQ*6WrFhe33WaPA
Timing-Allow-Origin: https://shop.app
X-Content-Type-Options: nosniff
X-Robots-Tag: none
X-ShardId: 56
X-ShopId: 2442
Report-To: {"endpoints":[{"url":"https:\/\/a.nel.cloudflare.com\/report\/v4?s=QkboJZx0K9J9CjAGAmt6PDjswaJBk7pVy3okjZ5DNqRSsRHvqJ55elaC8xnMPvQVxwZXGvn3p0u12dvPgH16Bz9IixmCAIGCB7Iju0XswCk2%2FXMVF4eGiM1NcTVt%2Fw6lLiWF%2B79CmQ%3D%3D"}],"group":"cf-nel","max_age":604800}
NEL: {"success_fraction":0.01,"report_to":"cf-nel","max_age":604800}
Vary: Accept-Encoding
Server-Timing: cfRequestDuration;dur=193.000078
X-XSS-Protection: 1; mode=block
X-Permitted-Cross-Domain-Policies: none
X-Download-Options: noopen
Server: cloudflare
CF-RAY: 99c6745eabf3f7a9-LAX
Content-Encoding: br
alt-svc: h3=":443"; ma=86400

<!DOCTYPE html><html lang="en-US" dir="ltr"><head><title>Checkout - example</title><meta charset="UTF-8"/><meta name="viewport" content="width=device-width, initial-scale=1.0, height=device-height"/><link rel="preconnect" href="https://cdn.shopify.com" crossorigin/><link rel="dns-prefetch" href="https://cdn.shopify.com" crossorigin/><link rel="preconnect" href="https://checkout.pci.shopifyinc.com" crossorigin/><link rel="dns-prefetch" href="https://checkout.pci.shopifyinc.com" crossorigin/><link rel="preconnect" href="https://checkout.shopify.com" crossorigin/><link rel="dns-prefetch" href="https://checkout.shopify.com" crossorigin/><link rel="preconnect" href="https://shop.app" crossorigin/><link rel="dns-prefetch" href="https://shop.app" crossorigin/><link rel="preconnect" href="https://server.shop.app" crossorigin/><link rel="dns-prefetch" href="https://server.shop.app" crossorigin/></head><body class="Loading">
<script>
(function() {
  try {
    // No need to use the value of syntaxCheck, as we only care if it is valid syntax
    const [syntaxCheck] = ((abc = 1) => [Promise.resolve(abc)])();
    window.checkoutMinimalBrowserSupport = typeof window.fetch === 'function';
  } catch (err) {}
})();
</script>
<script>
if (window.checkoutMinimalBrowserSupport !== true) {
  document.documentElement.innerHTML = "<div class=\"error-container\"><style>* {\n  box-sizing: border-box;\n  margin: 0;\n  padding: 0;\n}\n\nhtml {\n  font-family: \"Helvetica Neue\", Helvetica, Arial, sans-serif;\n  background: #F1F1F1;\n  font-size: 62.5%;\n  color: #303030;\n  min-height: 100%;\n}\n\nbody {\n  padding: 0;\n  margin: 0;\n  line-height: 2.7rem;\n}\n\nh1 {\n  font-size: 1.8rem;\n  font-weight: 400;\n  margin: 0 0 1.4rem 0;\n}\n\np {\n  font-size: 1.5rem;\n  margin: 0;\n}\n\n.error-container {\n  padding: 4rem 3.5rem;\n}\n\n@media all and (min-width:500px) {\n  .error-container {\n    padding: 7.5rem 10.5rem;\n    align-items: center;\n  }\n}</style><div><h1>It looks like your browser version isn't supported.</h1><p>Please update your browser to access the checkout and complete your purchase.</p></div></div>";
}
</script><style>
    
    :root {
      
    
    --x-skeleton-color-global-accent: hsl(214, 100%, 41%);
    --x-skeleton-color-global-background: hsl(0, 0%, 100%);
    --x-skeleton-color-global-backgroundSubdued: hsl(0, 0%, 96%);
    --x-skeleton-color-global-border: hsl(0, 0%, 87%);
    --x-skeleton-color-global-text: hsl(0, 0%, 0%);
    --x-skeleton-color-global-textContrast: hsl(0, 0%, 100%);
    --x-skeleton-color-global-textSubdued: hsl(0, 0%, 44%);
    --x-skeleton-color-global-textSubdued200: hsl(0, 0%, 90%);

    --x-skeleton-color-schemes-scheme2-base-background: hsl(0, 0%, 96%);
    --x-skeleton-color-schemes-scheme2-base-backgroundSubdued: hsl(0, 0%, 93%);
    --x-skeleton-color-schemes-scheme2-base-border: hsl(0, 0%, 84%);
    --x-skeleton-color-schemes-scheme2-base-text: hsl(0, 0%, 0%);
    --x-skeleton-color-schemes-scheme2-base-textContrast: hsl(0, 0%, 96%);
    --x-skeleton-color-schemes-scheme2-base-textSubdued: hsl(0, 0%, 40%);
    --x-skeleton-color-schemes-scheme2-base-textSubdued200: hsl(0, 0%, 80%);

    --x-skeleton-color-schemes-scheme6-base-background: hsl(214, 100%, 41%);
    --x-skeleton-color-schemes-scheme6-base-backgroundSubdued: hsl(214, 100%, 44%);
    --x-skeleton-color-schemes-scheme6-base-border: hsl(228, 33%, 66%);
    --x-skeleton-color-schemes-scheme6-base-text: hsl(0, 0%, 100%);
    --x-skeleton-color-schemes-scheme6-base-textContrast: hsl(0, 0%, 0%);
    --x-skeleton-color-schemes-scheme6-base-textSubdued: hsla(0, 0%, 100%, 0.66);
    --x-skeleton-color-schemes-scheme6-base-textSubdued200: hsla(0, 0%, 100%, 0.20);
  
    --x-skeleton-color-global-accent: #2a9dcc;
    





  

      --x-skeleton-typography-line-small: 1.2;
      --x-skeleton-typography-line-base: 1.5;
      --x-skeleton-line-quantity-size: 2.1rem;

      --x-skeleton-typography-size-small: 1.2rem;
      --x-skeleton-typography-size-default: 1.4rem;
      --x-skeleton-typography-size-medium: 1.6rem;
      --x-skeleton-typography-size-large: 1.9rem;
      --x-skeleton-typography-size-extra-large: 2.1rem;
      --x-skeleton-typography-size-extra-extra-large: 2.4rem;

      --x-skeleton-typography-primary-weight-bold: 400;
      --x-skeleton-typography-primary-fonts: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif, "Apple Color Emoji", "Segoe UI Emoji", "Segoe UI Symbol";

      --x-skeleton-typography-secondary-weight-bold: 600;
      --x-skeleton-typography-secondary-fonts: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif, "Apple Color Emoji", "Segoe UI Emoji", "Segoe UI Symbol";

      --x-skeleton-spacing-none: 0;
      --x-skeleton-spacing-small-100: 1.1rem;
      --x-skeleton-spacing-small-200: 0.9rem;
      --x-skeleton-spacing-small-300: 0.7rem;
      --x-skeleton-spacing-small-400: 0.5rem;
      --x-skeleton-spacing-small-500: 0.3rem;
      --x-skeleton-spacing-base: 1.4rem;
      --x-skeleton-spacing-large-100: 1.7rem;
      --x-skeleton-spacing-large-200: 2.1rem;
      --x-skeleton-spacing-large-300: 2.6rem;
      --x-skeleton-spacing-large-400: 3.2rem;
      --x-skeleton-spacing-large-500: 3.8rem;

      --x-skeleton-border-radius-none: 0;
      --x-skeleton-border-radius-base: 5px;
      --x-skeleton-border-radius-small: 2px;
      --x-skeleton-border-radius-large: 10px;
    }

    

    @keyframes SkeletonPulse {
      50% {
        opacity: 1;
      }
      75% {
        opacity: 0.5;
      }
      100% {
        opacity: 1;
      }
    }

    *,
    :after,
    :before {
      box-sizing: border-box;
    }

    body,
    html {
      height: 100%;
      margin: 0;
      width: 100%;
    }

    html {
      -webkit-text-size-adjust: 100%;
      text-size-adjust: 100%;
      font-size: 62.5%;
      font-family: var(--x-skeleton-typography-primary-fonts);
      line-height: var(--x-skeleton-typography-line-base);
    }

    body {
      -webkit-font-smoothing: subpixel-antialiased;
      overflow-wrap: break-word;
      overflow-x: hidden;
      overflow-y: scroll;
    }

    body.Loading {
      position: fixed;
    }

    /* TODO: need to take it out of the accessibility tree, too? */
    body.Loading > .LoadingShell {
      opacity: 1;
    }
  
    
    .BlockStack {
      display: grid;
    }

    .BlockStack--spacing-small500 {
      gap: var(--x-skeleton-spacing-small-500);
    }
    .BlockStack--spacing-small300 {
      gap: var(--x-skeleton-spacing-small-300);
    }
    .BlockStack--spacing-small100 {
      gap: var(--x-skeleton-spacing-small-100);
    }
    .BlockStack--spacing-base {
      gap: var(--x-skeleton-spacing-base);
    }
    .BlockStack--spacing-large100 {
      gap: var(--x-skeleton-spacing-large-100);
    }
    .BlockStack--spacing-large200 {
      gap: var(--x-skeleton-spacing-large-200);
    }
    .BlockStack--min-inline-size-full {
      flex: 1;
    }
    .BlockStack--inline-alignment-center {
      justify-items: center;
    }
    .BlockStack--inline-alignment-end {
      justify-items: end;
    }

    .LoadingHeaderHeading {
      margin: 0;
      font-size: var(--x-skeleton-typography-size-extra-large);
      font-weight: var(--x-skeleton-typography-secondary-weight-bold);
      font-family: var(--x-skeleton-typography-secondary-fonts);
      line-height: var(--x-skeleton-typography-line-small);
    }

    .LoadingHeaderHeading-uplift {
      font-size: var(--x-skeleton-typography-size-large);
    }

    .LoadingHeaderImage {
      display: block;
      max-width: 100%;
      height: auto;
    }

    .LoadingReferralTitle {
      font-size: var(--x-skeleton-typography-size-default);
      font-weight: var(--x-skeleton-typography-secondary-weight-bold);
      font-family: var(--x-skeleton-typography-secondary-fonts);
      line-height: var(--x-skeleton-typography-line-small);
    }

    .LoadingReferralTitleContainer {
      display: flex;
      flex-direction: column;
      justify-content: space-between;
      gap: 7px;
    }

    .InlineStack {
      display: flex;
      min-height: 100%;
      min-width: 100%;
    }
    .InlineStack--spacing-base {
      column-gap: var(--x-skeleton-spacing-base);
    }

    .InlineStack--spacing-small100 {
      column-gap: var(--x-skeleton-spacing-small-100);
    }

    .InlineStack--spacing-large200 {
      column-gap: var(--x-skeleton-spacing-large-200);
    }
    .InlineStack--inline-alignment-spaceBetween {
      justify-content: space-between;
    }
    .InlineStack--block-alignment-start {
      align-items: start;
    }
    .InlineStack--block-alignment-center {
      align-items: center;
    }

    .Divider {
      width: 100%;
      height: 1px;
      background-color: var(--x-skeleton-default-color-border);
    }

    .SkeletonButton {
      background-color: var(--x-skeleton-default-color-textSubdued200);
      border-radius: var(--x-skeleton-border-radius-base);
      animation: SkeletonPulse 4000ms ease infinite;
      width: 100%;
    }
    .SkeletonButtonInner {
      width: 100%;
      height: 4.8rem;
    }

    .SkeletonImage {
      background-color: var(--x-skeleton-default-color-textSubdued200);
      animation: SkeletonPulse 4000ms ease infinite;
      width: 100%;
    }
    .SkeletonImage--corner-radius-small {
      border-radius: var(--x-skeleton-border-radius-small);
    }
    .SkeletonImage--corner-radius-base {
      border-radius: var(--x-skeleton-border-radius-base);
    }
    .SkeletonImage--corner-radius-large {
      border-radius: var(--x-skeleton-border-radius-large);
    }
    .SkeletonImage--corner-radius-rounded {
      border-radius: 100%;
    }

    .SkeletonImageInner {
      width: 100%;
      height: 100%;
    }

    @supports (aspect-ratio: 1) {
      .SkeletonImage {
        aspect-ratio: var(--skeleton-thumbnail-aspect-ratio, 1);
      }
    }
    @supports not (aspect-ratio: 1) {
      .SkeletonImage::before {
        content: "";
        height: 0;
        display: block;
        padding-bottom: 100%;
        padding-bottom: calc(100% / var(--skeleton-thumbnail-aspect-ratio, 1));
      }
    }

    .SkeletonText {
      background-color: var(--x-skeleton-default-color-textSubdued200);
      border-radius: var(--x-skeleton-border-radius-base);
      animation: SkeletonPulse 4000ms ease infinite;
    }
    .SkeletonTextInner {
      display: inline-block;
    }
    .SkeletonTextInner--inline-size-small {
      width: 10ch;
    }
    .SkeletonTextInner--inline-size-base {
      width: 20ch;
    }
    .SkeletonTextInner--inline-size-large {
      width: 30ch;
    }
    .SkeletonTextInner--inline-size-full {
      width: 100%;
    }

    .Icon {
      fill: none;
      color: var(--x-skeleton-default-color-border);
      stroke: currentColor;
    }

    .Icon path {
      vector-effect: non-scaling-stroke;
      stroke-width: 1.4px;
    }

    .LoadingShellLineItems {
      display: grid;
      grid-auto-flow: row;
      align-items: stretch;
      gap: var(--x-skeleton-spacing-base);
    }

    .LoadingShellLine {
      display: grid;
      grid-template-columns: auto 1fr auto;
      gap: var(--x-skeleton-spacing-base);
      align-items: center;
      font-size: var(--x-type-size-base);
    }

    .LoadingShellLineImageWrapper {
      width: calc(6.4rem * var(--skeleton-thumbnail-inline-size, 1));
      height: calc(6.4rem / var(--skeleton-thumbnail-box-size, 1));
      position: relative;
      padding: 1px;
    }

    .LoadingShellImageWrapper--Small {
      width: 3.2rem;
      height: 3.2rem;
      position: relative;
    }

    .LoadingShellLineImage {
      width: 6.4rem;
      height: 6.4rem;
      display: flex;
      align-items: center;
      justify-content: center;
      object-fit: contain;
      background: var(--x-skeleton-default-color-backgroundSubdued);
    }
    .LoadingShellLineImage--border-full {
      border: 1px solid var(--x-skeleton-default-color-border);
    }
    .LoadingShellLineImage--corner-radius-small {
      border-radius: var(--x-skeleton-border-radius-small);
    }
    .LoadingShellLineImage--corner-radius-base {
      border-radius: var(--x-skeleton-border-radius-base);
    }
    .LoadingShellLineImage--corner-radius-large {
      border-radius: var(--x-skeleton-border-radius-large);
    }
    .LoadingShellLineImage--corner-radius-rounded {
      border-radius: 100%;
    }

    .LoadingShellLineImageIcon {
      width: 3.3rem;
      height: 3.3rem;
    }

    .LoadingShellLineQuantity {
      position: absolute;
      top: 0;
      right: 0;
      transform: translate(25%, -50%);
      display: inline-flex;
      align-items: center;
      justify-content: center;
      min-width: 2.2rem;
      min-height: 2.2rem;
      padding: 0 var(--x-skeleton-spacing-small-300);
      border-radius: 1.1rem;
      background: var(--x-skeleton-default-color-textSubdued);
      color: var(--x-skeleton-default-color-textContrast);
      font-size: var(--x-skeleton-typography-size-small);
      font-weight: 500;
    }

    .LoadingShellLineQuantity--corner-radius-none {
      border-radius: 0;
    }

    .LoadingShellLineContent {
      display: flex;
      flex-direction: column;
      align-self: baseline;
      min-height: calc(6.4rem / var(--skeleton-thumbnail-box-size, 1));
      justify-content: center;
    }

    .LoadingShellLinePrice {
      display: flex;
      align-self: baseline;
    }

    .Text {
      font-size: var(--x-skeleton-typography-size-default);
    }
    .Text--size-small {
      font-size: var(--x-skeleton-typography-size-small);
    }
    .Text--size-large {
      font-size: var(--x-skeleton-typography-size-large);
    }
    .Text--size-extraExtraLarge {
      font-size: var(--x-skeleton-typography-size-extra-extra-large);
    }
    .Text--appearance-subdued {
      color: var(--x-skeleton-default-color-textSubdued);
    }

    .SkeletonExpressCheckoutButtons {
      display: grid;
      gap: var(--x-skeleton-spacing-small-100);
      grid-template-columns: repeat(2, 1fr);
    }

    .SkeletonExpressCheckoutButtons > *:first-child {
      grid-column: 1 / -1;
    }

    .SkeletonExpressCheckout {
      margin-bottom: var(--x-skeleton-spacing-large-500);
    }

    .ExpressCheckoutDivider {
      display: flex;
      place-items: center;
      height: 21px;
      padding-top: calc(var(--x-skeleton-spacing-large-500) - 1px);
    }

    @media screen and (min-width: 1000px) {
      .SkeletonExpressCheckoutButtons {
        grid-template-columns: repeat(3, 1fr);
      }

      .SkeletonExpressCheckoutButtons > *:first-child {
        grid-column: auto;
      }

      .SkeletonExpressCheckoutButtons {
        grid-template-columns: repeat(3, 1fr);
      }

      .SkeletonExpressCheckoutButtons > *:first-child {
        grid-column: auto;
      }
    }

    .LoadingShellHeader--banner {
      background-position: 50% 50%;
      background-size: cover;
      background-image: var(--x-skeleton-banner-image);
      --x-skeleton-header-shop-name-color: #fff;
      --x-skeleton-cart-color: #fff;
    }


    .VisuallyHidden {
      border-width: 0;
      clip: rect(0, 0, 0, 0);
      height: 1px;
      margin: -1px;
      overflow: hidden;
      padding: 0;
      position: absolute;
      width: 1px;
      white-space: nowrap;
    }

    .FadeIn {
      opacity: 0;
      animation: 400ms FadeIn 150ms forwards;
    }

    @keyframes FadeIn {
      from {
        opacity: 0;
      }
      to {
        opacity: 1;
      }
    }
  
    
    
        .colorSchemeScheme1 {
          --x-skeleton-default-color-background: var(--x-skeleton-color-schemes-scheme1-base-background, var(--x-skeleton-color-global-background));
          --x-skeleton-default-color-accent: var(--x-skeleton-color-schemes-scheme1-base-accent, var(--x-skeleton-color-global-accent));
          --x-skeleton-default-color-backgroundSubdued: var(--x-skeleton-color-schemes-scheme1-base-backgroundSubdued, var(--x-skeleton-color-global-backgroundSubdued));
          --x-skeleton-default-color-border: var(--x-skeleton-color-schemes-scheme1-base-border, var(--x-skeleton-color-global-border));
          --x-skeleton-default-color-text: var(--x-skeleton-color-schemes-scheme1-base-text, var(--x-skeleton-color-global-text));
          --x-skeleton-default-color-textContrast: var(--x-skeleton-color-schemes-scheme2-base-textContrast, var(--x-skeleton-color-global-textContrast));
          --x-skeleton-default-color-textSubdued: var(--x-skeleton-color-schemes-scheme1-base-textSubdued, var(--x-skeleton-color-global-textSubdued));
          --x-skeleton-default-color-textSubdued200: var(--x-skeleton-color-schemes-scheme1-base-textSubdued200, var(--x-skeleton-color-global-textSubdued200));
        }
      
        .colorSchemeScheme2 {
          --x-skeleton-default-color-background: var(--x-skeleton-color-schemes-scheme2-base-background, var(--x-skeleton-color-global-background));
          --x-skeleton-default-color-accent: var(--x-skeleton-color-schemes-scheme2-base-accent, var(--x-skeleton-color-global-accent));
          --x-skeleton-default-color-backgroundSubdued: var(--x-skeleton-color-schemes-scheme2-base-backgroundSubdued, var(--x-skeleton-color-global-backgroundSubdued));
          --x-skeleton-default-color-border: var(--x-skeleton-color-schemes-scheme2-base-border, var(--x-skeleton-color-global-border));
          --x-skeleton-default-color-text: var(--x-skeleton-color-schemes-scheme2-base-text, var(--x-skeleton-color-global-text));
          --x-skeleton-default-color-textContrast: var(--x-skeleton-color-schemes-scheme2-base-textContrast, var(--x-skeleton-color-global-textContrast));
          --x-skeleton-default-color-textSubdued: var(--x-skeleton-color-schemes-scheme2-base-textSubdued, var(--x-skeleton-color-global-textSubdued));
          --x-skeleton-default-color-textSubdued200: var(--x-skeleton-color-schemes-scheme2-base-textSubdued200, var(--x-skeleton-color-global-textSubdued200));
        }
      
        .colorSchemeScheme3 {
          --x-skeleton-default-color-background: var(--x-skeleton-color-schemes-scheme3-base-background, var(--x-skeleton-color-global-background));
          --x-skeleton-default-color-accent: var(--x-skeleton-color-schemes-scheme3-base-accent, var(--x-skeleton-color-global-accent));
          --x-skeleton-default-color-backgroundSubdued: var(--x-skeleton-color-schemes-scheme3-base-backgroundSubdued, var(--x-skeleton-color-global-backgroundSubdued));
          --x-skeleton-default-color-border: var(--x-skeleton-color-schemes-scheme3-base-border, var(--x-skeleton-color-global-border));
          --x-skeleton-default-color-text: var(--x-skeleton-color-schemes-scheme3-base-text, var(--x-skeleton-color-global-text));
          --x-skeleton-default-color-textContrast: var(--x-skeleton-color-schemes-scheme2-base-textContrast, var(--x-skeleton-color-global-textContrast));
          --x-skeleton-default-color-textSubdued: var(--x-skeleton-color-schemes-scheme3-base-textSubdued, var(--x-skeleton-color-global-textSubdued));
          --x-skeleton-default-color-textSubdued200: var(--x-skeleton-color-schemes-scheme3-base-textSubdued200, var(--x-skeleton-color-global-textSubdued200));
        }
      
        .colorSchemeScheme4 {
          --x-skeleton-default-color-background: var(--x-skeleton-color-schemes-scheme4-base-background, var(--x-skeleton-color-global-background));
          --x-skeleton-default-color-accent: var(--x-skeleton-color-schemes-scheme4-base-accent, var(--x-skeleton-color-global-accent));
          --x-skeleton-default-color-backgroundSubdued: var(--x-skeleton-color-schemes-scheme4-base-backgroundSubdued, var(--x-skeleton-color-global-backgroundSubdued));
          --x-skeleton-default-color-border: var(--x-skeleton-color-schemes-scheme4-base-border, var(--x-skeleton-color-global-border));
          --x-skeleton-default-color-text: var(--x-skeleton-color-schemes-scheme4-base-text, var(--x-skeleton-color-global-text));
          --x-skeleton-default-color-textContrast: var(--x-skeleton-color-schemes-scheme2-base-textContrast, var(--x-skeleton-color-global-textContrast));
          --x-skeleton-default-color-textSubdued: var(--x-skeleton-color-schemes-scheme4-base-textSubdued, var(--x-skeleton-color-global-textSubdued));
          --x-skeleton-default-color-textSubdued200: var(--x-skeleton-color-schemes-scheme4-base-textSubdued200, var(--x-skeleton-color-global-textSubdued200));
        }
      
        .colorSchemeScheme5 {
          --x-skeleton-default-color-background: var(--x-skeleton-color-schemes-scheme5-base-background, var(--x-skeleton-color-global-background));
          --x-skeleton-default-color-accent: var(--x-skeleton-color-schemes-scheme5-base-accent, var(--x-skeleton-color-global-accent));
          --x-skeleton-default-color-backgroundSubdued: var(--x-skeleton-color-schemes-scheme5-base-backgroundSubdued, var(--x-skeleton-color-global-backgroundSubdued));
          --x-skeleton-default-color-border: var(--x-skeleton-color-schemes-scheme5-base-border, var(--x-skeleton-color-global-border));
          --x-skeleton-default-color-text: var(--x-skeleton-color-schemes-scheme5-base-text, var(--x-skeleton-color-global-text));
          --x-skeleton-default-color-textContrast: var(--x-skeleton-color-schemes-scheme2-base-textContrast, var(--x-skeleton-color-global-textContrast));
          --x-skeleton-default-color-textSubdued: var(--x-skeleton-color-schemes-scheme5-base-textSubdued, var(--x-skeleton-color-global-textSubdued));
          --x-skeleton-default-color-textSubdued200: var(--x-skeleton-color-schemes-scheme5-base-textSubdued200, var(--x-skeleton-color-global-textSubdued200));
        }
      
        .colorSchemeScheme6 {
          --x-skeleton-default-color-background: var(--x-skeleton-color-schemes-scheme6-base-background, var(--x-skeleton-color-global-background));
          --x-skeleton-default-color-accent: var(--x-skeleton-color-schemes-scheme6-base-accent, var(--x-skeleton-color-global-accent));
          --x-skeleton-default-color-backgroundSubdued: var(--x-skeleton-color-schemes-scheme6-base-backgroundSubdued, var(--x-skeleton-color-global-backgroundSubdued));
          --x-skeleton-default-color-border: var(--x-skeleton-color-schemes-scheme6-base-border, var(--x-skeleton-color-global-border));
          --x-skeleton-default-color-text: var(--x-skeleton-color-schemes-scheme6-base-text, var(--x-skeleton-color-global-text));
          --x-skeleton-default-color-textContrast: var(--x-skeleton-color-schemes-scheme2-base-textContrast, var(--x-skeleton-color-global-textContrast));
          --x-skeleton-default-color-textSubdued: var(--x-skeleton-color-schemes-scheme6-base-textSubdued, var(--x-skeleton-color-global-textSubdued));
          --x-skeleton-default-color-textSubdued200: var(--x-skeleton-color-schemes-scheme6-base-textSubdued200, var(--x-skeleton-color-global-textSubdued200));
        }
      

    .backgroundColorBase {
      background-color: var(--x-skeleton-default-color-background);
      color: var(--x-skeleton-default-color-text);
    }

    .backgroundColorSubdued {
      background-color: var(--x-skeleton-default-color-backgroundSubdued);
      color: var(--x-skeleton-default-color-text);
    }
  

    .LoadingShell {
      position: absolute;
      top: 0;
      right: 0;
      bottom: 0;
      left: 0;
      z-index: 100000;
      pointer-events: none;
      opacity: 0;
      transition: opacity 0.2s ease;
      will-change: opacity;

      min-height: 100dvh;
      display: grid;
      grid-template-rows: auto auto 1fr;
      grid-template-areas:
        'header'
        'disclosure'
        'shell-content';
      background-image: var(--x-skeleton-shell-background-image);

      --x-skeleton-shell-inline-size: 58rem;
      --x-skeleton-shell-background-image: var(--skeleton-config-shell-background-image);

      --x-skeleton-shell-header-inline-size: var(--x-skeleton-shell-inline-size);

      --x-skeleton-shell-header-padding: var(--skeleton-config-header-padding, var(--x-skeleton-spacing-large-200));

      --x-skeleton-shell-header-background-image: var(--skeleton-config-header-background-image);

      --x-skeleton-shell-disclosure-inline-size: var(--x-skeleton-shell-inline-size);
      --x-skeleton-shell-disclosure-padding: var(--x-skeleton-spacing-large-100) var(--x-skeleton-spacing-large-200);
      --x-skeleton-shell-disclosure-display: block;

      --x-skeleton-shell-main-inline-size: var(--x-skeleton-shell-inline-size);
      --x-skeleton-shell-main-justify-content: center;
      --x-skeleton-shell-main-padding: var(--x-skeleton-spacing-large-200);
      --x-skeleton-shell-main-border: none;

      --x-skeleton-shell-order-summary-display: none;
      --x-skeleton-shell-order-summary-background-image: var(--skeleton-config-order-summary-background-image);

      --x-skeleton-box-shadow-extra-small:
        0 1px 1.75px 0 rgba(0, 0, 0, 0.12),
        0 -0.5px 1.5px 0 rgba(0, 0, 0, 0.09),
        0 3px 4px 0 rgba(0, 0, 0, 0.03);

      --x-skeleton-box-shadow-small:
        0 1px 2px -0.5px rgba(0, 0, 0, 0.05),
        0 2px 4px -1px rgba(0, 0, 0, 0.08),
        0 3px 6px -1.5px rgba(0, 0, 0, 0.08),
        0 -0.5px 1.5px 0 rgba(0, 0, 0, 0.09);

      @media screen and (min-width: 1000px) {
        --x-skeleton-shell-main-inline-size: 58rem;
        --x-skeleton-shell-order-summary-inline-size: 48rem;
        --x-skeleton-shell-section-columns-offset: 5rem;

        --x-skeleton-shell-content-display: grid;
        --x-skeleton-shell-content-template-areas: 'main order-summary';

        --x-skeleton-shell-content-template-columns: minmax(
            min-content, calc(50% + var(--x-skeleton-shell-section-columns-offset))
          )
          1fr;

        --x-skeleton-shell-inline-size: 106rem;
        --x-skeleton-shell-header-padding: var(--skeleton-config-header-padding, 0);

        --x-skeleton-shell-disclosure-display: none;

        --x-skeleton-shell-main-justify-content: flex-end;
        --x-skeleton-shell-main-padding: var(--x-skeleton-spacing-large-500);
        --x-skeleton-shell-main-border: 1px solid var(--x-skeleton-default-color-border);

        --x-skeleton-shell-order-summary-display: block;
        --x-skeleton-shell-order-summary-padding: var(--x-skeleton-spacing-large-500);
      }
    }

    @supports (width: min(0px, 100px)) {
      /* mobile header padding is clamped at large-200 like Sections */
      @media screen and (max-width: 999px) {
        .LoadingShell {
          --x-skeleton-shell-header-padding: min(
            var(--skeleton-config-header-padding, var(--x-skeleton-spacing-large-200)),
            var(--x-skeleton-spacing-large-200)
          );
        }
      }
    }

    @media screen and (min-width: 1000px) {
      .LoadingShell.LoadingShellConfig-Header-positionStart {
        --x-skeleton-shell-header-padding: var(--skeleton-config-header-padding, var(--x-skeleton-spacing-large-200) var(--x-skeleton-spacing-large-500));
      }
    }

    .LoadingShellHeader {
      grid-area: header;
    }

    .LoadingShellHeaderContent {
      padding: var(--x-skeleton-shell-header-padding);
      width: 100%;
      max-width: var(--x-skeleton-shell-header-inline-size);
    }

    @media screen and (min-width: 1000px) {
      .LoadingShell:not(.LoadingShellConfig-Header-positionStart) .LoadingShellHeader-positionStart {
        display: none;
      }
    }

    @media screen and (max-width: 999px) {
      .LoadingShellConfig-Header-positionInline .LoadingShellHeader-positionInline,
      .LoadingShellConfig-Header-positionInlineSecondary .LoadingShellHeader-positionInlineSecondary {
        display: none;
      }

      .LoadingShellConfig-Header-positionInlineSecondary .LoadingShellHeader-positionStart {
        background-image: var(
          --x-skeleton-shell-header-background-image,
          var(--x-skeleton-shell-order-summary-background-image)
        );
      }
    }

    .LoadingShellHeader-positionStart {
      display: flex;
      justify-content: center;
      border-bottom: 1px solid var(--x-skeleton-default-color-border);
      background-image: var(--x-skeleton-shell-header-background-image);
      background-position: 50% 50%;
      background-size: cover;
    }

    .LoadingShellHeader-uplift {
      z-index: 1;
      border-bottom: none;
      box-shadow: var(--x-skeleton-box-shadow-small);
    }

    .LoadingShellHeader-positionStart.LoadingShellHeader-hasBackgroundImage {
      --header-shop-name-color: #ffffff;
      --x-skeleton-default-color-accent: #ffffff;
    }

    .LoadingShellBuyerJourneyContent {
      width: 100%;
      width: var(--x-skeleton-shell-buyer-journey-inline-size);
      padding: var(--x-skeleton-shell-buyer-journey-padding);
    }

    .LoadingShellDisclosure {
      grid-area: disclosure;
      display: var(--x-skeleton-shell-disclosure-display);
      border-bottom: 1px solid var(--x-skeleton-default-color-border);
    }

    .LoadingShellDisclosure-uplift {
      border-bottom: none;
      box-shadow: var(--x-skeleton-box-shadow-extra-small);
    }

    .LoadingShellDisclosureButton {
      display: flex;
      justify-content: center;
      width: 100%;
    }

    .LoadingShellDisclosureButton {
      text-align: start;
      background: var(--x-skeleton-default-color-backgroundSubdued);
      color: var(--x-skeleton-default-color-accent);
      position: relative;
      z-index: 2;
    }

    .LoadingShellConfig-Shell-hasBackgroundImage .LoadingShellDisclosureButton {
      background: transparent;
      color: inherit;
    }

    .LoadingShellDisclosureButtonContent {
      display: grid;
      grid-template-columns: 1fr auto;
      gap: var(--x-skeleton-spacing-small-200);
      align-content: center;
      align-items: center;
    }

    .LoadingShellDisclosureButtonContent {
      padding: var(--x-skeleton-shell-disclosure-padding);
      width: 100%;
      max-width: var(--x-skeleton-shell-disclosure-inline-size);
    }

    .LoadingShellContent {
      grid-area: shell-content;
      display: var(--x-skeleton-shell-content-display);
      grid-template-areas: var(--x-skeleton-shell-content-template-areas);
      grid-template-columns: var(--x-skeleton-shell-content-template-columns);
    }

    .LoadingShellMain {
      grid-area: main;
      display: flex;
      justify-content: var(--x-skeleton-shell-main-justify-content);
      height: 100%;
    }

    .LoadingShellMain .LoadingShellMainContent {
      height: 100%;
      width: 100%;
      max-width: var(--x-skeleton-shell-main-inline-size);
      padding: var(--x-skeleton-shell-main-padding);
      border-inline-end: var(--x-skeleton-shell-main-border);

      display: grid;
      grid-template-rows: auto auto 1fr;
      grid-template-columns: 1fr;
      grid-template-areas:
        'header'
        'buyer-journey'
        'main-content-primary';
    }

    .LoadingShellMainContentPrimary {
      grid-area: main-content-primary;
    }


    .LoadingShellMainContent .LoadingShellHeader {
      margin-bottom: var(--x-skeleton-spacing-large-100);
    }
    .LoadingShellMainContent .LoadingShellBuyerJourney {
      margin-bottom: var(--x-skeleton-spacing-large-300);
    }

    .LoadingShellOrderSummary {
      display: var(--x-skeleton-shell-order-summary-display);
      grid-area: order-summary;
    }

    .LoadingShellOrderSummary .LoadingShellOrderSummaryContent {
      position: sticky;
      padding: var(--x-skeleton-shell-order-summary-padding);
      width: 100%;
      max-width: var(--x-skeleton-shell-order-summary-inline-size);
      top: 0;
      right: auto;
      bottom: 0;
      left: auto;
    }

    .LoadingShellOrderSummaryContent .LoadingShellHeader {
      margin-bottom: var(--x-skeleton-spacing-large-200);
    }

    /* Header */
    .LoadingHeader {
      display: flex;
      width: 100%;
    }

    .LoadingHeader-alignmentStart {
      justify-content: flex-start;
    }

    .LoadingHeader-alignmentCenter {
      justify-content: center;
    }

    .LoadingHeader-alignmentEnd {
      justify-content: flex-end;
    }

    .LoadingShell-variantOneStepCheckout .LoadingHeader-alignmentCenter .LoadingHeaderHeading {
      display: flex;
      justify-content: center;
    }
    .LoadingShell-variantOneStepCheckout .LoadingHeader-alignmentEnd .LoadingHeaderHeading {
      display: flex;
      justify-content: flex-end;
    }
  </style><div class="LoadingShell LoadingShellConfig-Header-positionStart LoadingShell-variantOneStepCheckout colorSchemeScheme1 backgroundColorBase"><header class="LoadingShellHeader LoadingShellHeader-containerFill LoadingShellHeader-positionStart"><div class="LoadingShellHeaderContent"><div class="LoadingHeader LoadingHeader-alignmentStart"><h1 class="LoadingHeaderHeading">example</h1></div></div></header><div class="LoadingShellDisclosure ShopPay"><div class="LoadingShellDisclosureButton LoadingShellDisclosureButton-containerFill"><span class="LoadingShellDisclosureButtonContent FadeIn"><span class="Text Text--size-small"><span class="SkeletonText"><span class="SkeletonTextInner SkeletonTextInner--inline-size-base"><span></span></span></span></span><span><span class="Text Text--size-large"><span class="SkeletonText"><span class="SkeletonTextInner SkeletonTextInner--inline-size-small"><span></span></span></span></span></span></span></div></div><div class="LoadingShellContent LoadingShellContent-containerFill"><div class="LoadingShellMain"><div class="LoadingShellMainContent"><main class="LoadingShellMainContentPrimary FadeIn"><div class="SkeletonExpressCheckout"><div class="BlockStack BlockStack--spacing-base"><div class="BlockStack BlockStack--inline-alignment-center BlockStack--spacing-base"><span class="Text"><span class="SkeletonText"><span class="SkeletonTextInner SkeletonTextInner--inline-size-base"><span></span></span></span></span></div><div class="SkeletonExpressCheckoutButtons"><div class="SkeletonButton"><div class="SkeletonButtonInner"></div></div><div class="SkeletonButton"><div class="SkeletonButtonInner"></div></div><div class="SkeletonButton"><div class="SkeletonButtonInner"></div></div></div></div><div class="ExpressCheckoutDivider"><div class="Divider"></div></div></div><div class="BlockStack BlockStack--spacing-large200"><div class="BlockStack BlockStack--spacing-base"><span class="Text Text--size-large"><span class="SkeletonText"><span class="SkeletonTextInner SkeletonTextInner--inline-size-small"><span></span></span></span></span><div class="BlockStack BlockStack--spacing-small300"><span class="Text Text--size-small"><span class="SkeletonText"><span class="SkeletonTextInner SkeletonTextInner--inline-size-full"><span></span></span></span></span><span class="Text Text--size-small"><span class="SkeletonText"><span class="SkeletonTextInner SkeletonTextInner--inline-size-full"><span></span></span></span></span></div></div><div class="Divider"></div><div class="BlockStack BlockStack--spacing-base"><span class="Text Text--size-large"><span class="SkeletonText"><span class="SkeletonTextInner SkeletonTextInner--inline-size-small"><span></span></span></span></span><div class="BlockStack BlockStack--spacing-small300"><span class="Text Text--size-small"><span class="SkeletonText"><span class="SkeletonTextInner SkeletonTextInner--inline-size-full"><span></span></span></span></span><span class="Text Text--size-small"><span class="SkeletonText"><span class="SkeletonTextInner SkeletonTextInner--inline-size-full"><span></span></span></span></span></div></div></div></main></div></div><div class="LoadingShellOrderSummary colorSchemeScheme2 backgroundColorBase"><div class="LoadingShellOrderSummaryContent"><aside class="LoadingShellOrderSummaryContentPrimary FadeIn"><div class="BlockStack BlockStack--spacing-large200"><h2 class="VisuallyHidden"></h2><div class="LoadingShellLineItems"><div class="LoadingShellLine"><div class="LoadingShellLineImageWrapper"><div class="SkeletonImage SkeletonImage--corner-radius-base"><span class="SkeletonImageInner"></span></div></div><div class="LoadingShellLineContent"><div class="BlockStack BlockStack--spacing-small500"><span class="Text Text--size-small"><span class="SkeletonText"><span class="SkeletonTextInner SkeletonTextInner--inline-size-base"><span></span></span></span></span><span class="Text Text--size-small"><span class="SkeletonText"><span class="SkeletonTextInner SkeletonTextInner--inline-size-small"><span></span></span></span></span></div></div><div class="LoadingShellLinePrice"><span class="Text Text--size-small"><span class="SkeletonText"><span class="SkeletonTextInner SkeletonTextInner--inline-size-small"><span></span></span></span></span></div></div></div><div class="BlockStack BlockStack--spacing-small100"><div class="InlineStack InlineStack--spacing-base InlineStack--block-alignment-start InlineStack--inline-alignment-spaceBetween"><span class="Text Text--size-small"><span class="SkeletonText"><span class="SkeletonTextInner SkeletonTextInner--inline-size-small"><span></span></span></span></span><span class="Text Text--size-small"><span class="SkeletonText"><span class="SkeletonTextInner SkeletonTextInner--inline-size-small"><span></span></span></span></span></div><div class="InlineStack InlineStack--spacing-base InlineStack--block-alignment-start InlineStack--inline-alignment-spaceBetween"><span class="Text Text--size-small"><span class="SkeletonText"><span class="SkeletonTextInner SkeletonTextInner--inline-size-small"><span></span></span></span></span><span class="Text Text--size-small"><span class="SkeletonText"><span class="SkeletonTextInner SkeletonTextInner--inline-size-small"><span></span></span></span></span></div><div class="InlineStack InlineStack--spacing-base InlineStack--block-alignment-start InlineStack--inline-alignment-spaceBetween"><span class="Text Text--size-small"><span class="SkeletonText"><span class="SkeletonTextInner SkeletonTextInner--inline-size-small"><span></span></span></span></span><span class="Text Text--size-small"><span class="SkeletonText"><span class="SkeletonTextInner SkeletonTextInner--inline-size-small"><span></span></span></span></span></div><div class="InlineStack InlineStack--spacing-base InlineStack--block-alignment-start InlineStack--inline-alignment-spaceBetween"><span class="Text Text--size-large"><span class="SkeletonText"><span class="SkeletonTextInner SkeletonTextInner--inline-size-small"><span></span></span></span></span><span class="Text Text--size-large"><span class="SkeletonText"><span class="SkeletonTextInner SkeletonTextInner--inline-size-small"><span></span></span></span></span></div></div></div></aside></div></div></div></div><script type="systemjs-importmap">{
  "integrity": {
    "/cdn/shopifycloud/checkout-web/assets/c1/shopjs-locales-legacy.B3N1GyTh.js": "sha384-71YmlcoTQM8GrDnXtLCjLUQqoq5sDhWS24v+Rb6M8/QPURIEhRu67DreoRvabPX9",
    "/cdn/shopifycloud/checkout-web/assets/c1/component-StreetNameField-legacy.kEQmdX2A.js": "sha384-5VZN5dkoY245JbQbvB9Mtp0iYL1m6+82KEECrwzMJMrmZY5zaIHSWmyiFydfyGxR",
    "/cdn/shopifycloud/checkout-web/assets/c1/app-legacy.aMtlhewy.js": "sha384-2WIGmU84o1ThrfTzoP8GG2kJrFJ0Mx0N550Z7bvlPwsf1OB0vQLA88t/35tQ3M42",
    "/cdn/shopifycloud/checkout-web/assets/c1/component-SubscriptionGroupLine-legacy.DV0dfYmQ.js": "sha384-2jXKZFR1JbrMA8352jWe9pgIZzCOMhdAnFddoB985QrpEC58GI+lyL5fv0vzC/Zs",
    "/cdn/shopifycloud/checkout-web/assets/c1/ShipmentLine-legacy.DQ-ihRLn.js": "sha384-7B7oXeBtEuIc+MolPuuBDiRXaY7dYapFHg5/AoIJFTY6L44enZnUmX4sgQ0sOIfr",
    "/cdn/shopifycloud/checkout-web/assets/c1/StackedMerchandisePreview-legacy.1itpoSxr.js": "sha384-7K4XkyOJEfixvll/9EgxP143DhJThy1iUCWMKJm7nhW0EsjuWYjwbp23Ul1vLon8",
    "/cdn/shopifycloud/checkout-web/assets/c1/MerchandiseModal-legacy.Dyrxm_zU.js": "sha384-KDiAVC4SRONBjUVHutqxxxvs4UY6OipbmwAwJ2zs0NSmR8EE3Q7HkNjJHEu12uTZ",
    "/cdn/shopifycloud/checkout-web/assets/c1/page-Review-legacy.CZGw_q7o.js": "sha384-mA43Tlo/BIzY3JGcusuF9qu6CxMifrjcgNRTs5tIfyk9ptB6/Eho0x+v+kuKVZ8q",
    "/cdn/shopifycloud/checkout-web/assets/c1/SeparatePaymentsNotice-legacy.DHPrwbG3.js": "sha384-i6q47fgAmKwU4E6gz86j6MsN1uOUL8mZSZJrp2r0i34yiZnVNUVH15/mv2AExdXc",
    "/cdn/shopifycloud/checkout-web/assets/c1/PaymentButtons-legacy.CdYmaiip.js": "sha384-UVXmi5JuffBmo+3H1+XJMAi49z5OLxrKcdeaxRsD5g3oNRl2VuIKQfzlPo3ixlC2",
    "/cdn/shopifycloud/checkout-web/assets/c1/component-PhoneNumberFormatter-legacy.DMdVHjRj.js": "sha384-1cF7TNM801bQLAhYeseHKKbVhwaUWKTeU4dTPl7UlPooWOaX6ntqwmhV7EaQSVpi",
    "/cdn/shopifycloud/checkout-web/assets/c1/getCountryCallingCode-legacy.CPwPkxys.js": "sha384-p1DB0pSOcoLyVzI/CEYn8CeAGNoQ6EVCwjInAn+hXxfBCDp3YO+db8P1kb3RqAVK",
    "/cdn/shopifycloud/checkout-web/assets/c1/component-Captcha-legacy.4OGjg-oS.js": "sha384-T41Lg5neF+v7vfeao2dYQR2xo8Y4Y4cu3PwLkvNp5lstN/CPJKvS3rA/Xa5g1ijC",
    "/cdn/shopifycloud/checkout-web/assets/c1/ShopPayCaptcha-legacy.DXczrdI8.js": "sha384-QAdHtzLHU0LtCMtW1o+MPIakSabTmHAzqNvDbTRzebu1BKWz1hNYvrUNBOTHa01b",
    "/cdn/shopifycloud/checkout-web/assets/c1/component-ShippingGroupsSummary-legacy.CJ3Qblad.js": "sha384-W4sNShi+kKQiFXbojU8RMCSTn5ihNkPyqfAtSj5kO7t+HTdz7cbfr9r+bhnvMnEL",
    "/cdn/shopifycloud/checkout-web/assets/c1/component-PayPalExpressPaymentMethod-legacy.Dh0iDYvr.js": "sha384-w4TyRd7tWR1m4vDpjGWNUa3FeOfslRfBXO4rinUib/wF7XV1jzjkccPFwaGvbHvW",
    "/cdn/shopifycloud/checkout-web/assets/c1/page-StockProblemsModal-legacy.BCRS950_.js": "sha384-8s+uuSMf2UjtWqjPAmxFWug0p5t6MXmCa0M8YHX9HUxebCbdMdjIHDENCY/748L9",
    "/cdn/shopifycloud/checkout-web/assets/c1/StockProblemsLineItemList-legacy.CACz654j.js": "sha384-43OL2TlL5DK6M85iKaTf1k1wiUrA3BPsV+Q/YWhGZqPHu1LU9LN6jr+qLWTABhJY",
    "/cdn/shopifycloud/checkout-web/assets/c1/EditorBridge-legacy.BagfBTkh.js": "sha384-e/bvnyAOA2/2jjwmKwvhVXny5FBl5gx97LggiK3OMqryxv+MsrkHsLbjQwnZDUvZ",
    "/cdn/shopifycloud/checkout-web/assets/c1/VaultedDeliveryAddress-legacy.BpN3ZUZg.js": "sha384-kO9MjCK0r0oMEnfb0sScbJUWJ0v/UjH7RMh/QDTsZeE+qbSXJOnWsrxdFtH2/Zj1",
    "/cdn/shopifycloud/checkout-web/assets/c1/page-Processing-legacy.CwSKK_mI.js": "sha384-BIe/A5dK8xeguBHBFndCaE7ncKQz6P4FvVtU4a9rFC+BJsZogZEjDP3D0QPsjS3M",
    "/cdn/shopifycloud/checkout-web/assets/c1/RemoteCheckoutLogo-legacy.Dqv6Mt31.js": "sha384-5Vki6jhKHgn2qvWsGwROxWUVTanN/5wBDo1MHm/NU+mIoC//O6uFU6Y1IXjbwqSx",
    "/cdn/shopifycloud/checkout-web/assets/c1/page-RemoteMerchandiseOnly-legacy.go1_iMWs.js": "sha384-q0VFya5XdpHTKg5eXu8cwhuxK8xtHOVutzjgKoa6YkvYyRCF4oDBdejGq7WUkPtK",
    "/cdn/shopifycloud/checkout-web/assets/c1/component-Throttle-legacy.Cp_a6JXu.js": "sha384-HkQaXsUifJAQGFnWsJWn9C874G8Hsf/FezAE+je8+zo3R2LTa+y1Cvo+088GYBDX",
    "/cdn/shopifycloud/checkout-web/assets/c1/component-ProfilePreviewBar-legacy.pCxqzHz7.js": "sha384-7FcisyyQlubip+mwmBcJJDINj/Apyj06zl3UR97oRoGLWW69c5JWI+H5D4dUOToF",
    "/cdn/shopifycloud/checkout-web/assets/c1/page-Shipping-legacy.Dln5NCxQ.js": "sha384-u47al07AO/glf7xYdlmePnjossKO64flKdcPQugOsONuPkk+hMkQ84tiv0SQTlUH",
    "/cdn/shopifycloud/checkout-web/assets/c1/ShipmentBreakdown-legacy.a7SEb60O.js": "sha384-UVHPr6s1TvyN01Y1bE0VuWTq1GL0IsnFmobeXOs5EXdMvTkn7Hv98H/hFV/xGrge",
    "/cdn/shopifycloud/checkout-web/assets/c1/page-Information-legacy.Cg_Kt5R_.js": "sha384-dA774K2IPOXgv2YuADPUdGiUtYmPEkhU4ufPPGHSIOiGa5wsVMBQ05ffCSjMar8c",
    "/cdn/shopifycloud/checkout-web/assets/c1/DeliveryMethodSelectorSection-legacy.CuhMH6o3.js": "sha384-VwRosuV8BSeB5l+MY5jBUpzVzU2MhRXBMQAOomJjMw/w8Mnva7Ha3x+7ncj5bgMG",
    "/cdn/shopifycloud/checkout-web/assets/c1/useEditorShopPayNavigation-legacy.BzrSSdip.js": "sha384-kmuD4Gdq6k/Zd//GmuLDxMZUShHcvB+GFpFicm9CwIPAiGoMleYMlRxmSU5gblfs",
    "/cdn/shopifycloud/checkout-web/assets/c1/VaultedPayment-legacy.CtD2_xSU.js": "sha384-4UuGX9vBlWe2DLIAoMCEZ/BUGTLo+AwECB1tksma+oQIqdUeRGNppxKqDaTiKk6G",
    "/cdn/shopifycloud/checkout-web/assets/c1/ActiveInspector-legacy.CRCIGXyn.js": "sha384-fuCyMW/ufJUkaqKD9OILVJ3MJhNVNnbFQkNlg8nxla2eVs791DfzMbru2fwzvM6+",
    "/cdn/shopifycloud/checkout-web/assets/c1/page-ShopPayLoginLoader-legacy.BfULr8H0.js": "sha384-Mp1g3eTLTa0/DkNxH/y+OHkfSG79FhgNqOeoMKvJn/MdVFZV7HnoXPyr8lq8v7g0",
    "/cdn/shopifycloud/checkout-web/assets/c1/useShopPayQuery-legacy.CQNLNiHE.js": "sha384-Mzun5Rv8BB38Q/Hb6xNmsKCv18AW2VKx3374UjMvfboE5f8pQZ8RP5FCAkB//JFp",
    "/cdn/shopifycloud/checkout-web/assets/c1/useShopPayParts-legacy.CsueeV9j.js": "sha384-TrujQhiEILQ/eaD9khId4SRZ3y5EthMH9gFhRcNiJFREgmzOnKF++nUnO6guTcPQ",
    "/cdn/shopifycloud/checkout-web/assets/c1/useSubscribeMessenger-legacy.amoX02oj.js": "sha384-73lmSazUNcwy4Xbu0IsYtUUUCvk8jLnrStSUiaHXFTBM4HfLNRMU70DmLSQvIilc",
    "/cdn/shopifycloud/checkout-web/assets/c1/page-StockProblems-legacy.CQjtqV2y.js": "sha384-f2DPxzgi2K2DW2BcL7LN/+NDEomdr7rF+MNAKTQxNu6e6cog7ao0OAcyV7Atw/++",
    "/cdn/shopifycloud/checkout-web/assets/c1/OffsitePaymentFailed-legacy.CuwyPUIU.js": "sha384-dl/m617Ak2hnZiHmr+RmJEgfJRZ8sqhHRFJ8GsxREUo2EADbxjPvbFRtqlmFtLkH",
    "/cdn/shopifycloud/checkout-web/assets/c1/component-AutocompleteField-legacy.BwdxjoO9.js": "sha384-vpjR8ynw3A+cKv0QxzSr8FQ+MzRInbHtpRLiw8besRCQ1bjhTXKjHrCfsHhJFLBz",
    "/cdn/shopifycloud/checkout-web/assets/c1/component-DeliveryMacros-legacy.BRUl_EKc.js": "sha384-vNZu1tZwG17dU7A9l6Gfc2TQNMvGmdaLdlspm1FZr41VnN6P1mDKdGjuPPjPYe1B",
    "/cdn/shopifycloud/checkout-web/assets/c1/BuyWithPrimeOrderTrackingButton-legacy.BjTyeHM8.js": "sha384-egBNlDeKQRY7nl8w2i1ogSkthE2X2TbnEm93IaFDe+22/DC6MedwA2LDwzRzih0k",
    "/cdn/shopifycloud/checkout-web/assets/c1/page-OnePageReview-legacy.B9JUs4Hg.js": "sha384-xem8D8s8vhdmms4eZuF5OOtbokgXfLGkmBtgTLTFzCgEsk6xbHbWW/0U4WAUwNJl",
    "/cdn/shopifycloud/checkout-web/assets/c1/PayButtonSection-legacy.wMEDDlk6.js": "sha384-0ysC7SWn2PIgr66SILxzf1k0eG9eJiBtWq7z5VaNg+FGrzKSmwMuOnvWVYjgSo4f",
    "/cdn/shopifycloud/checkout-web/assets/c1/ShopPayOptInDisclaimer-legacy.DGtL-jUw.js": "sha384-pzQ/dyukfqN2cK3FdSMPuPw9bOjHw2B6rnMA6Q8eu/mdZ8abQwyo7GHd4xSEUyCF",
    "/cdn/shopifycloud/checkout-web/assets/c1/RememberMeDescriptionText-legacy.DsqZrixM.js": "sha384-xfDdKzbVFYmvAF3ACNm7jFa/tvqM21tN1+64P5Hsh3/H+DbKbJdXvi7c9qv89PF0",
    "/cdn/shopifycloud/checkout-web/assets/c1/page-Payment-legacy.BkbjySoc.js": "sha384-JukeOUpDobjd67sDAciC31DH+c0z/M44oI+1sWpXBBMnG3BHmPpNX4DpxA5h1FaZ",
    "/cdn/shopifycloud/checkout-web/assets/c1/LocalizationExtensionField-legacy.DvIvGAsB.js": "sha384-MHz/WXBauNoTgK8mV+VoOlTpHyzIQwxRTTTyQHCY7BwPOtwK5VWwpltIKfzIuf7J",
    "/cdn/shopifycloud/checkout-web/assets/c1/Trekkie-legacy.1XtYbjCW.js": "sha384-9B8+5J7ddNDpyjYprMjPAsiuQmR/3xfe4R/kohEbVUPT50NDD9/Bx1WLXjYW58j+",
    "/cdn/shopifycloud/checkout-web/assets/c1/qrcodegen-legacy.DWimPs6n.js": "sha384-yhP3J+Y1K9jiCnCpnLmUlmRUwiA2TjEPXNmoyQ6p7DqCd2e1TwtkLJn1BcJYqR0v",
    "/cdn/shopifycloud/checkout-web/assets/c1/component-ShopPayWrapper-legacy.DAYYHTFc.js": "sha384-63C62250WJtiueNQGgbx8VnZw/fBhPI8yuZN6YdP1Ai/VX/43TW8JoHgkMFxGfuo",
    "/cdn/shopifycloud/checkout-web/assets/c1/monorail-legacy.C-vfuQYR.js": "sha384-foHKbV800XVH5tNtPco6vhMf4+xhzxRqEXcQNiFcB8I4F/i0YmaMx8IqJiVQ/+7b",
    "/cdn/shopifycloud/checkout-web/assets/c1/component-PayPalButton-legacy.BHDxLnAw.js": "sha384-uutYzt3PQ4Heo0pMDwz3Ybne9gMa7V0/n/P25Ei6DLyhtU3eq7bWgek8DQiALmcs",
    "/cdn/shopifycloud/checkout-web/assets/c1/CheckoutEditorBridge-legacy.CN0TJCLb.js": "sha384-enft6sbY4B+Ur/m7Zz98IgImtqBS+LCocAfsz4zKjAaiTa8pYfhOqq0k3gB9UcBu",
    "/cdn/shopifycloud/checkout-web/assets/c1/component-ShopPayVerificationSwitch-legacy.CbR4zpdn.js": "sha384-NO5+PV5QMT95GYvni5YdUyA98CVg3TOLQBye3brDeUkg7WU9MbYnFN4vdMcecndp",
    "/cdn/shopifycloud/checkout-web/assets/c1/index-legacy.B_H38oVr.js": "sha384-CXlICz8HicxPasg99eOT8ZeYh7spDfpa8dEMNWHi5kKanPcIX1HrVQsIN8oTUacS",
    "/cdn/shopifycloud/checkout-web/assets/c1/libphonenumber-index-legacy.BPiD4Gff.js": "sha384-QW8rx+hU2YQwGcg6lEpCOLdoAI7moYSeR8MMdGLMpaIsyxGZ4+UXQeydsqhiQDkE",
    "/cdn/shopifycloud/checkout-web/assets/c1/page-OnePage-legacy.CZQ80ogd.js": "sha384-hGH1x+jiezb2sRe0pvuV8dg4LjPN2+61njanoZmA1Y4qNIyQ3d4CT3oJLsJfamf5",
    "/cdn/shopifycloud/checkout-web/assets/c1/component-GooglePayButton-legacy.DY7yYI-C.js": "sha384-5w9uoNBkBz8OLB+UpOVppCDIwWVk4rtTwRjleWOjNSUym8UK9HmKePmJL7B7dh37",
    "/cdn/shopifycloud/checkout-web/assets/c1/ShopPayButtonContainer-legacy.Dur-HtdF.js": "sha384-17pe7RW/M7hra4McQZ7e71PNEmOwohcaWtk6F0AmiACCs7J19olxwWA1mOpUIgv0",
    "/cdn/shopifycloud/checkout-web/assets/c1/get-negotiation-input-legacy.Bd2czkA3.js": "sha384-wxD8hR++nS8bd3VrozaOq5SIJKhpGDmHEA8P5QiWOKChJbD8i5GeRJk21p5wd4Oc",
    "/cdn/shopifycloud/checkout-web/assets/c1/locale-zh-CN-legacy.1vTpBIV_.js": "sha384-DISll2mhlKsdYKklUD4GUaY1pesRQfpsyXgL+yDv8bTP2trurJARpnAKAqdq3DMO",
    "/cdn/shopifycloud/checkout-web/assets/c1/locale-zh-TW-legacy.DuR_dxeU.js": "sha384-lTn82NzYjQa1OI2nSUIm6RPn4g5TiC1skzTT6VFeRfmPJrllt1EQHYHYqdbt0g7k",
    "/cdn/shopifycloud/checkout-web/assets/c1/DevTools-legacy.cwDcNAAw.js": "sha384-Mf9wioMcEbEppjxetyio1DYq8gdCjUJaa/V8it8zL5qu4UXBYfeznB2qTiqq9o0Z",
    "/cdn/shopifycloud/checkout-web/assets/c1/locale-ja-legacy.2Q2nMqte.js": "sha384-b3r1o9IlIrvf0jk3jiNijMPSDNBJPxizf/CoZixI8oNqOqid5+L3sFLYkGkg9z36",
    "/cdn/shopifycloud/checkout-web/assets/c1/locale-ko-legacy.ueRY0W8O.js": "sha384-Zlx/7/a4TBz6P+qa7zax/RVj5BMSmuvxsAeqUZWwXvthIS93o+PCeKC/x6cGt/Kg",
    "/cdn/shopifycloud/checkout-web/assets/c1/page-ThankYou-legacy.Dpt8O9hQ.js": "sha384-jYFbKp0kza6KbemYKq4Nze/yP5e0NTD5wcWgxH796pgeHl1flIkUzm479ZVg97CX",
    "/cdn/shopifycloud/checkout-web/assets/c1/locale-en-legacy.cQx02XA3.js": "sha384-id7wctnQUnCQ5ZqPEQNTojhAMsOsNt6WBosmgKpGfSDmf2SRB1qZTIhpf5Kqi26u",
    "/cdn/shopifycloud/checkout-web/assets/c1/locale-th-legacy.B1Thmywb.js": "sha384-2e0jf6p/Tm6Sv2CLKqOzTFESfBoiS4UDLoqwDjkkvDUJ0dle51SbOlK+DTWJwsZ0",
    "/cdn/shopifycloud/checkout-web/assets/c1/locale-nb-legacy.G8TZosgF.js": "sha384-VMg6QJpbdYMPwECQ9l4v621conAWU7+ozWSOg/ZTpBMAYhJKYNTCXZWdm2OAR5oR",
    "/cdn/shopifycloud/checkout-web/assets/c1/locale-sv-legacy.D00sXZka.js": "sha384-Q5xrEwScDU/Wre/i5PHfmfa8vXIIzCcmwWHRDttgxA4F4Qt2wab5TFYV1idltFm7",
    "/cdn/shopifycloud/checkout-web/assets/c1/actions-legacy.C-CLOxJv.js": "sha384-Zh2HCQqa33nd6YgwCYfzt7E44nXrGbUDlfl8KdeIAWYM4obKppiemo9Wk2COqBiS",
    "/cdn/shopifycloud/checkout-web/assets/c1/locale-da-legacy.DXESj5zH.js": "sha384-LuVgF1TYpncHJGI/O4goHnB1fOguggPccTG4ZCJRMiAhWr8SvzRf/5SxXZGbTNsP",
    "/cdn/shopifycloud/checkout-web/assets/c1/locale-fi-legacy.C56rLApt.js": "sha384-vcvjkMvmMNBBbADZv6LZcvYwiOGLVyYNRDPaUabf5ixuQhSMyqmXA6z8u+X8hS1Z",
    "/cdn/shopifycloud/checkout-web/assets/c1/locale-hi-legacy.DPFxvYCm.js": "sha384-Yq0R49bx/7Zcr6kGw2RPHT/dQUp/E4Rmdw3hFeqGD6M8bmXTTxG96TAYfizRzi6d",
    "/cdn/shopifycloud/checkout-web/assets/c1/locale-vi-legacy.Q-6eTO-C.js": "sha384-zk1Epnk9RyBjaazAsnhzEStskvm+S0IDsXlFZBflDsEB7t6C3/WvYV3bBX1WPtbU",
    "/cdn/shopifycloud/checkout-web/assets/c1/locale-tr-legacy.DF03Qi83.js": "sha384-Olh/M1LooS63UdpVVayxJi6msjeyC47+7v1JYmFX5NlGlcBsSqwcZB1VSXNn8BX/",
    "/cdn/shopifycloud/checkout-web/assets/c1/locale-id-legacy.CXHu3HPQ.js": "sha384-xrj6bcaoWMitMNYIwvhq43QrEpL3zIfkurwFXlnUwxnHb87g6Jv40QUr+yM77LgJ",
    "/cdn/shopifycloud/checkout-web/assets/c1/locale-ms-legacy.BEI9oM-H.js": "sha384-w0geOvBQNleMgy2Lqm/KPljHdeyrhvqMB5los0DcWrrg37FuorhzeeQuztB7PWVf",
    "/cdn/shopifycloud/checkout-web/assets/c1/locale-nl-legacy.D6gmqyaM.js": "sha384-G0OpBrSdwhDSKH5hjfKPjlgi49wO77R+RzodFLiNmUyqg+jpLeekYctBp9Yqbrel",
    "/cdn/shopifycloud/checkout-web/assets/c1/locale-bg-legacy.BP-E-3B1.js": "sha384-DBzVe1198IH8lQyUYVNkKMGODvv9Yd9JEkNr0egHXxSLrPPBIkZgneCFtd8Go3bX",
    "/cdn/shopifycloud/checkout-web/assets/c1/locale-pt-BR-legacy.C3hr9pkn.js": "sha384-emtDucolS8HFP8iHY890/7JfaUyBnsMLWl9URNSxKpyi9jTOSoSVlpnhpzRJ70UX",
    "/cdn/shopifycloud/checkout-web/assets/c1/locale-hu-legacy.EE03aSdg.js": "sha384-r47S2BrocVH+tKXoqy5t1difKo0cIwl8DCk0FK4f0MFk+Rh0VjfyvDmXBqAv8+22",
    "/cdn/shopifycloud/checkout-web/assets/c1/locale-hr-legacy.CKWh-_F3.js": "sha384-nRkl61y9tJkL8xR6oazMHQ1vhNB7Qh4jFLY9naieff6fgTCPA4Ks+qfWrxywqKvx",
    "/cdn/shopifycloud/checkout-web/assets/c1/page-PostPurchase-legacy.rJTty2fp.js": "sha384-fT9di0jYFiQFqwXf0h138v/mTpemIF9lqZISsE7jVO7gdvLoNGa2OHroPm6TPwIv",
    "/cdn/shopifycloud/checkout-web/assets/c1/PostPurchaseShouldRender-legacy.DigjgGo3.js": "sha384-4nkFgRkOYyatLsSgBrZRfoZGJXA2UlgWd+/Mg+BL/wGCnnzfCQllk8RyC2Uxth4N",
    "/cdn/shopifycloud/checkout-web/assets/c1/locale-cs-legacy.bmj2HERh.js": "sha384-vUQW8S3zYsHjZxyDBChgspRW9drTm5tJUoYOHrXIDT+ralNcxZb0PlLBghZsFNRc",
    "/cdn/shopifycloud/checkout-web/assets/c1/locale-de-legacy.sv215Ulq.js": "sha384-0OEP69Tz7xlyBvShf9Wb9h/fnrNQPZJOBg6oQO18IxNcmVdsjgwDNDmEYVczFyHw",
    "/cdn/shopifycloud/checkout-web/assets/c1/locale-sk-legacy.D7idetQF.js": "sha384-M+q67Jh57mgGBVH/DInByE+ZDeAizySIGPD4vOrg83OqI4nnHdVlGi6QNtIwut2o",
    "/cdn/shopifycloud/checkout-web/assets/c1/locale-pt-PT-legacy.-ew5OLYc.js": "sha384-e3Hwmhz7/ifOekd1Fn3RDizhwIxg2zJaGBgrJn9q6o4BgxLXC73IwBc1LrZDRVEG",
    "/cdn/shopifycloud/checkout-web/assets/c1/locale-sl-legacy.DUhMLC7B.js": "sha384-85p82pRCcnpCT13jHP89tautL6OUchcJ7ANhbYR695AmoHFZgMDKtlvYRVeHAMlf",
    "/cdn/shopifycloud/checkout-web/assets/c1/locale-lt-legacy.DWjFi-KN.js": "sha384-ZtoTu7Yic5vbnn8aGHjTaZuFDFkknPdM4WOlCWS4q2dA/ZGhmR5/cKNC4DrEGBsW",
    "/cdn/shopifycloud/checkout-web/assets/c1/locale-es-legacy.CjqKh9Yo.js": "sha384-u7XOurNCoTq8FcqaS389gLxOPLDFbbI5lKW0wbwrjhLSGojTKvQPchFxbLA1/Oro",
    "/cdn/shopifycloud/checkout-web/assets/c1/locale-ro-legacy.DMhSj_rK.js": "sha384-M/HvLYIpj9B+px9hXIQmERlwv7zZD29SiSIUp1UOnkxmCJCh8FtEtTx0og9VUX9j",
    "/cdn/shopifycloud/checkout-web/assets/c1/locale-pl-legacy.CHk00Sjk.js": "sha384-L1smsJjCkWq9ccnPkqxmClK+eEWlRKaDOgPf32EXrcM2HwnF/kENI02Qw1h83esx",
    "/cdn/shopifycloud/checkout-web/assets/c1/locale-it-legacy.fxsEVL-z.js": "sha384-YIRxvjqnNXDXgKuzXScUtDEwXcR0IB5UzzSVjK5VABZL00FTqb5imyQYA2WNwpXQ",
    "/cdn/shopifycloud/checkout-web/assets/c1/locale-el-legacy.BYTdaoZz.js": "sha384-uTbX6XwqzgNFq4H/jMbdW6axZFXGAMd0+SiMGVT2zxotH7xe1uU/2vlhIE9iHFKp",
    "/cdn/shopifycloud/checkout-web/assets/c1/locale-ru-legacy.DYWqAWNp.js": "sha384-/b/aBZw4grUiC9tmmqpJ5xLpf6lnxZ1UBAS1kw/liX89DrJLlryVehS5hOvnSc9c",
    "/cdn/shopifycloud/checkout-web/assets/c1/locale-fr-legacy.CdUe78u9.js": "sha384-mOO+LNPCUy4691+1wvRXNZmRbAaZkrkV6pl/rNZ63y+gwLkJI7oUbwx0vJZ9uva/",
    "/cdn/shopifycloud/checkout-web/assets/c1/ShopPay-legacy.uz2qdacl.js": "sha384-hKxRty8b6B65cbL8vE8mIyBsCv2OT6EEyI5Mq0E82XyJpD4rX9SyI1x/XLNjhziN",
    "/cdn/shopifycloud/checkout-web/assets/c1/NoAddressLocationFullDetour-legacy.5svy5eg9.js": "sha384-iwCYnPVA8ERYPEkZEib299DvS+Wg2MDILW5yWqiZoRKf1HU4U3DxBDZKL1JqX/G2",
    "/cdn/shopifycloud/checkout-web/assets/c1/map-async-dependencies-legacy.Be9iK1uK.js": "sha384-+Np4pv8/IQH5xn/TponlPhOeeHhi/tkRMaFA+pbHN4wt+ZYMtKJ7d7JnScQnaCCU",
    "/cdn/shopifycloud/checkout-web/assets/c1/polyfills-legacy.CxAH3j_U.js": "sha384-YUCvaKNwY7d8sqLC6qAh/jhRadGglZd5pT03sYpm38lqfCd0ijmR1gQ+v+yQiHEA"
  }
}</script><script>/*!
 * SJS 6.15.1
 */
!function(){function e(e,t){return(t||"")+" (SystemJS https://github.com/systemjs/systemjs/blob/main/docs/errors.md#"+e+")"}function t(e,t){if(-1!==e.indexOf("\\")&&(e=e.replace(S,"/")),"/"===e[0]&&"/"===e[1])return t.slice(0,t.indexOf(":")+1)+e;if("."===e[0]&&("/"===e[1]||"."===e[1]&&("/"===e[2]||2===e.length&&(e+="/"))||1===e.length&&(e+="/"))||"/"===e[0]){var r,n=t.slice(0,t.indexOf(":")+1);if(r="/"===t[n.length+1]?"file:"!==n?(r=t.slice(n.length+2)).slice(r.indexOf("/")+1):t.slice(8):t.slice(n.length+("/"===t[n.length])),"/"===e[0])return t.slice(0,t.length-r.length-1)+e;for(var i=r.slice(0,r.lastIndexOf("/")+1)+e,o=[],s=-1,c=0;c<i.length;c++)-1!==s?"/"===i[c]&&(o.push(i.slice(s,c+1)),s=-1):"."===i[c]?"."!==i[c+1]||"/"!==i[c+2]&&c+2!==i.length?"/"===i[c+1]||c+1===i.length?c+=1:s=c:(o.pop(),c+=2):s=c;return-1!==s&&o.push(i.slice(s)),t.slice(0,t.length-r.length)+o.join("")}}function r(e,r){return t(e,r)||(-1!==e.indexOf(":")?e:t("./"+e,r))}function n(e,r,n,i,o){for(var s in e){var f=t(s,n)||s,a=e[s];if("string"==typeof a){var l=u(i,t(a,n)||a,o);l?r[f]=l:c("W1",s,a)}}}function i(e,t,i){var o;for(o in e.imports&&n(e.imports,i.imports,t,i,null),e.scopes||{}){var s=r(o,t);n(e.scopes[o],i.scopes[s]||(i.scopes[s]={}),t,i,s)}for(o in e.depcache||{})i.depcache[r(o,t)]=e.depcache[o];for(o in e.integrity||{})i.integrity[r(o,t)]=e.integrity[o]}function o(e,t){if(t[e])return e;var r=e.length;do{var n=e.slice(0,r+1);if(n in t)return n}while(-1!==(r=e.lastIndexOf("/",r-1)))}function s(e,t){var r=o(e,t);if(r){var n=t[r];if(null===n)return;if(!(e.length>r.length&&"/"!==n[n.length-1]))return n+e.slice(r.length);c("W2",r,n)}}function c(t,r,n){console.warn(e(t,[n,r].join(", ")))}function u(e,t,r){for(var n=e.scopes,i=r&&o(r,n);i;){var c=s(t,n[i]);if(c)return c;i=o(i.slice(0,i.lastIndexOf("/")),n)}return s(t,e.imports)||-1!==t.indexOf(":")&&t}function f(){this[b]={}}function a(t,r,n,i){var o=t[b][r];if(o)return o;var s=[],c=Object.create(null);j&&Object.defineProperty(c,j,{value:"Module"});var u=Promise.resolve().then((function(){return t.instantiate(r,n,i)})).then((function(n){if(!n)throw Error(e(2,r));var i=n[1]((function(e,t){o.h=!0;var r=!1;if("string"==typeof e)e in c&&c[e]===t||(c[e]=t,r=!0);else{for(var n in e)t=e[n],n in c&&c[n]===t||(c[n]=t,r=!0);e&&e.__esModule&&(c.__esModule=e.__esModule)}if(r)for(var i=0;i<s.length;i++){var u=s[i];u&&u(c)}return t}),2===n[1].length?{import:function(e,n){return t.import(e,r,n)},meta:t.createContext(r)}:void 0);return o.e=i.execute||function(){},[n[0],i.setters||[],n[2]||[]]}),(function(e){throw o.e=null,o.er=e,e})),f=u.then((function(e){return Promise.all(e[0].map((function(n,i){var o=e[1][i],s=e[2][i];return Promise.resolve(t.resolve(n,r)).then((function(e){var n=a(t,e,r,s);return Promise.resolve(n.I).then((function(){return o&&(n.i.push(o),!n.h&&n.I||o(n.n)),n}))}))}))).then((function(e){o.d=e}))}));return o=t[b][r]={id:r,i:s,n:c,m:i,I:u,L:f,h:!1,d:void 0,e:void 0,er:void 0,E:void 0,C:void 0,p:void 0}}function l(e,t,r,n){if(!n[t.id])return n[t.id]=!0,Promise.resolve(t.L).then((function(){return t.p&&null!==t.p.e||(t.p=r),Promise.all(t.d.map((function(t){return l(e,t,r,n)})))})).catch((function(e){if(t.er)throw e;throw t.e=null,e}))}function h(e,t){return t.C=l(e,t,t,{}).then((function(){return d(e,t,{})})).then((function(){return t.n}))}function d(e,t,r){function n(){try{var e=o.call(I);if(e)return e=e.then((function(){t.C=t.n,t.E=null}),(function(e){throw t.er=e,t.E=null,e})),t.E=e;t.C=t.n,t.L=t.I=void 0}catch(r){throw t.er=r,r}}if(!r[t.id]){if(r[t.id]=!0,!t.e){if(t.er)throw t.er;return t.E?t.E:void 0}var i,o=t.e;return t.e=null,t.d.forEach((function(n){try{var o=d(e,n,r);o&&(i=i||[]).push(o)}catch(s){throw t.er=s,s}})),i?Promise.all(i).then(n):n()}}function v(){[].forEach.call(document.querySelectorAll("script"),(function(t){if(!t.sp)if("systemjs-module"===t.type){if(t.sp=!0,!t.src)return;System.import("import:"===t.src.slice(0,7)?t.src.slice(7):r(t.src,p)).catch((function(e){if(e.message.indexOf("https://github.com/systemjs/systemjs/blob/main/docs/errors.md#3")>-1){var r=document.createEvent("Event");r.initEvent("error",!1,!1),t.dispatchEvent(r)}return Promise.reject(e)}))}else if("systemjs-importmap"===t.type){t.sp=!0;var n=t.src?(System.fetch||fetch)(t.src,{integrity:t.integrity,priority:t.fetchPriority,passThrough:!0}).then((function(e){if(!e.ok)throw Error(e.status);return e.text()})).catch((function(r){return r.message=e("W4",t.src)+"\n"+r.message,console.warn(r),"function"==typeof t.onerror&&t.onerror(),"{}"})):t.innerHTML;M=M.then((function(){return n})).then((function(r){!function(t,r,n){var o={};try{o=JSON.parse(r)}catch(s){console.warn(Error(e("W5")))}i(o,n,t)}(R,r,t.src||p)}))}}))}var p,m="undefined"!=typeof Symbol,g="undefined"!=typeof self,y="undefined"!=typeof document,E=g?self:global;if(y){var w=document.querySelector("base[href]");w&&(p=w.href)}if(!p&&"undefined"!=typeof location){var O=(p=location.href.split("#")[0].split("?")[0]).lastIndexOf("/");-1!==O&&(p=p.slice(0,O+1))}var x,S=/\\/g,j=m&&Symbol.toStringTag,b=m?Symbol():"@",P=f.prototype;P.import=function(e,t,r){var n=this;return t&&"object"==typeof t&&(r=t,t=void 0),Promise.resolve(n.prepareImport()).then((function(){return n.resolve(e,t,r)})).then((function(e){var t=a(n,e,void 0,r);return t.C||h(n,t)}))},P.createContext=function(e){var t=this;return{url:e,resolve:function(r,n){return Promise.resolve(t.resolve(r,n||e))}}},P.register=function(e,t,r){x=[e,t,r]},P.getRegister=function(){var e=x;return x=void 0,e};var I=Object.freeze(Object.create(null));E.System=new f;var L,C,M=Promise.resolve(),R={imports:{},scopes:{},depcache:{},integrity:{}},T=y;if(P.prepareImport=function(e){return(T||e)&&(v(),T=!1),M},P.getImportMap=function(){return JSON.parse(JSON.stringify(R))},y&&(v(),window.addEventListener("DOMContentLoaded",v)),P.addImportMap=function(e,t){i(e,t||p,R)},y){window.addEventListener("error",(function(e){J=e.filename,W=e.error}));var _=location.origin}P.createScript=function(e){var t=document.createElement("script");t.async=!0,e.indexOf(_+"/")&&(t.crossOrigin="anonymous");var r=R.integrity[e];return r&&(t.integrity=r),t.src=e,t};var J,W,q={},N=P.register;P.register=function(e,t){if(y&&"loading"===document.readyState&&"string"!=typeof e){var r=document.querySelectorAll("script[src]"),n=r[r.length-1];if(n){L=e;var i=this;C=setTimeout((function(){q[n.src]=[e,t],i.import(n.src)}))}}else L=void 0;return N.call(this,e,t)},P.instantiate=function(t,r){var n=q[t];if(n)return delete q[t],n;var i=this;return Promise.resolve(P.createScript(t)).then((function(n){return new Promise((function(o,s){n.addEventListener("error",(function(){s(Error(e(3,[t,r].join(", "))))})),n.addEventListener("load",(function(){if(document.head.removeChild(n),J===t)s(W);else{var e=i.getRegister(t);e&&e[0]===L&&clearTimeout(C),o(e)}})),document.head.appendChild(n)}))}))},P.shouldFetch=function(){return!1},"undefined"!=typeof fetch&&(P.fetch=fetch);var k=P.instantiate,A=/^(text|application)\/(x-)?javascript(;|$)/;P.instantiate=function(t,r,n){var i=this;return this.shouldFetch(t,r,n)?this.fetch(t,{credentials:"same-origin",integrity:R.integrity[t],meta:n}).then((function(n){if(!n.ok)throw Error(e(7,[n.status,n.statusText,t,r].join(", ")));var o=n.headers.get("content-type");if(!o||!A.test(o))throw Error(e(4,o));return n.text().then((function(e){return e.indexOf("//# sourceURL=")<0&&(e+="\n//# sourceURL="+t),(0,eval)(e),i.getRegister(t)}))})):k.apply(this,arguments)},P.resolve=function(r,n){return u(R,t(r,n=n||p)||r,n)||function(t,r){throw Error(e(8,[t,r].join(", ")))}(r,n)};var F=P.instantiate;P.instantiate=function(e,t,r){var n=R.depcache[e];if(n)for(var i=0;i<n.length;i++)a(this,this.resolve(n[i],e),e);return F.call(this,e,t,r)},g&&"function"==typeof importScripts&&(P.instantiate=function(e){var t=this;return Promise.resolve().then((function(){return importScripts(e),t.getRegister(e)}))})}();
//# sourceMappingURL=s.min.js.map
</script><link href="/cdn/shopifycloud/checkout-web/assets/c1/polyfills-legacy.CxAH3j_U.js" as="script" rel="preload" integrity="sha384-YUCvaKNwY7d8sqLC6qAh/jhRadGglZd5pT03sYpm38lqfCd0ijmR1gQ+v+yQiHEA" fetchPriority="high"/><link href="/cdn/shopifycloud/checkout-web/assets/c1/app-legacy.aMtlhewy.js" as="script" rel="preload" integrity="sha384-2WIGmU84o1ThrfTzoP8GG2kJrFJ0Mx0N550Z7bvlPwsf1OB0vQLA88t/35tQ3M42" fetchPriority="high"/><link href="/cdn/shopifycloud/checkout-web/assets/c1/locale-en-legacy.cQx02XA3.js" as="script" rel="preload" integrity="sha384-id7wctnQUnCQ5ZqPEQNTojhAMsOsNt6WBosmgKpGfSDmf2SRB1qZTIhpf5Kqi26u"/><link href="/cdn/shopifycloud/checkout-web/assets/c1/page-OnePage-legacy.CZQ80ogd.js" as="script" rel="preload" integrity="sha384-hGH1x+jiezb2sRe0pvuV8dg4LjPN2+61njanoZmA1Y4qNIyQ3d4CT3oJLsJfamf5"/><link href="/cdn/shopifycloud/checkout-web/assets/c1/LocalizationExtensionField-legacy.DvIvGAsB.js" as="script" rel="preload" integrity="sha384-MHz/WXBauNoTgK8mV+VoOlTpHyzIQwxRTTTyQHCY7BwPOtwK5VWwpltIKfzIuf7J"/><link href="/cdn/shopifycloud/checkout-web/assets/c1/RememberMeDescriptionText-legacy.DsqZrixM.js" as="script" rel="preload" integrity="sha384-xfDdKzbVFYmvAF3ACNm7jFa/tvqM21tN1+64P5Hsh3/H+DbKbJdXvi7c9qv89PF0"/><link href="/cdn/shopifycloud/checkout-web/assets/c1/ShopPayOptInDisclaimer-legacy.DGtL-jUw.js" as="script" rel="preload" integrity="sha384-pzQ/dyukfqN2cK3FdSMPuPw9bOjHw2B6rnMA6Q8eu/mdZ8abQwyo7GHd4xSEUyCF"/><link href="/cdn/shopifycloud/checkout-web/assets/c1/PaymentButtons-legacy.CdYmaiip.js" as="script" rel="preload" integrity="sha384-UVXmi5JuffBmo+3H1+XJMAi49z5OLxrKcdeaxRsD5g3oNRl2VuIKQfzlPo3ixlC2"/><link href="/cdn/shopifycloud/checkout-web/assets/c1/StockProblemsLineItemList-legacy.CACz654j.js" as="script" rel="preload" integrity="sha384-43OL2TlL5DK6M85iKaTf1k1wiUrA3BPsV+Q/YWhGZqPHu1LU9LN6jr+qLWTABhJY"/><link href="/cdn/shopifycloud/checkout-web/assets/c1/DeliveryMethodSelectorSection-legacy.CuhMH6o3.js" as="script" rel="preload" integrity="sha384-VwRosuV8BSeB5l+MY5jBUpzVzU2MhRXBMQAOomJjMw/w8Mnva7Ha3x+7ncj5bgMG"/><link href="/cdn/shopifycloud/checkout-web/assets/c1/useEditorShopPayNavigation-legacy.BzrSSdip.js" as="script" rel="preload" integrity="sha384-kmuD4Gdq6k/Zd//GmuLDxMZUShHcvB+GFpFicm9CwIPAiGoMleYMlRxmSU5gblfs"/><link href="/cdn/shopifycloud/checkout-web/assets/c1/VaultedPayment-legacy.CtD2_xSU.js" as="script" rel="preload" integrity="sha384-4UuGX9vBlWe2DLIAoMCEZ/BUGTLo+AwECB1tksma+oQIqdUeRGNppxKqDaTiKk6G"/><link href="/cdn/shopifycloud/checkout-web/assets/c1/SeparatePaymentsNotice-legacy.DHPrwbG3.js" as="script" rel="preload" integrity="sha384-i6q47fgAmKwU4E6gz86j6MsN1uOUL8mZSZJrp2r0i34yiZnVNUVH15/mv2AExdXc"/><link href="/cdn/shopifycloud/checkout-web/assets/c1/ShipmentBreakdown-legacy.a7SEb60O.js" as="script" rel="preload" integrity="sha384-UVHPr6s1TvyN01Y1bE0VuWTq1GL0IsnFmobeXOs5EXdMvTkn7Hv98H/hFV/xGrge"/><link href="/cdn/shopifycloud/checkout-web/assets/c1/MerchandiseModal-legacy.Dyrxm_zU.js" as="script" rel="preload" integrity="sha384-KDiAVC4SRONBjUVHutqxxxvs4UY6OipbmwAwJ2zs0NSmR8EE3Q7HkNjJHEu12uTZ"/><link href="/cdn/shopifycloud/checkout-web/assets/c1/StackedMerchandisePreview-legacy.1itpoSxr.js" as="script" rel="preload" integrity="sha384-7K4XkyOJEfixvll/9EgxP143DhJThy1iUCWMKJm7nhW0EsjuWYjwbp23Ul1vLon8"/><link href="/cdn/shopifycloud/checkout-web/assets/c1/component-ShopPayVerificationSwitch-legacy.CbR4zpdn.js" as="script" rel="preload" integrity="sha384-NO5+PV5QMT95GYvni5YdUyA98CVg3TOLQBye3brDeUkg7WU9MbYnFN4vdMcecndp"/><link href="/cdn/shopifycloud/checkout-web/assets/c1/useSubscribeMessenger-legacy.amoX02oj.js" as="script" rel="preload" integrity="sha384-73lmSazUNcwy4Xbu0IsYtUUUCvk8jLnrStSUiaHXFTBM4HfLNRMU70DmLSQvIilc"/><link href="/cdn/shopifycloud/checkout-web/assets/c1/index-legacy.B_H38oVr.js" as="script" rel="preload" integrity="sha384-CXlICz8HicxPasg99eOT8ZeYh7spDfpa8dEMNWHi5kKanPcIX1HrVQsIN8oTUacS"/><link href="/cdn/shopifycloud/checkout-web/assets/c1/PayButtonSection-legacy.wMEDDlk6.js" as="script" rel="preload" integrity="sha384-0ysC7SWn2PIgr66SILxzf1k0eG9eJiBtWq7z5VaNg+FGrzKSmwMuOnvWVYjgSo4f"/><script defer src="/cdn/shopifycloud/checkout-web/assets/c1/polyfills-legacy.CxAH3j_U.js" integrity="sha384-YUCvaKNwY7d8sqLC6qAh/jhRadGglZd5pT03sYpm38lqfCd0ijmR1gQ+v+yQiHEA"></script><script defer src="/cdn/shopifycloud/checkout-web/assets/c1/app-legacy.aMtlhewy.js" type="systemjs-module" integrity="sha384-2WIGmU84o1ThrfTzoP8GG2kJrFJ0Mx0N550Z7bvlPwsf1OB0vQLA88t/35tQ3M42"></script><meta name="serialized-session-token" content="&quot;AAEBliIo6z8TpCE4G6EQZTJHaCYoa7be-mp7TXtT4e8M5IwrxkEzrcey-yThxOhJREyEgXITVPaziFhryXNksbcUlceEJTmnH9YFasudmwzv_Fph4Zv2n8JQaumERbnsrluzAuIh9xBK5qoc3ghMruRnhMn8RsT9LNelSuwn2hHNejTOjjekUk2srCHQnxtny_mJpUYty_tEP2asHc2hEaCkMfmdnQNA&quot;"/><meta name="serialized-source-token" content="&quot;hWN58P5vnP5f3mFNyIRk9QBu&quot;"/><meta name="serialized-source-type" content="&quot;cn&quot;"/><meta name="serialized-checkout-session-identifier" content="&quot;a43fb3f45ab275ae35b5bd4648b57dbc&quot;"/><meta name="serialized-graphql" content="{&quot;48a283248c7c0484c9d74d29eebfd8e8009baefc86733f126f296ad0d98321be{}&quot;:{&quot;shop&quot;:{&quot;id&quot;:&quot;gid://shopify/Shop/2442&quot;,&quot;designSystem&quot;:{&quot;colors&quot;:{&quot;global&quot;:{&quot;brand&quot;:&quot;hsl(231.994, 93.077%, 60.75%)&quot;,&quot;accent&quot;:&quot;hsl(231.994, 93.077%, 60.75%)&quot;,&quot;custom&quot;:null,&quot;success&quot;:null,&quot;warning&quot;:null,&quot;critical&quot;:null,&quot;info&quot;:null,&quot;__typename&quot;:&quot;ColorGlobal&quot;},&quot;schemes&quot;:null,&quot;__typename&quot;:&quot;Colors&quot;},&quot;typography&quot;:null,&quot;cornerRadius&quot;:null,&quot;__typename&quot;:&quot;DesignSystem&quot;},&quot;customizations&quot;:null,&quot;__typename&quot;:&quot;CheckoutShopConfig&quot;}},&quot;5638616fb05cb50fa18d4cba4335a74898a1bfebfdc79a784e07dacd23898e17{}&quot;:{&quot;shop&quot;:{&quot;id&quot;:&quot;gid://shopify/Shop/2442&quot;,&quot;shippingCountries&quot;:[{&quot;value&quot;:&quot;US&quot;,&quot;label&quot;:&quot;United States&quot;,&quot;__typename&quot;:&quot;Country&quot;}],&quot;__typename&quot;:&quot;CheckoutShopConfig&quot;}},&quot;1f464dae8cfc48ed739094d19709a52fff169078d1f750d864ad4c8da1ce4e17{}&quot;:{&quot;shop&quot;:{&quot;defaultShippingDetails&quot;:{&quot;country&quot;:{&quot;name&quot;:&quot;United States&quot;,&quot;code&quot;:&quot;US&quot;,&quot;localizationKeys&quot;:{&quot;address2&quot;:null,&quot;postalCode&quot;:&quot;zip_code_label&quot;,&quot;zone&quot;:&quot;state_label&quot;,&quot;neighborhood&quot;:null,&quot;__typename&quot;:&quot;AddressLocalizationKeys&quot;},&quot;labels&quot;:{&quot;firstName&quot;:&quot;First name&quot;,&quot;lastName&quot;:&quot;Last name&quot;,&quot;company&quot;:&quot;Company&quot;,&quot;address1&quot;:&quot;Address&quot;,&quot;address2&quot;:&quot;Apartment, suite, etc&quot;,&quot;city&quot;:&quot;City&quot;,&quot;country&quot;:&quot;Country/region&quot;,&quot;zone&quot;:&quot;State&quot;,&quot;postalCode&quot;:&quot;ZIP code&quot;,&quot;phone&quot;:&quot;Phone&quot;,&quot;__typename&quot;:&quot;AddressLabels&quot;},&quot;zones&quot;:[{&quot;code&quot;:&quot;AL&quot;,&quot;name&quot;:&quot;Alabama&quot;,&quot;nameWithAlternates&quot;:[&quot;Alabama&quot;],&quot;__typename&quot;:&quot;AddressZone&quot;},{&quot;code&quot;:&quot;AK&quot;,&quot;name&quot;:&quot;Alaska&quot;,&quot;nameWithAlternates&quot;:[&quot;Alaska&quot;],&quot;__typename&quot;:&quot;AddressZone&quot;},{&quot;code&quot;:&quot;AS&quot;,&quot;name&quot;:&quot;American Samoa&quot;,&quot;nameWithAlternates&quot;:[&quot;American Samoa&quot;],&quot;__typename&quot;:&quot;AddressZone&quot;},{&quot;code&quot;:&quot;AZ&quot;,&quot;name&quot;:&quot;Arizona&quot;,&quot;nameWithAlternates&quot;:[&quot;Arizona&quot;],&quot;__typename&quot;:&quot;AddressZone&quot;},{&quot;code&quot;:&quot;AR&quot;,&quot;name&quot;:&quot;Arkansas&quot;,&quot;nameWithAlternates&quot;:[&quot;Arkansas&quot;],&quot;__typename&quot;:&quot;AddressZone&quot;},{&quot;code&quot;:&quot;CA&quot;,&quot;name&quot;:&quot;California&quot;,&quot;nameWithAlternates&quot;:[&quot;California&quot;],&quot;__typename&quot;:&quot;AddressZone&quot;},{&quot;code&quot;:&quot;CO&quot;,&quot;name&quot;:&quot;Colorado&quot;,&quot;nameWithAlternates&quot;:[&quot;Colorado&quot;],&quot;__typename&quot;:&quot;AddressZone&quot;},{&quot;code&quot;:&quot;CT&quot;,&quot;name&quot;:&quot;Connecticut&quot;,&quot;nameWithAlternates&quot;:[&quot;Connecticut&quot;],&quot;__typename&quot;:&quot;AddressZone&quot;},{&quot;code&quot;:&quot;DE&quot;,&quot;name&quot;:&quot;Delaware&quot;,&quot;nameWithAlternates&quot;:[&quot;Delaware&quot;],&quot;__typename&quot;:&quot;AddressZone&quot;},{&quot;code&quot;:&quot;FM&quot;,&quot;name&quot;:&quot;Micronesia&quot;,&quot;nameWithAlternates&quot;:[&quot;Federated States of Micronesia&quot;,&quot;Micronesia&quot;],&quot;__typename&quot;:&quot;AddressZone&quot;},{&quot;code&quot;:&quot;FL&quot;,&quot;name&quot;:&quot;Florida&quot;,&quot;nameWithAlternates&quot;:[&quot;Florida&quot;],&quot;__typename&quot;:&quot;AddressZone&quot;},{&quot;code&quot;:&quot;GA&quot;,&quot;name&quot;:&quot;Georgia&quot;,&quot;nameWithAlternates&quot;:[&quot;Georgia&quot;],&quot;__typename&quot;:&quot;AddressZone&quot;},{&quot;code&quot;:&quot;GU&quot;,&quot;name&quot;:&quot;Guam&quot;,&quot;nameWithAlternates&quot;:[&quot;Guam&quot;],&quot;__typename&quot;:&quot;AddressZone&quot;},{&quot;code&quot;:&quot;HI&quot;,&quot;name&quot;:&quot;Hawaii&quot;,&quot;nameWithAlternates&quot;:[&quot;Hawaii&quot;],&quot;__typename&quot;:&quot;AddressZone&quot;},{&quot;code&quot;:&quot;ID&quot;,&quot;name&quot;:&quot;Idaho&quot;,&quot;nameWithAlternates&quot;:[&quot;Idaho&quot;],&quot;__typename&quot;:&quot;AddressZone&quot;},{&quot;code&quot;:&quot;IL&quot;,&quot;name&quot;:&quot;Illinois&quot;,&quot;nameWithAlternates&quot;:[&quot;Illinois&quot;],&quot;__typename&quot;:&quot;AddressZone&quot;},{&quot;code&quot;:&quot;IN&quot;,&quot;name&quot;:&quot;Indiana&quot;,&quot;nameWithAlternates&quot;:[&quot;Indiana&quot;],&quot;__typename&quot;:&quot;AddressZone&quot;},{&quot;code&quot;:&quot;IA&quot;,&quot;name&quot;:&quot;Iowa&quot;,&quot;nameWithAlternates&quot;:[&quot;Iowa&quot;],&quot;__typename&quot;:&quot;AddressZone&quot;},{&quot;code&quot;:&quot;KS&quot;,&quot;name&quot;:&quot;Kansas&quot;,&quot;nameWithAlternates&quot;:[&quot;Kansas&quot;],&quot;__typename&quot;:&quot;AddressZone&quot;},{&quot;code&quot;:&quot;KY&quot;,&quot;name&quot;:&quot;Kentucky&quot;,&quot;nameWithAlternates&quot;:[&quot;Kentucky&quot;],&quot;__typename&quot;:&quot;AddressZone&quot;},{&quot;code&quot;:&quot;LA&quot;,&quot;name&quot;:&quot;Louisiana&quot;,&quot;nameWithAlternates&quot;:[&quot;Louisiana&quot;],&quot;__typename&quot;:&quot;AddressZone&quot;},{&quot;code&quot;:&quot;ME&quot;,&quot;name&quot;:&quot;Maine&quot;,&quot;nameWithAlternates&quot;:[&quot;Maine&quot;],&quot;__typename&quot;:&quot;AddressZone&quot;},{&quot;code&quot;:&quot;MH&quot;,&quot;name&quot;:&quot;Marshall Islands&quot;,&quot;nameWithAlternates&quot;:[&quot;Marshall Islands&quot;],&quot;__typename&quot;:&quot;AddressZone&quot;},{&quot;code&quot;:&quot;MD&quot;,&quot;name&quot;:&quot;Maryland&quot;,&quot;nameWithAlternates&quot;:[&quot;Maryland&quot;],&quot;__typename&quot;:&quot;AddressZone&quot;},{&quot;code&quot;:&quot;MA&quot;,&quot;name&quot;:&quot;Massachusetts&quot;,&quot;nameWithAlternates&quot;:[&quot;Massachusetts&quot;],&quot;__typename&quot;:&quot;AddressZone&quot;},{&quot;code&quot;:&quot;MI&quot;,&quot;name&quot;:&quot;Michigan&quot;,&quot;nameWithAlternates&quot;:[&quot;Michigan&quot;],&quot;__typename&quot;:&quot;AddressZone&quot;},{&quot;code&quot;:&quot;MN&quot;,&quot;name&quot;:&quot;Minnesota&quot;,&quot;nameWithAlternates&quot;:[&quot;Minnesota&quot;],&quot;__typename&quot;:&quot;AddressZone&quot;},{&quot;code&quot;:&quot;MS&quot;,&quot;name&quot;:&quot;Mississippi&quot;,&quot;nameWithAlternates&quot;:[&quot;Mississippi&quot;],&quot;__typename&quot;:&quot;AddressZone&quot;},{&quot;code&quot;:&quot;MO&quot;,&quot;name&quot;:&quot;Missouri&quot;,&quot;nameWithAlternates&quot;:[&quot;Missouri&quot;],&quot;__typename&quot;:&quot;AddressZone&quot;},{&quot;code&quot;:&quot;MT&quot;,&quot;name&quot;:&quot;Montana&quot;,&quot;nameWithAlternates&quot;:[&quot;Montana&quot;],&quot;__typename&quot;:&quot;AddressZone&quot;},{&quot;code&quot;:&quot;NE&quot;,&quot;name&quot;:&quot;Nebraska&quot;,&quot;nameWithAlternates&quot;:[&quot;Nebraska&quot;],&quot;__typename&quot;:&quot;AddressZone&quot;},{&quot;code&quot;:&quot;NV&quot;,&quot;name&quot;:&quot;Nevada&quot;,&quot;nameWithAlternates&quot;:[&quot;Nevada&quot;],&quot;__typename&quot;:&quot;AddressZone&quot;},{&quot;code&quot;:&quot;NH&quot;,&quot;name&quot;:&quot;New Hampshire&quot;,&quot;nameWithAlternates&quot;:[&quot;New Hampshire&quot;],&quot;__typename&quot;:&quot;AddressZone&quot;},{&quot;code&quot;:&quot;NJ&quot;,&quot;name&quot;:&quot;New Jersey&quot;,&quot;nameWithAlternates&quot;:[&quot;New Jersey&quot;],&quot;__typename&quot;:&quot;AddressZone&quot;},{&quot;code&quot;:&quot;NM&quot;,&quot;name&quot;:&quot;New Mexico&quot;,&quot;nameWithAlternates&quot;:[&quot;New Mexico&quot;],&quot;__typename&quot;:&quot;AddressZone&quot;},{&quot;code&quot;:&quot;NY&quot;,&quot;name&quot;:&quot;New York&quot;,&quot;nameWithAlternates&quot;:[&quot;New York&quot;],&quot;__typename&quot;:&quot;AddressZone&quot;},{&quot;code&quot;:&quot;NC&quot;,&quot;name&quot;:&quot;North Carolina&quot;,&quot;nameWithAlternates&quot;:[&quot;North Carolina&quot;],&quot;__typename&quot;:&quot;AddressZone&quot;},{&quot;code&quot;:&quot;ND&quot;,&quot;name&quot;:&quot;North Dakota&quot;,&quot;nameWithAlternates&quot;:[&quot;North Dakota&quot;],&quot;__typename&quot;:&quot;AddressZone&quot;},{&quot;code&quot;:&quot;MP&quot;,&quot;name&quot;:&quot;Northern Mariana Islands&quot;,&quot;nameWithAlternates&quot;:[&quot;Northern Mariana Islands&quot;],&quot;__typename&quot;:&quot;AddressZone&quot;},{&quot;code&quot;:&quot;OH&quot;,&quot;name&quot;:&quot;Ohio&quot;,&quot;nameWithAlternates&quot;:[&quot;Ohio&quot;],&quot;__typename&quot;:&quot;AddressZone&quot;},{&quot;code&quot;:&quot;OK&quot;,&quot;name&quot;:&quot;Oklahoma&quot;,&quot;nameWithAlternates&quot;:[&quot;Oklahoma&quot;],&quot;__typename&quot;:&quot;AddressZone&quot;},{&quot;code&quot;:&quot;OR&quot;,&quot;name&quot;:&quot;Oregon&quot;,&quot;nameWithAlternates&quot;:[&quot;Oregon&quot;],&quot;__typename&quot;:&quot;AddressZone&quot;},{&quot;code&quot;:&quot;PW&quot;,&quot;name&quot;:&quot;Palau&quot;,&quot;nameWithAlternates&quot;:[&quot;Palau&quot;],&quot;__typename&quot;:&quot;AddressZone&quot;},{&quot;code&quot;:&quot;PA&quot;,&quot;name&quot;:&quot;Pennsylvania&quot;,&quot;nameWithAlternates&quot;:[&quot;Pennsylvania&quot;],&quot;__typename&quot;:&quot;AddressZone&quot;},{&quot;code&quot;:&quot;PR&quot;,&quot;name&quot;:&quot;Puerto Rico&quot;,&quot;nameWithAlternates&quot;:[&quot;Puerto Rico&quot;],&quot;__typename&quot;:&quot;AddressZone&quot;},{&quot;code&quot;:&quot;RI&quot;,&quot;name&quot;:&quot;Rhode Island&quot;,&quot;nameWithAlternates&quot;:[&quot;Rhode Island&quot;],&quot;__typename&quot;:&quot;AddressZone&quot;},{&quot;code&quot;:&quot;SC&quot;,&quot;name&quot;:&quot;South Carolina&quot;,&quot;nameWithAlternates&quot;:[&quot;South Carolina&quot;],&quot;__typename&quot;:&quot;AddressZone&quot;},{&quot;code&quot;:&quot;SD&quot;,&quot;name&quot;:&quot;South Dakota&quot;,&quot;nameWithAlternates&quot;:[&quot;South Dakota&quot;],&quot;__typename&quot;:&quot;AddressZone&quot;},{&quot;code&quot;:&quot;TN&quot;,&quot;name&quot;:&quot;Tennessee&quot;,&quot;nameWithAlternates&quot;:[&quot;Tennessee&quot;],&quot;__typename&quot;:&quot;AddressZone&quot;},{&quot;code&quot;:&quot;TX&quot;,&quot;name&quot;:&quot;Texas&quot;,&quot;nameWithAlternates&quot;:[&quot;Texas&quot;],&quot;__typename&quot;:&quot;AddressZone&quot;},{&quot;code&quot;:&quot;UT&quot;,&quot;name&quot;:&quot;Utah&quot;,&quot;nameWithAlternates&quot;:[&quot;Utah&quot;],&quot;__typename&quot;:&quot;AddressZone&quot;},{&quot;code&quot;:&quot;VT&quot;,&quot;name&quot;:&quot;Vermont&quot;,&quot;nameWithAlternates&quot;:[&quot;Vermont&quot;],&quot;__typename&quot;:&quot;AddressZone&quot;},{&quot;code&quot;:&quot;VA&quot;,&quot;name&quot;:&quot;Virginia&quot;,&quot;nameWithAlternates&quot;:[&quot;Virginia&quot;],&quot;__typename&quot;:&quot;AddressZone&quot;},{&quot;code&quot;:&quot;WA&quot;,&quot;name&quot;:&quot;Washington&quot;,&quot;nameWithAlternates&quot;:[&quot;Washington&quot;],&quot;__typename&quot;:&quot;AddressZone&quot;},{&quot;code&quot;:&quot;DC&quot;,&quot;name&quot;:&quot;Washington DC&quot;,&quot;nameWithAlternates&quot;:[&quot;District of Columbia&quot;,&quot;Washington DC&quot;],&quot;__typename&quot;:&quot;AddressZone&quot;},{&quot;code&quot;:&quot;WV&quot;,&quot;name&quot;:&quot;West Virginia&quot;,&quot;nameWithAlternates&quot;:[&quot;West Virginia&quot;],&quot;__typename&quot;:&quot;AddressZone&quot;},{&quot;code&quot;:&quot;WI&quot;,&quot;name&quot;:&quot;Wisconsin&quot;,&quot;nameWithAlternates&quot;:[&quot;Wisconsin&quot;],&quot;__typename&quot;:&quot;AddressZone&quot;},{&quot;code&quot;:&quot;WY&quot;,&quot;name&quot;:&quot;Wyoming&quot;,&quot;nameWithAlternates&quot;:[&quot;Wyoming&quot;],&quot;__typename&quot;:&quot;AddressZone&quot;},{&quot;code&quot;:&quot;VI&quot;,&quot;name&quot;:&quot;U.S. Virgin Islands&quot;,&quot;nameWithAlternates&quot;:[&quot;Virgin Islands&quot;,&quot;U.S. Virgin Islands&quot;],&quot;__typename&quot;:&quot;AddressZone&quot;},{&quot;code&quot;:&quot;AA&quot;,&quot;name&quot;:&quot;Armed Forces Americas&quot;,&quot;nameWithAlternates&quot;:[&quot;Armed Forces Americas&quot;],&quot;__typename&quot;:&quot;AddressZone&quot;},{&quot;code&quot;:&quot;AE&quot;,&quot;name&quot;:&quot;Armed Forces Europe&quot;,&quot;nameWithAlternates&quot;:[&quot;Armed Forces Europe&quot;],&quot;__typename&quot;:&quot;AddressZone&quot;},{&quot;code&quot;:&quot;AP&quot;,&quot;name&quot;:&quot;Armed Forces Pacific&quot;,&quot;nameWithAlternates&quot;:[&quot;Armed Forces Pacific&quot;],&quot;__typename&quot;:&quot;AddressZone&quot;}],&quot;formatting&quot;:{&quot;edit&quot;:&quot;{country}_{firstName}{lastName}_{company}_{address1}_{address2}_{city}{province}{zip}_{phone}&quot;,&quot;show&quot;:&quot;{firstName} {lastName}_{company}_{address1}_{address2}_{city} {province} {zip}_{country}_{phone}&quot;,&quot;__typename&quot;:&quot;AddressFormat&quot;},&quot;extendedFormatting&quot;:null,&quot;autocompletionField&quot;:&quot;ADDRESS1&quot;,&quot;neighborhoodRequired&quot;:false,&quot;streetNumberRequired&quot;:false,&quot;buildingNumberRequired&quot;:true,&quot;buildingNumberMayBeInAddress2&quot;:false,&quot;pureNumericPostalCode&quot;:false,&quot;postalCodeRequired&quot;:true,&quot;__typename&quot;:&quot;Country&quot;},&quot;zone&quot;:{&quot;code&quot;:&quot;CA&quot;,&quot;__typename&quot;:&quot;AddressZone&quot;},&quot;__typename&quot;:&quot;DefaultShippingDetails&quot;},&quot;remoteShopConfigurations&quot;:[],&quot;paymentMethodAutoSelectionDisabled&quot;:false,&quot;__typename&quot;:&quot;CheckoutShopConfig&quot;},&quot;httpRequestInfo&quot;:{&quot;locale&quot;:&quot;en-US&quot;,&quot;localeDirection&quot;:&quot;ltr&quot;,&quot;geolocation&quot;:{&quot;country&quot;:{&quot;code&quot;:&quot;US&quot;,&quot;name&quot;:&quot;United States&quot;,&quot;localizationKeys&quot;:{&quot;address2&quot;:null,&quot;postalCode&quot;:&quot;zip_code_label&quot;,&quot;zone&quot;:&quot;state_label&quot;,&quot;neighborhood&quot;:null,&quot;__typename&quot;:&quot;AddressLocalizationKeys&quot;},&quot;labels&quot;:{&quot;firstName&quot;:&quot;First name&quot;,&quot;lastName&quot;:&quot;Last name&quot;,&quot;company&quot;:&quot;Company&quot;,&quot;address1&quot;:&quot;Address&quot;,&quot;address2&quot;:&quot;Apartment, suite, etc&quot;,&quot;city&quot;:&quot;City&quot;,&quot;country&quot;:&quot;Country/region&quot;,&quot;zone&quot;:&quot;State&quot;,&quot;postalCode&quot;:&quot;ZIP code&quot;,&quot;phone&quot;:&quot;Phone&quot;,&quot;__typename&quot;:&quot;AddressLabels&quot;},&quot;zones&quot;:[{&quot;code&quot;:&quot;AL&quot;,&quot;name&quot;:&quot;Alabama&quot;,&quot;nameWithAlternates&quot;:[&quot;Alabama&quot;],&quot;__typename&quot;:&quot;AddressZone&quot;},{&quot;code&quot;:&quot;AK&quot;,&quot;name&quot;:&quot;Alaska&quot;,&quot;nameWithAlternates&quot;:[&quot;Alaska&quot;],&quot;__typename&quot;:&quot;AddressZone&quot;},{&quot;code&quot;:&quot;AS&quot;,&quot;name&quot;:&quot;American Samoa&quot;,&quot;nameWithAlternates&quot;:[&quot;American Samoa&quot;],&quot;__typename&quot;:&quot;AddressZone&quot;},{&quot;code&quot;:&quot;AZ&quot;,&quot;name&quot;:&quot;Arizona&quot;,&quot;nameWithAlternates&quot;:[&quot;Arizona&quot;],&quot;__typename&quot;:&quot;AddressZone&quot;},{&quot;code&quot;:&quot;AR&quot;,&quot;name&quot;:&quot;Arkansas&quot;,&quot;nameWithAlternates&quot;:[&quot;Arkansas&quot;],&quot;__typename&quot;:&quot;AddressZone&quot;},{&quot;code&quot;:&quot;CA&quot;,&quot;name&quot;:&quot;California&quot;,&quot;nameWithAlternates&quot;:[&quot;California&quot;],&quot;__typename&quot;:&quot;AddressZone&quot;},{&quot;code&quot;:&quot;CO&quot;,&quot;name&quot;:&quot;Colorado&quot;,&quot;nameWithAlternates&quot;:[&quot;Colorado&quot;],&quot;__typename&quot;:&quot;AddressZone&quot;},{&quot;code&quot;:&quot;CT&quot;,&quot;name&quot;:&quot;Connecticut&quot;,&quot;nameWithAlternates&quot;:[&quot;Connecticut&quot;],&quot;__typename&quot;:&quot;AddressZone&quot;},{&quot;code&quot;:&quot;DE&quot;,&quot;name&quot;:&quot;Delaware&quot;,&quot;nameWithAlternates&quot;:[&quot;Delaware&quot;],&quot;__typename&quot;:&quot;AddressZone&quot;},{&quot;code&quot;:&quot;FM&quot;,&quot;name&quot;:&quot;Micronesia&quot;,&quot;nameWithAlternates&quot;:[&quot;Federated States of Micronesia&quot;,&quot;Micronesia&quot;],&quot;__typename&quot;:&quot;AddressZone&quot;},{&quot;code&quot;:&quot;FL&quot;,&quot;name&quot;:&quot;Florida&quot;,&quot;nameWithAlternates&quot;:[&quot;Florida&quot;],&quot;__typename&quot;:&quot;AddressZone&quot;},{&quot;code&quot;:&quot;GA&quot;,&quot;name&quot;:&quot;Georgia&quot;,&quot;nameWithAlternates&quot;:[&quot;Georgia&quot;],&quot;__typename&quot;:&quot;AddressZone&quot;},{&quot;code&quot;:&quot;GU&quot;,&quot;name&quot;:&quot;Guam&quot;,&quot;nameWithAlternates&quot;:[&quot;Guam&quot;],&quot;__typename&quot;:&quot;AddressZone&quot;},{&quot;code&quot;:&quot;HI&quot;,&quot;name&quot;:&quot;Hawaii&quot;,&quot;nameWithAlternates&quot;:[&quot;Hawaii&quot;],&quot;__typename&quot;:&quot;AddressZone&quot;},{&quot;code&quot;:&quot;ID&quot;,&quot;name&quot;:&quot;Idaho&quot;,&quot;nameWithAlternates&quot;:[&quot;Idaho&quot;],&quot;__typename&quot;:&quot;AddressZone&quot;},{&quot;code&quot;:&quot;IL&quot;,&quot;name&quot;:&quot;Illinois&quot;,&quot;nameWithAlternates&quot;:[&quot;Illinois&quot;],&quot;__typename&quot;:&quot;AddressZone&quot;},{&quot;code&quot;:&quot;IN&quot;,&quot;name&quot;:&quot;Indiana&quot;,&quot;nameWithAlternates&quot;:[&quot;Indiana&quot;],&quot;__typename&quot;:&quot;AddressZone&quot;},{&quot;code&quot;:&quot;IA&quot;,&quot;name&quot;:&quot;Iowa&quot;,&quot;nameWithAlternates&quot;:[&quot;Iowa&quot;],&quot;__typename&quot;:&quot;AddressZone&quot;},{&quot;code&quot;:&quot;KS&quot;,&quot;name&quot;:&quot;Kansas&quot;,&quot;nameWithAlternates&quot;:[&quot;Kansas&quot;],&quot;__typename&quot;:&quot;AddressZone&quot;},{&quot;code&quot;:&quot;KY&quot;,&quot;name&quot;:&quot;Kentucky&quot;,&quot;nameWithAlternates&quot;:[&quot;Kentucky&quot;],&quot;__typename&quot;:&quot;AddressZone&quot;},{&quot;code&quot;:&quot;LA&quot;,&quot;name&quot;:&quot;Louisiana&quot;,&quot;nameWithAlternates&quot;:[&quot;Louisiana&quot;],&quot;__typename&quot;:&quot;AddressZone&quot;},{&quot;code&quot;:&quot;ME&quot;,&quot;name&quot;:&quot;Maine&quot;,&quot;nameWithAlternates&quot;:[&quot;Maine&quot;],&quot;__typename&quot;:&quot;AddressZone&quot;},{&quot;code&quot;:&quot;MH&quot;,&quot;name&quot;:&quot;Marshall Islands&quot;,&quot;nameWithAlternates&quot;:[&quot;Marshall Islands&quot;],&quot;__typename&quot;:&quot;AddressZone&quot;},{&quot;code&quot;:&quot;MD&quot;,&quot;name&quot;:&quot;Maryland&quot;,&quot;nameWithAlternates&quot;:[&quot;Maryland&quot;],&quot;__typename&quot;:&quot;AddressZone&quot;},{&quot;code&quot;:&quot;MA&quot;,&quot;name&quot;:&quot;Massachusetts&quot;,&quot;nameWithAlternates&quot;:[&quot;Massachusetts&quot;],&quot;__typename&quot;:&quot;AddressZone&quot;},{&quot;code&quot;:&quot;MI&quot;,&quot;name&quot;:&quot;Michigan&quot;,&quot;nameWithAlternates&quot;:[&quot;Michigan&quot;],&quot;__typename&quot;:&quot;AddressZone&quot;},{&quot;code&quot;:&quot;MN&quot;,&quot;name&quot;:&quot;Minnesota&quot;,&quot;nameWithAlternates&quot;:[&quot;Minnesota&quot;],&quot;__typename&quot;:&quot;AddressZone&quot;},{&quot;code&quot;:&quot;MS&quot;,&quot;name&quot;:&quot;Mississippi&quot;,&quot;nameWithAlternates&quot;:[&quot;Mississippi&quot;],&quot;__typename&quot;:&quot;AddressZone&quot;},{&quot;code&quot;:&quot;MO&quot;,&quot;name&quot;:&quot;Missouri&quot;,&quot;nameWithAlternates&quot;:[&quot;Missouri&quot;],&quot;__typename&quot;:&quot;AddressZone&quot;},{&quot;code&quot;:&quot;MT&quot;,&quot;name&quot;:&quot;Montana&quot;,&quot;nameWithAlternates&quot;:[&quot;Montana&quot;],&quot;__typename&quot;:&quot;AddressZone&quot;},{&quot;code&quot;:&quot;NE&quot;,&quot;name&quot;:&quot;Nebraska&quot;,&quot;nameWithAlternates&quot;:[&quot;Nebraska&quot;],&quot;__typename&quot;:&quot;AddressZone&quot;},{&quot;code&quot;:&quot;NV&quot;,&quot;name&quot;:&quot;Nevada&quot;,&quot;nameWithAlternates&quot;:[&quot;Nevada&quot;],&quot;__typename&quot;:&quot;AddressZone&quot;},{&quot;code&quot;:&quot;NH&quot;,&quot;name&quot;:&quot;New Hampshire&quot;,&quot;nameWithAlternates&quot;:[&quot;New Hampshire&quot;],&quot;__typename&quot;:&quot;AddressZone&quot;},{&quot;code&quot;:&quot;NJ&quot;,&quot;name&quot;:&quot;New Jersey&quot;,&quot;nameWithAlternates&quot;:[&quot;New Jersey&quot;],&quot;__typename&quot;:&quot;AddressZone&quot;},{&quot;code&quot;:&quot;NM&quot;,&quot;name&quot;:&quot;New Mexico&quot;,&quot;nameWithAlternates&quot;:[&quot;New Mexico&quot;],&quot;__typename&quot;:&quot;AddressZone&quot;},{&quot;code&quot;:&quot;NY&quot;,&quot;name&quot;:&quot;New York&quot;,&quot;nameWithAlternates&quot;:[&quot;New York&quot;],&quot;__typename&quot;:&quot;AddressZone&quot;},{&quot;code&quot;:&quot;NC&quot;,&quot;name&quot;:&quot;North Carolina&quot;,&quot;nameWithAlternates&quot;:[&quot;North Carolina&quot;],&quot;__typename&quot;:&quot;AddressZone&quot;},{&quot;code&quot;:&quot;ND&quot;,&quot;name&quot;:&quot;North Dakota&quot;,&quot;nameWithAlternates&quot;:[&quot;North Dakota&quot;],&quot;__typename&quot;:&quot;AddressZone&quot;},{&quot;code&quot;:&quot;MP&quot;,&quot;name&quot;:&quot;Northern Mariana Islands&quot;,&quot;nameWithAlternates&quot;:[&quot;Northern Mariana Islands&quot;],&quot;__typename&quot;:&quot;AddressZone&quot;},{&quot;code&quot;:&quot;OH&quot;,&quot;name&quot;:&quot;Ohio&quot;,&quot;nameWithAlternates&quot;:[&quot;Ohio&quot;],&quot;__typename&quot;:&quot;AddressZone&quot;},{&quot;code&quot;:&quot;OK&quot;,&quot;name&quot;:&quot;Oklahoma&quot;,&quot;nameWithAlternates&quot;:[&quot;Oklahoma&quot;],&quot;__typename&quot;:&quot;AddressZone&quot;},{&quot;code&quot;:&quot;OR&quot;,&quot;name&quot;:&quot;Oregon&quot;,&quot;nameWithAlternates&quot;:[&quot;Oregon&quot;],&quot;__typename&quot;:&quot;AddressZone&quot;},{&quot;code&quot;:&quot;PW&quot;,&quot;name&quot;:&quot;Palau&quot;,&quot;nameWithAlternates&quot;:[&quot;Palau&quot;],&quot;__typename&quot;:&quot;AddressZone&quot;},{&quot;code&quot;:&quot;PA&quot;,&quot;name&quot;:&quot;Pennsylvania&quot;,&quot;nameWithAlternates&quot;:[&quot;Pennsylvania&quot;],&quot;__typename&quot;:&quot;AddressZone&quot;},{&quot;code&quot;:&quot;PR&quot;,&quot;name&quot;:&quot;Puerto Rico&quot;,&quot;nameWithAlternates&quot;:[&quot;Puerto Rico&quot;],&quot;__typename&quot;:&quot;AddressZone&quot;},{&quot;code&quot;:&quot;RI&quot;,&quot;name&quot;:&quot;Rhode Island&quot;,&quot;nameWithAlternates&quot;:[&quot;Rhode Island&quot;],&quot;__typename&quot;:&quot;AddressZone&quot;},{&quot;code&quot;:&quot;SC&quot;,&quot;name&quot;:&quot;South Carolina&quot;,&quot;nameWithAlternates&quot;:[&quot;South Carolina&quot;],&quot;__typename&quot;:&quot;AddressZone&quot;},{&quot;code&quot;:&quot;SD&quot;,&quot;name&quot;:&quot;South Dakota&quot;,&quot;nameWithAlternates&quot;:[&quot;South Dakota&quot;],&quot;__typename&quot;:&quot;AddressZone&quot;},{&quot;code&quot;:&quot;TN&quot;,&quot;name&quot;:&quot;Tennessee&quot;,&quot;nameWithAlternates&quot;:[&quot;Tennessee&quot;],&quot;__typename&quot;:&quot;AddressZone&quot;},{&quot;code&quot;:&quot;TX&quot;,&quot;name&quot;:&quot;Texas&quot;,&quot;nameWithAlternates&quot;:[&quot;Texas&quot;],&quot;__typename&quot;:&quot;AddressZone&quot;},{&quot;code&quot;:&quot;UT&quot;,&quot;name&quot;:&quot;Utah&quot;,&quot;nameWithAlternates&quot;:[&quot;Utah&quot;],&quot;__typename&quot;:&quot;AddressZone&quot;},{&quot;code&quot;:&quot;VT&quot;,&quot;name&quot;:&quot;Vermont&quot;,&quot;nameWithAlternates&quot;:[&quot;Vermont&quot;],&quot;__typename&quot;:&quot;AddressZone&quot;},{&quot;code&quot;:&quot;VA&quot;,&quot;name&quot;:&quot;Virginia&quot;,&quot;nameWithAlternates&quot;:[&quot;Virginia&quot;],&quot;__typename&quot;:&quot;AddressZone&quot;},{&quot;code&quot;:&quot;WA&quot;,&quot;name&quot;:&quot;Washington&quot;,&quot;nameWithAlternates&quot;:[&quot;Washington&quot;],&quot;__typename&quot;:&quot;AddressZone&quot;},{&quot;code&quot;:&quot;DC&quot;,&quot;name&quot;:&quot;Washington DC&quot;,&quot;nameWithAlternates&quot;:[&quot;District of Columbia&quot;,&quot;Washington DC&quot;],&quot;__typename&quot;:&quot;AddressZone&quot;},{&quot;code&quot;:&quot;WV&quot;,&quot;name&quot;:&quot;West Virginia&quot;,&quot;nameWithAlternates&quot;:[&quot;West Virginia&quot;],&quot;__typename&quot;:&quot;AddressZone&quot;},{&quot;code&quot;:&quot;WI&quot;,&quot;name&quot;:&quot;Wisconsin&quot;,&quot;nameWithAlternates&quot;:[&quot;Wisconsin&quot;],&quot;__typename&quot;:&quot;AddressZone&quot;},{&quot;code&quot;:&quot;WY&quot;,&quot;name&quot;:&quot;Wyoming&quot;,&quot;nameWithAlternates&quot;:[&quot;Wyoming&quot;],&quot;__typename&quot;:&quot;AddressZone&quot;},{&quot;code&quot;:&quot;VI&quot;,&quot;name&quot;:&quot;U.S. Virgin Islands&quot;,&quot;nameWithAlternates&quot;:[&quot;Virgin Islands&quot;,&quot;U.S. Virgin Islands&quot;],&quot;__typename&quot;:&quot;AddressZone&quot;},{&quot;code&quot;:&quot;AA&quot;,&quot;name&quot;:&quot;Armed Forces Americas&quot;,&quot;nameWithAlternates&quot;:[&quot;Armed Forces Americas&quot;],&quot;__typename&quot;:&quot;AddressZone&quot;},{&quot;code&quot;:&quot;AE&quot;,&quot;name&quot;:&quot;Armed Forces Europe&quot;,&quot;nameWithAlternates&quot;:[&quot;Armed Forces Europe&quot;],&quot;__typename&quot;:&quot;AddressZone&quot;},{&quot;code&quot;:&quot;AP&quot;,&quot;name&quot;:&quot;Armed Forces Pacific&quot;,&quot;nameWithAlternates&quot;:[&quot;Armed Forces Pacific&quot;],&quot;__typename&quot;:&quot;AddressZone&quot;}],&quot;formatting&quot;:{&quot;edit&quot;:&quot;{country}_{firstName}{lastName}_{company}_{address1}_{address2}_{city}{province}{zip}_{phone}&quot;,&quot;show&quot;:&quot;{firstName} {lastName}_{company}_{address1}_{address2}_{city} {province} {zip}_{country}_{phone}&quot;,&quot;__typename&quot;:&quot;AddressFormat&quot;},&quot;extendedFormatting&quot;:null,&quot;autocompletionField&quot;:&quot;ADDRESS1&quot;,&quot;neighborhoodRequired&quot;:false,&quot;streetNumberRequired&quot;:false,&quot;buildingNumberRequired&quot;:true,&quot;buildingNumberMayBeInAddress2&quot;:false,&quot;pureNumericPostalCode&quot;:false,&quot;postalCodeRequired&quot;:true,&quot;__typename&quot;:&quot;Country&quot;},&quot;zone&quot;:{&quot;code&quot;:&quot;CA&quot;,&quot;name&quot;:&quot;California&quot;,&quot;__typename&quot;:&quot;AddressZone&quot;},&quot;coordinates&quot;:{&quot;latitude&quot;:34.0481,&quot;longitude&quot;:-118.2531,&quot;__typename&quot;:&quot;GeographicalCoordinates&quot;},&quot;__typename&quot;:&quot;Geolocation&quot;},&quot;__typename&quot;:&quot;HttpRequestInfo&quot;},&quot;mobileCheckoutSdkConfig&quot;:{&quot;checkoutAuthenticationResult&quot;:null,&quot;colorScheme&quot;:&quot;LIGHT&quot;,&quot;version&quot;:null,&quot;schema&quot;:null,&quot;variant&quot;:null,&quot;suppressPixels&quot;:true,&quot;__typename&quot;:&quot;MobileCheckoutSdkConfig&quot;},&quot;checkoutSheetProtocolConfig&quot;:null,&quot;embed&quot;:null},&quot;657baeffb5e8b64f2180ad7a7a66462976d92d5e9179baa3a58d31a3eaabf362{}&quot;:{&quot;shop&quot;:{&quot;hostedFieldsUrl&quot;:&quot;https://checkout.pci.shopifyinc.com/dist/card_fields.js&quot;,&quot;domain&quot;:&quot;example.myshopify.com&quot;,&quot;name&quot;:&quot;example&quot;,&quot;id&quot;:&quot;gid://shopify/Shop/2442&quot;,&quot;allowExtensionDevelopment&quot;:true,&quot;storefrontDomains&quot;:[&quot;example.myshopify.com&quot;,&quot;example.account.myshopify.com&quot;],&quot;merchantPolicies&quot;:[],&quot;country&quot;:{&quot;code&quot;:&quot;CA&quot;,&quot;name&quot;:&quot;Canada&quot;,&quot;localizationKeys&quot;:{&quot;address2&quot;:&quot;apt_unit_number_label&quot;,&quot;postalCode&quot;:null,&quot;zone&quot;:&quot;province_label&quot;,&quot;neighborhood&quot;:null,&quot;__typename&quot;:&quot;AddressLocalizationKeys&quot;},&quot;labels&quot;:{&quot;firstName&quot;:&quot;First name&quot;,&quot;lastName&quot;:&quot;Last name&quot;,&quot;company&quot;:&quot;Company&quot;,&quot;address1&quot;:&quot;Address&quot;,&quot;address2&quot;:&quot;Apartment, suite, etc&quot;,&quot;city&quot;:&quot;City&quot;,&quot;country&quot;:&quot;Country/region&quot;,&quot;zone&quot;:&quot;Province&quot;,&quot;postalCode&quot;:&quot;Postal code&quot;,&quot;phone&quot;:&quot;Phone&quot;,&quot;__typename&quot;:&quot;AddressLabels&quot;},&quot;zones&quot;:[{&quot;code&quot;:&quot;AB&quot;,&quot;name&quot;:&quot;Alberta&quot;,&quot;nameWithAlternates&quot;:[&quot;Alberta&quot;],&quot;__typename&quot;:&quot;AddressZone&quot;},{&quot;code&quot;:&quot;BC&quot;,&quot;name&quot;:&quot;British Columbia&quot;,&quot;nameWithAlternates&quot;:[&quot;British Columbia&quot;],&quot;__typename&quot;:&quot;AddressZone&quot;},{&quot;code&quot;:&quot;MB&quot;,&quot;name&quot;:&quot;Manitoba&quot;,&quot;nameWithAlternates&quot;:[&quot;Manitoba&quot;],&quot;__typename&quot;:&quot;AddressZone&quot;},{&quot;code&quot;:&quot;NB&quot;,&quot;name&quot;:&quot;New Brunswick&quot;,&quot;nameWithAlternates&quot;:[&quot;New Brunswick&quot;],&quot;__typename&quot;:&quot;AddressZone&quot;},{&quot;code&quot;:&quot;NL&quot;,&quot;name&quot;:&quot;Newfoundland and Labrador&quot;,&quot;nameWithAlternates&quot;:[&quot;Newfoundland and Labrador&quot;,&quot;Newfoundland&quot;],&quot;__typename&quot;:&quot;AddressZone&quot;},{&quot;code&quot;:&quot;NT&quot;,&quot;name&quot;:&quot;Northwest Territories&quot;,&quot;nameWithAlternates&quot;:[&quot;Northwest Territories&quot;],&quot;__typename&quot;:&quot;AddressZone&quot;},{&quot;code&quot;:&quot;NS&quot;,&quot;name&quot;:&quot;Nova Scotia&quot;,&quot;nameWithAlternates&quot;:[&quot;Nova Scotia&quot;],&quot;__typename&quot;:&quot;AddressZone&quot;},{&quot;code&quot;:&quot;NU&quot;,&quot;name&quot;:&quot;Nunavut&quot;,&quot;nameWithAlternates&quot;:[&quot;Nunavut&quot;],&quot;__typename&quot;:&quot;AddressZone&quot;},{&quot;code&quot;:&quot;ON&quot;,&quot;name&quot;:&quot;Ontario&quot;,&quot;nameWithAlternates&quot;:[&quot;Ontario&quot;],&quot;__typename&quot;:&quot;AddressZone&quot;},{&quot;code&quot;:&quot;PE&quot;,&quot;name&quot;:&quot;Prince Edward Island&quot;,&quot;nameWithAlternates&quot;:[&quot;Prince Edward Island&quot;],&quot;__typename&quot;:&quot;AddressZone&quot;},{&quot;code&quot;:&quot;QC&quot;,&quot;name&quot;:&quot;Quebec&quot;,&quot;nameWithAlternates&quot;:[&quot;Quebec&quot;,&quot;Québec&quot;],&quot;__typename&quot;:&quot;AddressZone&quot;},{&quot;code&quot;:&quot;SK&quot;,&quot;name&quot;:&quot;Saskatchewan&quot;,&quot;nameWithAlternates&quot;:[&quot;Saskatchewan&quot;],&quot;__typename&quot;:&quot;AddressZone&quot;},{&quot;code&quot;:&quot;YT&quot;,&quot;name&quot;:&quot;Yukon&quot;,&quot;nameWithAlternates&quot;:[&quot;Yukon&quot;],&quot;__typename&quot;:&quot;AddressZone&quot;}],&quot;formatting&quot;:{&quot;edit&quot;:&quot;{country}_{firstName}{lastName}_{company}_{address1}_{address2}_{city}{province}{zip}_{phone}&quot;,&quot;show&quot;:&quot;{firstName} {lastName}_{company}_{address1}_{address2}_{city} {province} {zip}_{country}_{phone}&quot;,&quot;__typename&quot;:&quot;AddressFormat&quot;},&quot;extendedFormatting&quot;:null,&quot;autocompletionField&quot;:&quot;ADDRESS1&quot;,&quot;neighborhoodRequired&quot;:false,&quot;streetNumberRequired&quot;:false,&quot;buildingNumberRequired&quot;:true,&quot;buildingNumberMayBeInAddress2&quot;:false,&quot;pureNumericPostalCode&quot;:false,&quot;postalCodeRequired&quot;:true,&quot;__typename&quot;:&quot;Country&quot;},&quot;billingCountries&quot;:[{&quot;value&quot;:&quot;AF&quot;,&quot;label&quot;:&quot;Afghanistan&quot;,&quot;__typename&quot;:&quot;Country&quot;},{&quot;value&quot;:&quot;AX&quot;,&quot;label&quot;:&quot;Åland Islands&quot;,&quot;__typename&quot;:&quot;Country&quot;},{&quot;value&quot;:&quot;AL&quot;,&quot;label&quot;:&quot;Albania&quot;,&quot;__typename&quot;:&quot;Country&quot;},{&quot;value&quot;:&quot;DZ&quot;,&quot;label&quot;:&quot;Algeria&quot;,&quot;__typename&quot;:&quot;Country&quot;},{&quot;value&quot;:&quot;AD&quot;,&quot;label&quot;:&quot;Andorra&quot;,&quot;__typename&quot;:&quot;Country&quot;},{&quot;value&quot;:&quot;AO&quot;,&quot;label&quot;:&quot;Angola&quot;,&quot;__typename&quot;:&quot;Country&quot;},{&quot;value&quot;:&quot;AI&quot;,&quot;label&quot;:&quot;Anguilla&quot;,&quot;__typename&quot;:&quot;Country&quot;},{&quot;value&quot;:&quot;AG&quot;,&quot;label&quot;:&quot;Antigua &amp; Barbuda&quot;,&quot;__typename&quot;:&quot;Country&quot;},{&quot;value&quot;:&quot;AR&quot;,&quot;label&quot;:&quot;Argentina&quot;,&quot;__typename&quot;:&quot;Country&quot;},{&quot;value&quot;:&quot;AM&quot;,&quot;label&quot;:&quot;Armenia&quot;,&quot;__typename&quot;:&quot;Country&quot;},{&quot;value&quot;:&quot;AW&quot;,&quot;label&quot;:&quot;Aruba&quot;,&quot;__typename&quot;:&quot;Country&quot;},{&quot;value&quot;:&quot;AC&quot;,&quot;label&quot;:&quot;Ascension Island&quot;,&quot;__typename&quot;:&quot;Country&quot;},{&quot;value&quot;:&quot;AU&quot;,&quot;label&quot;:&quot;Australia&quot;,&quot;__typename&quot;:&quot;Country&quot;},{&quot;value&quot;:&quot;AT&quot;,&quot;label&quot;:&quot;Austria&quot;,&quot;__typename&quot;:&quot;Country&quot;},{&quot;value&quot;:&quot;AZ&quot;,&quot;label&quot;:&quot;Azerbaijan&quot;,&quot;__typename&quot;:&quot;Country&quot;},{&quot;value&quot;:&quot;BS&quot;,&quot;label&quot;:&quot;Bahamas&quot;,&quot;__typename&quot;:&quot;Country&quot;},{&quot;value&quot;:&quot;BH&quot;,&quot;label&quot;:&quot;Bahrain&quot;,&quot;__typename&quot;:&quot;Country&quot;},{&quot;value&quot;:&quot;BD&quot;,&quot;label&quot;:&quot;Bangladesh&quot;,&quot;__typename&quot;:&quot;Country&quot;},{&quot;value&quot;:&quot;BB&quot;,&quot;label&quot;:&quot;Barbados&quot;,&quot;__typename&quot;:&quot;Country&quot;},{&quot;value&quot;:&quot;BY&quot;,&quot;label&quot;:&quot;Belarus&quot;,&quot;__typename&quot;:&quot;Country&quot;},{&quot;value&quot;:&quot;BE&quot;,&quot;label&quot;:&quot;Belgium&quot;,&quot;__typename&quot;:&quot;Country&quot;},{&quot;value&quot;:&quot;BZ&quot;,&quot;label&quot;:&quot;Belize&quot;,&quot;__typename&quot;:&quot;Country&quot;},{&quot;value&quot;:&quot;BJ&quot;,&quot;label&quot;:&quot;Benin&quot;,&quot;__typename&quot;:&quot;Country&quot;},{&quot;value&quot;:&quot;BM&quot;,&quot;label&quot;:&quot;Bermuda&quot;,&quot;__typename&quot;:&quot;Country&quot;},{&quot;value&quot;:&quot;BT&quot;,&quot;label&quot;:&quot;Bhutan&quot;,&quot;__typename&quot;:&quot;Country&quot;},{&quot;value&quot;:&quot;BO&quot;,&quot;label&quot;:&quot;Bolivia&quot;,&quot;__typename&quot;:&quot;Country&quot;},{&quot;value&quot;:&quot;BA&quot;,&quot;label&quot;:&quot;Bosnia &amp; Herzegovina&quot;,&quot;__typename&quot;:&quot;Country&quot;},{&quot;value&quot;:&quot;BW&quot;,&quot;label&quot;:&quot;Botswana&quot;,&quot;__typename&quot;:&quot;Country&quot;},{&quot;value&quot;:&quot;BR&quot;,&quot;label&quot;:&quot;Brazil&quot;,&quot;__typename&quot;:&quot;Country&quot;},{&quot;value&quot;:&quot;IO&quot;,&quot;label&quot;:&quot;British Indian Ocean Territory&quot;,&quot;__typename&quot;:&quot;Country&quot;},{&quot;value&quot;:&quot;VG&quot;,&quot;label&quot;:&quot;British Virgin Islands&quot;,&quot;__typename&quot;:&quot;Country&quot;},{&quot;value&quot;:&quot;BN&quot;,&quot;label&quot;:&quot;Brunei&quot;,&quot;__typename&quot;:&quot;Country&quot;},{&quot;value&quot;:&quot;BG&quot;,&quot;label&quot;:&quot;Bulgaria&quot;,&quot;__typename&quot;:&quot;Country&quot;},{&quot;value&quot;:&quot;BF&quot;,&quot;label&quot;:&quot;Burkina Faso&quot;,&quot;__typename&quot;:&quot;Country&quot;},{&quot;value&quot;:&quot;BI&quot;,&quot;label&quot;:&quot;Burundi&quot;,&quot;__typename&quot;:&quot;Country&quot;},{&quot;value&quot;:&quot;KH&quot;,&quot;label&quot;:&quot;Cambodia&quot;,&quot;__typename&quot;:&quot;Country&quot;},{&quot;value&quot;:&quot;CM&quot;,&quot;label&quot;:&quot;Cameroon&quot;,&quot;__typename&quot;:&quot;Country&quot;},{&quot;value&quot;:&quot;CA&quot;,&quot;label&quot;:&quot;Canada&quot;,&quot;__typename&quot;:&quot;Country&quot;},{&quot;value&quot;:&quot;CV&quot;,&quot;label&quot;:&quot;Cape Verde&quot;,&quot;__typename&quot;:&quot;Country&quot;},{&quot;value&quot;:&quot;BQ&quot;,&quot;label&quot;:&quot;Caribbean Netherlands&quot;,&quot;__typename&quot;:&quot;Country&quot;},{&quot;value&quot;:&quot;KY&quot;,&quot;label&quot;:&quot;Cayman Islands&quot;,&quot;__typename&quot;:&quot;Country&quot;},{&quot;value&quot;:&quot;CF&quot;,&quot;label&quot;:&quot;Central African Republic&quot;,&quot;__typename&quot;:&quot;Country&quot;},{&quot;value&quot;:&quot;TD&quot;,&quot;label&quot;:&quot;Chad&quot;,&quot;__typename&quot;:&quot;Country&quot;},{&quot;value&quot;:&quot;CL&quot;,&quot;label&quot;:&quot;Chile&quot;,&quot;__typename&quot;:&quot;Country&quot;},{&quot;value&quot;:&quot;CN&quot;,&quot;label&quot;:&quot;China&quot;,&quot;__typename&quot;:&quot;Country&quot;},{&quot;value&quot;:&quot;CX&quot;,&quot;label&quot;:&quot;Christmas Island&quot;,&quot;__typename&quot;:&quot;Country&quot;},{&quot;value&quot;:&quot;CC&quot;,&quot;label&quot;:&quot;Cocos (Keeling) Islands&quot;,&quot;__typename&quot;:&quot;Country&quot;},{&quot;value&quot;:&quot;CO&quot;,&quot;label&quot;:&quot;Colombia&quot;,&quot;__typename&quot;:&quot;Country&quot;},{&quot;value&quot;:&quot;KM&quot;,&quot;label&quot;:&quot;Comoros&quot;,&quot;__typename&quot;:&quot;Country&quot;},{&quot;value&quot;:&quot;CG&quot;,&quot;label&quot;:&quot;Congo - Brazzaville&quot;,&quot;__typename&quot;:&quot;Country&quot;},{&quot;value&quot;:&quot;CD&quot;,&quot;label&quot;:&quot;Congo - Kinshasa&quot;,&quot;__typename&quot;:&quot;Country&quot;},{&quot;value&quot;:&quot;CK&quot;,&quot;label&quot;:&quot;Cook Islands&quot;,&quot;__typename&quot;:&quot;Country&quot;},{&quot;value&quot;:&quot;CR&quot;,&quot;label&quot;:&quot;Costa Rica&quot;,&quot;__typename&quot;:&quot;Country&quot;},{&quot;value&quot;:&quot;HR&quot;,&quot;label&quot;:&quot;Croatia&quot;,&quot;__typename&quot;:&quot;Country&quot;},{&quot;value&quot;:&quot;CW&quot;,&quot;label&quot;:&quot;Curaçao&quot;,&quot;__typename&quot;:&quot;Country&quot;},{&quot;value&quot;:&quot;CY&quot;,&quot;label&quot;:&quot;Cyprus&quot;,&quot;__typename&quot;:&quot;Country&quot;},{&quot;value&quot;:&quot;CZ&quot;,&quot;label&quot;:&quot;Czechia&quot;,&quot;__typename&quot;:&quot;Country&quot;},{&quot;value&quot;:&quot;CI&quot;,&quot;label&quot;:&quot;Côte d’Ivoire&quot;,&quot;__typename&quot;:&quot;Country&quot;},{&quot;value&quot;:&quot;DK&quot;,&quot;label&quot;:&quot;Denmark&quot;,&quot;__typename&quot;:&quot;Country&quot;},{&quot;value&quot;:&quot;DJ&quot;,&quot;label&quot;:&quot;Djibouti&quot;,&quot;__typename&quot;:&quot;Country&quot;},{&quot;value&quot;:&quot;DM&quot;,&quot;label&quot;:&quot;Dominica&quot;,&quot;__typename&quot;:&quot;Country&quot;},{&quot;value&quot;:&quot;DO&quot;,&quot;label&quot;:&quot;Dominican Republic&quot;,&quot;__typename&quot;:&quot;Country&quot;},{&quot;value&quot;:&quot;EC&quot;,&quot;label&quot;:&quot;Ecuador&quot;,&quot;__typename&quot;:&quot;Country&quot;},{&quot;value&quot;:&quot;EG&quot;,&quot;label&quot;:&quot;Egypt&quot;,&quot;__typename&quot;:&quot;Country&quot;},{&quot;value&quot;:&quot;SV&quot;,&quot;label&quot;:&quot;El Salvador&quot;,&quot;__typename&quot;:&quot;Country&quot;},{&quot;value&quot;:&quot;GQ&quot;,&quot;label&quot;:&quot;Equatorial Guinea&quot;,&quot;__typename&quot;:&quot;Country&quot;},{&quot;value&quot;:&quot;ER&quot;,&quot;label&quot;:&quot;Eritrea&quot;,&quot;__typename&quot;:&quot;Country&quot;},{&quot;value&quot;:&quot;EE&quot;,&quot;label&quot;:&quot;Estonia&quot;,&quot;__typename&quot;:&quot;Country&quot;},{&quot;value&quot;:&quot;SZ&quot;,&quot;label&quot;:&quot;Eswatini&quot;,&quot;__typename&quot;:&quot;Country&quot;},{&quot;value&quot;:&quot;ET&quot;,&quot;label&quot;:&quot;Ethiopia&quot;,&quot;__typename&quot;:&quot;Country&quot;},{&quot;value&quot;:&quot;FK&quot;,&quot;label&quot;:&quot;Falkland Islands&quot;,&quot;__typename&quot;:&quot;Country&quot;},{&quot;value&quot;:&quot;FO&quot;,&quot;label&quot;:&quot;Faroe Islands&quot;,&quot;__typename&quot;:&quot;Country&quot;},{&quot;value&quot;:&quot;FJ&quot;,&quot;label&quot;:&quot;Fiji&quot;,&quot;__typename&quot;:&quot;Country&quot;},{&quot;value&quot;:&quot;FI&quot;,&quot;label&quot;:&quot;Finland&quot;,&quot;__typename&quot;:&quot;Country&quot;},{&quot;value&quot;:&quot;FR&quot;,&quot;label&quot;:&quot;France&quot;,&quot;__typename&quot;:&quot;Country&quot;},{&quot;value&quot;:&quot;GF&quot;,&quot;label&quot;:&quot;French Guiana&quot;,&quot;__typename&quot;:&quot;Country&quot;},{&quot;value&quot;:&quot;PF&quot;,&quot;label&quot;:&quot;French Polynesia&quot;,&quot;__typename&quot;:&quot;Country&quot;},{&quot;value&quot;:&quot;TF&quot;,&quot;label&quot;:&quot;French Southern Territories&quot;,&quot;__typename&quot;:&quot;Country&quot;},{&quot;value&quot;:&quot;GA&quot;,&quot;label&quot;:&quot;Gabon&quot;,&quot;__typename&quot;:&quot;Country&quot;},{&quot;value&quot;:&quot;GM&quot;,&quot;label&quot;:&quot;Gambia&quot;,&quot;__typename&quot;:&quot;Country&quot;},{&quot;value&quot;:&quot;GE&quot;,&quot;label&quot;:&quot;Georgia&quot;,&quot;__typename&quot;:&quot;Country&quot;},{&quot;value&quot;:&quot;DE&quot;,&quot;label&quot;:&quot;Germany&quot;,&quot;__typename&quot;:&quot;Country&quot;},{&quot;value&quot;:&quot;GH&quot;,&quot;label&quot;:&quot;Ghana&quot;,&quot;__typename&quot;:&quot;Country&quot;},{&quot;value&quot;:&quot;GI&quot;,&quot;label&quot;:&quot;Gibraltar&quot;,&quot;__typename&quot;:&quot;Country&quot;},{&quot;value&quot;:&quot;GR&quot;,&quot;label&quot;:&quot;Greece&quot;,&quot;__typename&quot;:&quot;Country&quot;},{&quot;value&quot;:&quot;GL&quot;,&quot;label&quot;:&quot;Greenland&quot;,&quot;__typename&quot;:&quot;Country&quot;},{&quot;value&quot;:&quot;GD&quot;,&quot;label&quot;:&quot;Grenada&quot;,&quot;__typename&quot;:&quot;Country&quot;},{&quot;value&quot;:&quot;GP&quot;,&quot;label&quot;:&quot;Guadeloupe&quot;,&quot;__typename&quot;:&quot;Country&quot;},{&quot;value&quot;:&quot;GT&quot;,&quot;label&quot;:&quot;Guatemala&quot;,&quot;__typename&quot;:&quot;Country&quot;},{&quot;value&quot;:&quot;GG&quot;,&quot;label&quot;:&quot;Guernsey&quot;,&quot;__typename&quot;:&quot;Country&quot;},{&quot;value&quot;:&quot;GN&quot;,&quot;label&quot;:&quot;Guinea&quot;,&quot;__typename&quot;:&quot;Country&quot;},{&quot;value&quot;:&quot;GW&quot;,&quot;label&quot;:&quot;Guinea-Bissau&quot;,&quot;__typename&quot;:&quot;Country&quot;},{&quot;value&quot;:&quot;GY&quot;,&quot;label&quot;:&quot;Guyana&quot;,&quot;__typename&quot;:&quot;Country&quot;},{&quot;value&quot;:&quot;HT&quot;,&quot;label&quot;:&quot;Haiti&quot;,&quot;__typename&quot;:&quot;Country&quot;},{&quot;value&quot;:&quot;HN&quot;,&quot;label&quot;:&quot;Honduras&quot;,&quot;__typename&quot;:&quot;Country&quot;},{&quot;value&quot;:&quot;HK&quot;,&quot;label&quot;:&quot;Hong Kong SAR&quot;,&quot;__typename&quot;:&quot;Country&quot;},{&quot;value&quot;:&quot;HU&quot;,&quot;label&quot;:&quot;Hungary&quot;,&quot;__typename&quot;:&quot;Country&quot;},{&quot;value&quot;:&quot;IS&quot;,&quot;label&quot;:&quot;Iceland&quot;,&quot;__typename&quot;:&quot;Country&quot;},{&quot;value&quot;:&quot;IN&quot;,&quot;label&quot;:&quot;India&quot;,&quot;__typename&quot;:&quot;Country&quot;},{&quot;value&quot;:&quot;ID&quot;,&quot;label&quot;:&quot;Indonesia&quot;,&quot;__typename&quot;:&quot;Country&quot;},{&quot;value&quot;:&quot;IQ&quot;,&quot;label&quot;:&quot;Iraq&quot;,&quot;__typename&quot;:&quot;Country&quot;},{&quot;value&quot;:&quot;IE&quot;,&quot;label&quot;:&quot;Ireland&quot;,&quot;__typename&quot;:&quot;Country&quot;},{&quot;value&quot;:&quot;IM&quot;,&quot;label&quot;:&quot;Isle of Man&quot;,&quot;__typename&quot;:&quot;Country&quot;},{&quot;value&quot;:&quot;IL&quot;,&quot;label&quot;:&quot;Israel&quot;,&quot;__typename&quot;:&quot;Country&quot;},{&quot;value&quot;:&quot;IT&quot;,&quot;label&quot;:&quot;Italy&quot;,&quot;__typename&quot;:&quot;Country&quot;},{&quot;value&quot;:&quot;JM&quot;,&quot;label&quot;:&quot;Jamaica&quot;,&quot;__typename&quot;:&quot;Country&quot;},{&quot;value&quot;:&quot;JP&quot;,&quot;label&quot;:&quot;Japan&quot;,&quot;__typename&quot;:&quot;Country&quot;},{&quot;value&quot;:&quot;JE&quot;,&quot;label&quot;:&quot;Jersey&quot;,&quot;__typename&quot;:&quot;Country&quot;},{&quot;value&quot;:&quot;JO&quot;,&quot;label&quot;:&quot;Jordan&quot;,&quot;__typename&quot;:&quot;Country&quot;},{&quot;value&quot;:&quot;KZ&quot;,&quot;label&quot;:&quot;Kazakhstan&quot;,&quot;__typename&quot;:&quot;Country&quot;},{&quot;value&quot;:&quot;KE&quot;,&quot;label&quot;:&quot;Kenya&quot;,&quot;__typename&quot;:&quot;Country&quot;},{&quot;value&quot;:&quot;KI&quot;,&quot;label&quot;:&quot;Kiribati&quot;,&quot;__typename&quot;:&quot;Country&quot;},{&quot;value&quot;:&quot;XK&quot;,&quot;label&quot;:&quot;Kosovo&quot;,&quot;__typename&quot;:&quot;Country&quot;},{&quot;value&quot;:&quot;KW&quot;,&quot;label&quot;:&quot;Kuwait&quot;,&quot;__typename&quot;:&quot;Country&quot;},{&quot;value&quot;:&quot;KG&quot;,&quot;label&quot;:&quot;Kyrgyzstan&quot;,&quot;__typename&quot;:&quot;Country&quot;},{&quot;value&quot;:&quot;LA&quot;,&quot;label&quot;:&quot;Laos&quot;,&quot;__typename&quot;:&quot;Country&quot;},{&quot;value&quot;:&quot;LV&quot;,&quot;label&quot;:&quot;Latvia&quot;,&quot;__typename&quot;:&quot;Country&quot;},{&quot;value&quot;:&quot;LB&quot;,&quot;label&quot;:&quot;Lebanon&quot;,&quot;__typename&quot;:&quot;Country&quot;},{&quot;value&quot;:&quot;LS&quot;,&quot;label&quot;:&quot;Lesotho&quot;,&quot;__typename&quot;:&quot;Country&quot;},{&quot;value&quot;:&quot;LR&quot;,&quot;label&quot;:&quot;Liberia&quot;,&quot;__typename&quot;:&quot;Country&quot;},{&quot;value&quot;:&quot;LY&quot;,&quot;label&quot;:&quot;Libya&quot;,&quot;__typename&quot;:&quot;Country&quot;},{&quot;value&quot;:&quot;LI&quot;,&quot;label&quot;:&quot;Liechtenstein&quot;,&quot;__typename&quot;:&quot;Country&quot;},{&quot;value&quot;:&quot;LT&quot;,&quot;label&quot;:&quot;Lithuania&quot;,&quot;__typename&quot;:&quot;Country&quot;},{&quot;value&quot;:&quot;LU&quot;,&quot;label&quot;:&quot;Luxembourg&quot;,&quot;__typename&quot;:&quot;Country&quot;},{&quot;value&quot;:&quot;MO&quot;,&quot;label&quot;:&quot;Macao SAR&quot;,&quot;__typename&quot;:&quot;Country&quot;},{&quot;value&quot;:&quot;MG&quot;,&quot;label&quot;:&quot;Madagascar&quot;,&quot;__typename&quot;:&quot;Country&quot;},{&quot;value&quot;:&quot;MW&quot;,&quot;label&quot;:&quot;Malawi&quot;,&quot;__typename&quot;:&quot;Country&quot;},{&quot;value&quot;:&quot;MY&quot;,&quot;label&quot;:&quot;Malaysia&quot;,&quot;__typename&quot;:&quot;Country&quot;},{&quot;value&quot;:&quot;MV&quot;,&quot;label&quot;:&quot;Maldives&quot;,&quot;__typename&quot;:&quot;Country&quot;},{&quot;value&quot;:&quot;ML&quot;,&quot;label&quot;:&quot;Mali&quot;,&quot;__typename&quot;:&quot;Country&quot;},{&quot;value&quot;:&quot;MT&quot;,&quot;label&quot;:&quot;Malta&quot;,&quot;__typename&quot;:&quot;Country&quot;},{&quot;value&quot;:&quot;MQ&quot;,&quot;label&quot;:&quot;Martinique&quot;,&quot;__typename&quot;:&quot;Country&quot;},{&quot;value&quot;:&quot;MR&quot;,&quot;label&quot;:&quot;Mauritania&quot;,&quot;__typename&quot;:&quot;Country&quot;},{&quot;value&quot;:&quot;MU&quot;,&quot;label&quot;:&quot;Mauritius&quot;,&quot;__typename&quot;:&quot;Country&quot;},{&quot;value&quot;:&quot;YT&quot;,&quot;label&quot;:&quot;Mayotte&quot;,&quot;__typename&quot;:&quot;Country&quot;},{&quot;value&quot;:&quot;MX&quot;,&quot;label&quot;:&quot;Mexico&quot;,&quot;__typename&quot;:&quot;Country&quot;},{&quot;value&quot;:&quot;MD&quot;,&quot;label&quot;:&quot;Moldova&quot;,&quot;__typename&quot;:&quot;Country&quot;},{&quot;value&quot;:&quot;MC&quot;,&quot;label&quot;:&quot;Monaco&quot;,&quot;__typename&quot;:&quot;Country&quot;},{&quot;value&quot;:&quot;MN&quot;,&quot;label&quot;:&quot;Mongolia&quot;,&quot;__typename&quot;:&quot;Country&quot;},{&quot;value&quot;:&quot;ME&quot;,&quot;label&quot;:&quot;Montenegro&quot;,&quot;__typename&quot;:&quot;Country&quot;},{&quot;value&quot;:&quot;MS&quot;,&quot;label&quot;:&quot;Montserrat&quot;,&quot;__typename&quot;:&quot;Country&quot;},{&quot;value&quot;:&quot;MA&quot;,&quot;label&quot;:&quot;Morocco&quot;,&quot;__typename&quot;:&quot;Country&quot;},{&quot;value&quot;:&quot;MZ&quot;,&quot;label&quot;:&quot;Mozambique&quot;,&quot;__typename&quot;:&quot;Country&quot;},{&quot;value&quot;:&quot;MM&quot;,&quot;label&quot;:&quot;Myanmar (Burma)&quot;,&quot;__typename&quot;:&quot;Country&quot;},{&quot;value&quot;:&quot;NA&quot;,&quot;label&quot;:&quot;Namibia&quot;,&quot;__typename&quot;:&quot;Country&quot;},{&quot;value&quot;:&quot;NR&quot;,&quot;label&quot;:&quot;Nauru&quot;,&quot;__typename&quot;:&quot;Country&quot;},{&quot;value&quot;:&quot;NP&quot;,&quot;label&quot;:&quot;Nepal&quot;,&quot;__typename&quot;:&quot;Country&quot;},{&quot;value&quot;:&quot;NL&quot;,&quot;label&quot;:&quot;Netherlands&quot;,&quot;__typename&quot;:&quot;Country&quot;},{&quot;value&quot;:&quot;NC&quot;,&quot;label&quot;:&quot;New Caledonia&quot;,&quot;__typename&quot;:&quot;Country&quot;},{&quot;value&quot;:&quot;NZ&quot;,&quot;label&quot;:&quot;New Zealand&quot;,&quot;__typename&quot;:&quot;Country&quot;},{&quot;value&quot;:&quot;NI&quot;,&quot;label&quot;:&quot;Nicaragua&quot;,&quot;__typename&quot;:&quot;Country&quot;},{&quot;value&quot;:&quot;NE&quot;,&quot;label&quot;:&quot;Niger&quot;,&quot;__typename&quot;:&quot;Country&quot;},{&quot;value&quot;:&quot;NG&quot;,&quot;label&quot;:&quot;Nigeria&quot;,&quot;__typename&quot;:&quot;Country&quot;},{&quot;value&quot;:&quot;NU&quot;,&quot;label&quot;:&quot;Niue&quot;,&quot;__typename&quot;:&quot;Country&quot;},{&quot;value&quot;:&quot;NF&quot;,&quot;label&quot;:&quot;Norfolk Island&quot;,&quot;__typename&quot;:&quot;Country&quot;},{&quot;value&quot;:&quot;MK&quot;,&quot;label&quot;:&quot;North Macedonia&quot;,&quot;__typename&quot;:&quot;Country&quot;},{&quot;value&quot;:&quot;NO&quot;,&quot;label&quot;:&quot;Norway&quot;,&quot;__typename&quot;:&quot;Country&quot;},{&quot;value&quot;:&quot;OM&quot;,&quot;label&quot;:&quot;Oman&quot;,&quot;__typename&quot;:&quot;Country&quot;},{&quot;value&quot;:&quot;PK&quot;,&quot;label&quot;:&quot;Pakistan&quot;,&quot;__typename&quot;:&quot;Country&quot;},{&quot;value&quot;:&quot;PS&quot;,&quot;label&quot;:&quot;Palestinian Territories&quot;,&quot;__typename&quot;:&quot;Country&quot;},{&quot;value&quot;:&quot;PA&quot;,&quot;label&quot;:&quot;Panama&quot;,&quot;__typename&quot;:&quot;Country&quot;},{&quot;value&quot;:&quot;PG&quot;,&quot;label&quot;:&quot;Papua New Guinea&quot;,&quot;__typename&quot;:&quot;Country&quot;},{&quot;value&quot;:&quot;PY&quot;,&quot;label&quot;:&quot;Paraguay&quot;,&quot;__typename&quot;:&quot;Country&quot;},{&quot;value&quot;:&quot;PE&quot;,&quot;label&quot;:&quot;Peru&quot;,&quot;__typename&quot;:&quot;Country&quot;},{&quot;value&quot;:&quot;PH&quot;,&quot;label&quot;:&quot;Philippines&quot;,&quot;__typename&quot;:&quot;Country&quot;},{&quot;value&quot;:&quot;PN&quot;,&quot;label&quot;:&quot;Pitcairn Islands&quot;,&quot;__typename&quot;:&quot;Country&quot;},{&quot;value&quot;:&quot;PL&quot;,&quot;label&quot;:&quot;Poland&quot;,&quot;__typename&quot;:&quot;Country&quot;},{&quot;value&quot;:&quot;PT&quot;,&quot;label&quot;:&quot;Portugal&quot;,&quot;__typename&quot;:&quot;Country&quot;},{&quot;value&quot;:&quot;QA&quot;,&quot;label&quot;:&quot;Qatar&quot;,&quot;__typename&quot;:&quot;Country&quot;},{&quot;value&quot;:&quot;RE&quot;,&quot;label&quot;:&quot;Réunion&quot;,&quot;__typename&quot;:&quot;Country&quot;},{&quot;value&quot;:&quot;RO&quot;,&quot;label&quot;:&quot;Romania&quot;,&quot;__typename&quot;:&quot;Country&quot;},{&quot;value&quot;:&quot;RU&quot;,&quot;label&quot;:&quot;Russia&quot;,&quot;__typename&quot;:&quot;Country&quot;},{&quot;value&quot;:&quot;RW&quot;,&quot;label&quot;:&quot;Rwanda&quot;,&quot;__typename&quot;:&quot;Country&quot;},{&quot;value&quot;:&quot;WS&quot;,&quot;label&quot;:&quot;Samoa&quot;,&quot;__typename&quot;:&quot;Country&quot;},{&quot;value&quot;:&quot;SM&quot;,&quot;label&quot;:&quot;San Marino&quot;,&quot;__typename&quot;:&quot;Country&quot;},{&quot;value&quot;:&quot;ST&quot;,&quot;label&quot;:&quot;São Tomé &amp; Príncipe&quot;,&quot;__typename&quot;:&quot;Country&quot;},{&quot;value&quot;:&quot;SA&quot;,&quot;label&quot;:&quot;Saudi Arabia&quot;,&quot;__typename&quot;:&quot;Country&quot;},{&quot;value&quot;:&quot;SN&quot;,&quot;label&quot;:&quot;Senegal&quot;,&quot;__typename&quot;:&quot;Country&quot;},{&quot;value&quot;:&quot;RS&quot;,&quot;label&quot;:&quot;Serbia&quot;,&quot;__typename&quot;:&quot;Country&quot;},{&quot;value&quot;:&quot;SC&quot;,&quot;label&quot;:&quot;Seychelles&quot;,&quot;__typename&quot;:&quot;Country&quot;},{&quot;value&quot;:&quot;SL&quot;,&quot;label&quot;:&quot;Sierra Leone&quot;,&quot;__typename&quot;:&quot;Country&quot;},{&quot;value&quot;:&quot;SG&quot;,&quot;label&quot;:&quot;Singapore&quot;,&quot;__typename&quot;:&quot;Country&quot;},{&quot;value&quot;:&quot;SX&quot;,&quot;label&quot;:&quot;Sint Maarten&quot;,&quot;__typename&quot;:&quot;Country&quot;},{&quot;value&quot;:&quot;SK&quot;,&quot;label&quot;:&quot;Slovakia&quot;,&quot;__typename&quot;:&quot;Country&quot;},{&quot;value&quot;:&quot;SI&quot;,&quot;label&quot;:&quot;Slovenia&quot;,&quot;__typename&quot;:&quot;Country&quot;},{&quot;value&quot;:&quot;SB&quot;,&quot;label&quot;:&quot;Solomon Islands&quot;,&quot;__typename&quot;:&quot;Country&quot;},{&quot;value&quot;:&quot;SO&quot;,&quot;label&quot;:&quot;Somalia&quot;,&quot;__typename&quot;:&quot;Country&quot;},{&quot;value&quot;:&quot;ZA&quot;,&quot;label&quot;:&quot;South Africa&quot;,&quot;__typename&quot;:&quot;Country&quot;},{&quot;value&quot;:&quot;GS&quot;,&quot;label&quot;:&quot;South Georgia &amp; South Sandwich Islands&quot;,&quot;__typename&quot;:&quot;Country&quot;},{&quot;value&quot;:&quot;KR&quot;,&quot;label&quot;:&quot;South Korea&quot;,&quot;__typename&quot;:&quot;Country&quot;},{&quot;value&quot;:&quot;SS&quot;,&quot;label&quot;:&quot;South Sudan&quot;,&quot;__typename&quot;:&quot;Country&quot;},{&quot;value&quot;:&quot;ES&quot;,&quot;label&quot;:&quot;Spain&quot;,&quot;__typename&quot;:&quot;Country&quot;},{&quot;value&quot;:&quot;LK&quot;,&quot;label&quot;:&quot;Sri Lanka&quot;,&quot;__typename&quot;:&quot;Country&quot;},{&quot;value&quot;:&quot;BL&quot;,&quot;label&quot;:&quot;St. Barthélemy&quot;,&quot;__typename&quot;:&quot;Country&quot;},{&quot;value&quot;:&quot;SH&quot;,&quot;label&quot;:&quot;St. Helena&quot;,&quot;__typename&quot;:&quot;Country&quot;},{&quot;value&quot;:&quot;KN&quot;,&quot;label&quot;:&quot;St. Kitts &amp; Nevis&quot;,&quot;__typename&quot;:&quot;Country&quot;},{&quot;value&quot;:&quot;LC&quot;,&quot;label&quot;:&quot;St. Lucia&quot;,&quot;__typename&quot;:&quot;Country&quot;},{&quot;value&quot;:&quot;MF&quot;,&quot;label&quot;:&quot;St. Martin&quot;,&quot;__typename&quot;:&quot;Country&quot;},{&quot;value&quot;:&quot;PM&quot;,&quot;label&quot;:&quot;St. Pierre &amp; Miquelon&quot;,&quot;__typename&quot;:&quot;Country&quot;},{&quot;value&quot;:&quot;VC&quot;,&quot;label&quot;:&quot;St. Vincent &amp; Grenadines&quot;,&quot;__typename&quot;:&quot;Country&quot;},{&quot;value&quot;:&quot;SD&quot;,&quot;label&quot;:&quot;Sudan&quot;,&quot;__typename&quot;:&quot;Country&quot;},{&quot;value&quot;:&quot;SR&quot;,&quot;label&quot;:&quot;Suriname&quot;,&quot;__typename&quot;:&quot;Country&quot;},{&quot;value&quot;:&quot;SJ&quot;,&quot;label&quot;:&quot;Svalbard &amp; Jan Mayen&quot;,&quot;__typename&quot;:&quot;Country&quot;},{&quot;value&quot;:&quot;SE&quot;,&quot;label&quot;:&quot;Sweden&quot;,&quot;__typename&quot;:&quot;Country&quot;},{&quot;value&quot;:&quot;CH&quot;,&quot;label&quot;:&quot;Switzerland&quot;,&quot;__typename&quot;:&quot;Country&quot;},{&quot;value&quot;:&quot;TW&quot;,&quot;label&quot;:&quot;Taiwan&quot;,&quot;__typename&quot;:&quot;Country&quot;},{&quot;value&quot;:&quot;TJ&quot;,&quot;label&quot;:&quot;Tajikistan&quot;,&quot;__typename&quot;:&quot;Country&quot;},{&quot;value&quot;:&quot;TZ&quot;,&quot;label&quot;:&quot;Tanzania&quot;,&quot;__typename&quot;:&quot;Country&quot;},{&quot;value&quot;:&quot;TH&quot;,&quot;label&quot;:&quot;Thailand&quot;,&quot;__typename&quot;:&quot;Country&quot;},{&quot;value&quot;:&quot;TL&quot;,&quot;label&quot;:&quot;Timor-Leste&quot;,&quot;__typename&quot;:&quot;Country&quot;},{&quot;value&quot;:&quot;TG&quot;,&quot;label&quot;:&quot;Togo&quot;,&quot;__typename&quot;:&quot;Country&quot;},{&quot;value&quot;:&quot;TK&quot;,&quot;label&quot;:&quot;Tokelau&quot;,&quot;__typename&quot;:&quot;Country&quot;},{&quot;value&quot;:&quot;TO&quot;,&quot;label&quot;:&quot;Tonga&quot;,&quot;__typename&quot;:&quot;Country&quot;},{&quot;value&quot;:&quot;TT&quot;,&quot;label&quot;:&quot;Trinidad &amp; Tobago&quot;,&quot;__typename&quot;:&quot;Country&quot;},{&quot;value&quot;:&quot;TA&quot;,&quot;label&quot;:&quot;Tristan da Cunha&quot;,&quot;__typename&quot;:&quot;Country&quot;},{&quot;value&quot;:&quot;TN&quot;,&quot;label&quot;:&quot;Tunisia&quot;,&quot;__typename&quot;:&quot;Country&quot;},{&quot;value&quot;:&quot;TR&quot;,&quot;label&quot;:&quot;Türkiye&quot;,&quot;__typename&quot;:&quot;Country&quot;},{&quot;value&quot;:&quot;TM&quot;,&quot;label&quot;:&quot;Turkmenistan&quot;,&quot;__typename&quot;:&quot;Country&quot;},{&quot;value&quot;:&quot;TC&quot;,&quot;label&quot;:&quot;Turks &amp; Caicos Islands&quot;,&quot;__typename&quot;:&quot;Country&quot;},{&quot;value&quot;:&quot;TV&quot;,&quot;label&quot;:&quot;Tuvalu&quot;,&quot;__typename&quot;:&quot;Country&quot;},{&quot;value&quot;:&quot;UM&quot;,&quot;label&quot;:&quot;U.S. Outlying Islands&quot;,&quot;__typename&quot;:&quot;Country&quot;},{&quot;value&quot;:&quot;UG&quot;,&quot;label&quot;:&quot;Uganda&quot;,&quot;__typename&quot;:&quot;Country&quot;},{&quot;value&quot;:&quot;UA&quot;,&quot;label&quot;:&quot;Ukraine&quot;,&quot;__typename&quot;:&quot;Country&quot;},{&quot;value&quot;:&quot;AE&quot;,&quot;label&quot;:&quot;United Arab Emirates&quot;,&quot;__typename&quot;:&quot;Country&quot;},{&quot;value&quot;:&quot;GB&quot;,&quot;label&quot;:&quot;United Kingdom&quot;,&quot;__typename&quot;:&quot;Country&quot;},{&quot;value&quot;:&quot;US&quot;,&quot;label&quot;:&quot;United States&quot;,&quot;__typename&quot;:&quot;Country&quot;},{&quot;value&quot;:&quot;UY&quot;,&quot;label&quot;:&quot;Uruguay&quot;,&quot;__typename&quot;:&quot;Country&quot;},{&quot;value&quot;:&quot;UZ&quot;,&quot;label&quot;:&quot;Uzbekistan&quot;,&quot;__typename&quot;:&quot;Country&quot;},{&quot;value&quot;:&quot;VU&quot;,&quot;label&quot;:&quot;Vanuatu&quot;,&quot;__typename&quot;:&quot;Country&quot;},{&quot;value&quot;:&quot;VA&quot;,&quot;label&quot;:&quot;Vatican City&quot;,&quot;__typename&quot;:&quot;Country&quot;},{&quot;value&quot;:&quot;VE&quot;,&quot;label&quot;:&quot;Venezuela&quot;,&quot;__typename&quot;:&quot;Country&quot;},{&quot;value&quot;:&quot;VN&quot;,&quot;label&quot;:&quot;Vietnam&quot;,&quot;__typename&quot;:&quot;Country&quot;},{&quot;value&quot;:&quot;WF&quot;,&quot;label&quot;:&quot;Wallis &amp; Futuna&quot;,&quot;__typename&quot;:&quot;Country&quot;},{&quot;value&quot;:&quot;EH&quot;,&quot;label&quot;:&quot;Western Sahara&quot;,&quot;__typename&quot;:&quot;Country&quot;},{&quot;value&quot;:&quot;YE&quot;,&quot;label&quot;:&quot;Yemen&quot;,&quot;__typename&quot;:&quot;Country&quot;},{&quot;value&quot;:&quot;ZM&quot;,&quot;label&quot;:&quot;Zambia&quot;,&quot;__typename&quot;:&quot;Country&quot;},{&quot;value&quot;:&quot;ZW&quot;,&quot;label&quot;:&quot;Zimbabwe&quot;,&quot;__typename&quot;:&quot;Country&quot;}],&quot;popularBillingCountries&quot;:[],&quot;popularShippingCountries&quot;:[],&quot;storefront&quot;:{&quot;url&quot;:&quot;https://example.myshopify.com&quot;,&quot;hasStorefront&quot;:true,&quot;__typename&quot;:&quot;CheckoutStorefrontConfig&quot;},&quot;theme&quot;:{&quot;id&quot;:&quot;24232&quot;,&quot;cityhash&quot;:&quot;3731655000859924227&quot;,&quot;__typename&quot;:&quot;ThemeConfig&quot;},&quot;trackingPixels&quot;:[],&quot;onlineStoreChat&quot;:null,&quot;facebookCapiEnabled&quot;:false,&quot;myshopifyDomain&quot;:&quot;example.myshopify.com&quot;,&quot;translations&quot;:&quot;{}&quot;,&quot;customerAccountRequirement&quot;:&quot;OPTIONAL&quot;,&quot;emailMarketing&quot;:&quot;CHECKED&quot;,&quot;smsMarketing&quot;:&quot;OFF&quot;,&quot;shippingRatesReloadStrategy&quot;:{&quot;US&quot;:{&quot;AL&quot;:3,&quot;AK&quot;:3,&quot;AZ&quot;:3,&quot;AR&quot;:3,&quot;CA&quot;:3,&quot;CO&quot;:3,&quot;CT&quot;:3,&quot;DE&quot;:3,&quot;DC&quot;:3,&quot;FL&quot;:3,&quot;GA&quot;:3,&quot;HI&quot;:3,&quot;ID&quot;:3,&quot;IL&quot;:3,&quot;IN&quot;:3,&quot;IA&quot;:3,&quot;KS&quot;:3,&quot;KY&quot;:3,&quot;LA&quot;:3,&quot;ME&quot;:3,&quot;MD&quot;:3,&quot;MA&quot;:3,&quot;MI&quot;:3,&quot;MN&quot;:3,&quot;MS&quot;:3,&quot;MO&quot;:3,&quot;MT&quot;:3,&quot;NE&quot;:3,&quot;NV&quot;:3,&quot;NH&quot;:3,&quot;NJ&quot;:3,&quot;NM&quot;:3,&quot;NY&quot;:3,&quot;NC&quot;:3,&quot;ND&quot;:3,&quot;OH&quot;:3,&quot;OK&quot;:3,&quot;OR&quot;:3,&quot;PA&quot;:3,&quot;RI&quot;:3,&quot;SC&quot;:3,&quot;SD&quot;:3,&quot;TN&quot;:3,&quot;TX&quot;:3,&quot;UT&quot;:3,&quot;VT&quot;:3,&quot;VA&quot;:3,&quot;WA&quot;:3,&quot;WV&quot;:3,&quot;WI&quot;:3,&quot;WY&quot;:3,&quot;AS&quot;:3,&quot;AA&quot;:3,&quot;AE&quot;:3,&quot;AP&quot;:3,&quot;FM&quot;:3,&quot;GU&quot;:3,&quot;MH&quot;:3,&quot;MP&quot;:3,&quot;PW&quot;:3,&quot;PR&quot;:3,&quot;VI&quot;:3}},&quot;billingAddressFormSettings&quot;:{&quot;address2&quot;:{&quot;mode&quot;:&quot;OPTIONAL&quot;,&quot;__typename&quot;:&quot;AddressFormField&quot;},&quot;company&quot;:{&quot;mode&quot;:&quot;OPTIONAL&quot;,&quot;__typename&quot;:&quot;AddressFormField&quot;},&quot;firstName&quot;:{&quot;mode&quot;:&quot;OPTIONAL&quot;,&quot;__typename&quot;:&quot;AddressFormField&quot;},&quot;phone&quot;:{&quot;mode&quot;:&quot;OPTIONAL&quot;,&quot;__typename&quot;:&quot;AddressFormField&quot;},&quot;addressAutocompletion&quot;:true,&quot;__typename&quot;:&quot;BillingAddressFormSettings&quot;},&quot;shopConfigurations&quot;:{&quot;defaultConfiguration&quot;:{&quot;contactInfoOptions&quot;:[&quot;EMAIL&quot;],&quot;addressFormSettings&quot;:{&quot;address2&quot;:{&quot;mode&quot;:&quot;OPTIONAL&quot;,&quot;__typename&quot;:&quot;AddressFormField&quot;},&quot;company&quot;:{&quot;mode&quot;:&quot;OPTIONAL&quot;,&quot;__typename&quot;:&quot;AddressFormField&quot;},&quot;firstName&quot;:{&quot;mode&quot;:&quot;OPTIONAL&quot;,&quot;__typename&quot;:&quot;AddressFormField&quot;},&quot;phone&quot;:{&quot;mode&quot;:&quot;OPTIONAL&quot;,&quot;__typename&quot;:&quot;AddressFormField&quot;},&quot;addressAutocompletion&quot;:true,&quot;addressValidation&quot;:true,&quot;__typename&quot;:&quot;AddressFormSettings&quot;},&quot;__typename&quot;:&quot;CountryConfiguration&quot;},&quot;countrySpecificConfigurations&quot;:[{&quot;countries&quot;:[&quot;US&quot;],&quot;configuration&quot;:{&quot;contactInfoOptions&quot;:[&quot;EMAIL&quot;],&quot;addressFormSettings&quot;:{&quot;address2&quot;:{&quot;mode&quot;:&quot;OPTIONAL&quot;,&quot;__typename&quot;:&quot;AddressFormField&quot;},&quot;company&quot;:{&quot;mode&quot;:&quot;OPTIONAL&quot;,&quot;__typename&quot;:&quot;AddressFormField&quot;},&quot;firstName&quot;:{&quot;mode&quot;:&quot;OPTIONAL&quot;,&quot;__typename&quot;:&quot;AddressFormField&quot;},&quot;phone&quot;:{&quot;mode&quot;:&quot;OPTIONAL&quot;,&quot;__typename&quot;:&quot;AddressFormField&quot;},&quot;addressAutocompletion&quot;:true,&quot;__typename&quot;:&quot;AddressFormSettings&quot;},&quot;__typename&quot;:&quot;CountryConfiguration&quot;},&quot;__typename&quot;:&quot;CountrySpecificConfiguration&quot;}],&quot;__typename&quot;:&quot;ShopConfigurations&quot;},&quot;currencyCode&quot;:&quot;USD&quot;,&quot;timeZone&quot;:&quot;America/New_York&quot;,&quot;enabledFlags&quot;:[&quot;8b17e08a&quot;,&quot;58dc8563&quot;,&quot;f0df213a&quot;,&quot;c2051049&quot;,&quot;c3c16cec&quot;,&quot;d11ec0f1&quot;,&quot;13b0fbe6&quot;,&quot;3c166f16&quot;,&quot;722b5467&quot;,&quot;102daeab&quot;,&quot;a006ef7d&quot;,&quot;52cd51b6&quot;,&quot;21c5a305&quot;,&quot;225b63f2&quot;,&quot;d2aec27a&quot;,&quot;072c91d4&quot;,&quot;3560349c&quot;,&quot;2dca8a86&quot;,&quot;ac843a20&quot;,&quot;6b6a465a&quot;,&quot;379cb9b4&quot;,&quot;8943c43f&quot;,&quot;ed15cb24&quot;,&quot;adcfa927&quot;,&quot;1117bd16&quot;,&quot;2b334f17&quot;,&quot;64c046aa&quot;,&quot;661adccf&quot;,&quot;66cfb9c0&quot;,&quot;660205cd&quot;,&quot;f00223c0&quot;,&quot;ef4b8ac3&quot;,&quot;9c3a6787&quot;,&quot;391c7c14&quot;,&quot;422c24c7&quot;,&quot;360fdd98&quot;,&quot;e61dcd68&quot;,&quot;624e1c90&quot;,&quot;e20ab1ac&quot;,&quot;bf1ee67a&quot;,&quot;cb20d750&quot;],&quot;enabledDeliveryMethods&quot;:[&quot;SHIPPING&quot;],&quot;giftCardsEnabled&quot;:false,&quot;discountCodesEnabled&quot;:false,&quot;contactEmail&quot;:&quot;no-email@shopify.com&quot;,&quot;acceptTipPayments&quot;:false,&quot;showTipPayments&quot;:true,&quot;postPurchaseExtensionAvailable&quot;:false,&quot;postPurchaseDevelopmentModeAvailable&quot;:true,&quot;postPurchaseAdditionalTrackingScript&quot;:null,&quot;confirmationPageEnabled&quot;:false,&quot;customerAccountLocationsUrl&quot;:&quot;https://shopify.com/2442/account/locations?return_to=https%3A%2F%2Fexample.myshopify.com%2Fcheckouts%2Fcn%2FhWN58P5vnP5f3mFNyIRk9QBu%2Fen-us%3F_r%3DAQABqjIc39Hwtua9FfBpjPwDhOdYU35Bi-Fp3JcFyyD5%26cart_link_id%3DjllaeLKt&quot;,&quot;loginLinkVisible&quot;:false,&quot;shopPayEnabled&quot;:false,&quot;storeVaultEnabled&quot;:false,&quot;storeVaultCvvVerificationAtGuestCheckoutEnabled&quot;:false,&quot;returnWindow&quot;:null,&quot;webPixelConfigurations&quot;:[{&quot;idTmp&quot;:&quot;shopify-app-pixel&quot;,&quot;configuration&quot;:&quot;{}&quot;,&quot;eventPayloadVersion&quot;:&quot;v1&quot;,&quot;runtimeContext&quot;:&quot;STRICT&quot;,&quot;scriptVersion&quot;:&quot;0450&quot;,&quot;type&quot;:&quot;APP&quot;,&quot;apiClientId&quot;:&quot;shopify-pixel&quot;,&quot;purposes&quot;:[&quot;ANALYTICS&quot;,&quot;MARKETING&quot;],&quot;name&quot;:null,&quot;capabilities&quot;:null,&quot;dataSharingAdjustments&quot;:null,&quot;integrityHash&quot;:null,&quot;__typename&quot;:&quot;WebPixelConfiguration&quot;},{&quot;idTmp&quot;:&quot;shopify-custom-pixel&quot;,&quot;configuration&quot;:null,&quot;eventPayloadVersion&quot;:&quot;v1&quot;,&quot;runtimeContext&quot;:&quot;LAX&quot;,&quot;scriptVersion&quot;:&quot;0450&quot;,&quot;type&quot;:&quot;CUSTOM&quot;,&quot;apiClientId&quot;:&quot;shopify-pixel&quot;,&quot;purposes&quot;:[&quot;ANALYTICS&quot;,&quot;MARKETING&quot;],&quot;name&quot;:null,&quot;capabilities&quot;:null,&quot;dataSharingAdjustments&quot;:null,&quot;integrityHash&quot;:null,&quot;__typename&quot;:&quot;WebPixelConfiguration&quot;}],&quot;webPixelManagerVersion&quot;:&quot;ae1676cfwd2530674p4253c800m34e853cb&quot;,&quot;webPixelsManagerSriMap&quot;:{&quot;legacy&quot;:&quot;sha384-GKH1g/VZNdYQQ/BSkmQlemhDig6TilU8S7N+mgw8DSjiW4iKsFEfd03L3RwZXFdV&quot;,&quot;modern&quot;:&quot;sha384-M54uBB6AbK5OvEmUBb8w52MgO0W044zXrWx41bH/iFmRed7X1vUjFtud1Jneq2zf&quot;,&quot;__typename&quot;:&quot;WebPixelsManagerSriMap&quot;},&quot;trekkieLoadConfiguration&quot;:{&quot;assetPath&quot;:&quot;s/trekkie.storefront.308893168db1679b4a9f8a086857af995740364f.min.js&quot;,&quot;sriHash&quot;:&quot;sha384-IwRVl88uf25VwHgp7bhvNgi6MElWo4pep+Xd0f7d4mWYUS0x8ARlCBYUMpPxjZwS&quot;,&quot;__typename&quot;:&quot;TrekkieLoadConfiguration&quot;},&quot;linkToArriveApp&quot;:true,&quot;shopPayRememberMeAutoOptinEnabled&quot;:true,&quot;sameBillingAndShippingAddress&quot;:true,&quot;requireMatchingShippingAndBilling&quot;:false,&quot;prefetchShippingRatesEnabled&quot;:true,&quot;captureAtFulfillmentEnabled&quot;:false,&quot;developmentShop&quot;:true,&quot;customerAccountDomain&quot;:&quot;shopify.com&quot;,&quot;checkoutPublicAccessToken&quot;:&quot;NGZlZmMzZjdlZTA5MzFmYTQ4ZDE0ZTJiM2JlNmMzMWI6\n&quot;,&quot;asyncDeliveryPromiseExperienceEnabled&quot;:false,&quot;paymentGateways&quot;:[],&quot;adsPublisherSettingsTypEnabled&quot;:false,&quot;draftAdsPublisherSettingsTypEnabled&quot;:false,&quot;sandboxUrlAutocomplete&quot;:&quot;https://checkout.shopify.com/2442/sandboxes/autocomplete?hmac=d8aa82cb6bddf2d938d48760a61456b37cffa8555c0123fe96e70836b71b2c2d&quot;,&quot;sandboxUrlAnalytics&quot;:&quot;https://checkout.shopify.com/2442/sandboxes/analytics?hmac=3339aebb82ec957db49e9eca7379356b2b2deb8811aa76ecb08cca3005cd0a9a&quot;,&quot;sandboxAppBridgeCheckoutCore&quot;:&quot;https://checkout.shopify.com/2442/sandboxes/app-bridge-checkout-core?hmac=452b506f4971e8a7a43a1e2bc5e73de45f2ee302545b353cb28002fb6b439870&quot;,&quot;sandboxCrypto&quot;:&quot;https://checkout.shopify.com/2442/sandboxes/crypto?shopHost=example.myshopify.com&amp;hmac=3218ec03d554a7a88400c091037e7bce62bb98fafc0e126c9657ade26d1689d4&quot;,&quot;sandboxPaypal&quot;:&quot;https://checkout.shopify.com/2442/sandboxes/wallets?shopHost=example.myshopify.com&amp;wallet=PAYPAL_EXPRESS&amp;hmac=757a1a21c0f87a7e4d001030546ea6229fa4a7b4347fe6a3f760b2aeaf75ed36&quot;,&quot;sandboxPayWithPaypal&quot;:&quot;https://checkout.shopify.com/2442/sandboxes/wallets?shopHost=example.myshopify.com&amp;wallet=PAY_WITH_PAYPAL&amp;hmac=008b9f60dc64ef94341deb735afadf4f4f1aed22592ad179434b26bd248fc92b&quot;,&quot;sandboxVenmo&quot;:&quot;https://checkout.shopify.com/2442/sandboxes/wallets?shopHost=example.myshopify.com&amp;wallet=VENMO&amp;hmac=5f1ad85d6b9e2ef426168b049ed6ac55b79578f18fad96db7a29924eddb9edc1&quot;,&quot;sandboxGooglePay&quot;:&quot;https://checkout.shopify.com/2442/sandboxes/wallets?shopHost=example.myshopify.com&amp;wallet=GOOGLE_PAY&amp;hmac=351ab8bc362c7729610af1070caccc932888db33e2579e89af2a1b7c69325dd9&quot;,&quot;sandboxAmazonPay&quot;:&quot;https://checkout.shopify.com/2442/sandboxes/wallets?shopHost=example.myshopify.com&amp;wallet=amazon_pay&amp;hmac=9f759c10a20981e5bfc602deb39054ee7d4cfab9ebbb5362455e7aee9248f829&quot;,&quot;sandboxBuyWithPrime&quot;:&quot;https://checkout.shopify.com/2442/sandboxes/wallets?shopHost=example.myshopify.com&amp;wallet=buy_with_prime&amp;hmac=ef21bc121038549fab91b3494610c69f9bb433ce1784d0fed52e217f9fe5d154&quot;,&quot;sandboxStripeBank&quot;:&quot;https://checkout.shopify.com/2442/sandboxes/wallets?shopHost=example.myshopify.com&amp;wallet=STRIPE_BANK&amp;hmac=df9d031d1e9fa510328c4db4c7111e9253dae36eb2d773ac6d2e9d969bd82f1d&quot;,&quot;brandSettings&quot;:null,&quot;__typename&quot;:&quot;CheckoutShopConfig&quot;},&quot;checkoutProfile&quot;:{&quot;id&quot;:&quot;gid://shopify/CheckoutProfile/577470521&quot;,&quot;activatedExtensions&quot;:[],&quot;__typename&quot;:&quot;CheckoutProfile&quot;},&quot;globalCheckoutUiExtensions&quot;:[],&quot;appConfiguration&quot;:{&quot;features&quot;:{&quot;isExpressCheckoutEnabled&quot;:true,&quot;isEmailMarketingEnabled&quot;:true,&quot;isSmsMarketingEnabled&quot;:true,&quot;isTipsEnabled&quot;:true,&quot;__typename&quot;:&quot;AppFeatureConfiguration&quot;},&quot;__typename&quot;:&quot;AppConfiguration&quot;},&quot;cardsinkUrl&quot;:&quot;https://checkout.pci.shopifyinc.com/sessions&quot;,&quot;extensionsAssetsPath&quot;:&quot;https://extensions.shopifycdn.com/shopifycloud/checkout-web/assets/&quot;,&quot;payNowAction&quot;:&quot;NEGOTIATION&quot;},&quot;051b5712f487b87ddcf5597b5949038278403c3e531932cd10e744dde9a3790c{\&quot;checkpointData\&quot;:null,\&quot;queueToken\&quot;:null}&quot;:{&quot;session&quot;:{&quot;context&quot;:{&quot;session&quot;:[],&quot;policies&quot;:{&quot;fees&quot;:[],&quot;payment&quot;:[],&quot;buyerIdentity&quot;:[],&quot;tax&quot;:[],&quot;duty&quot;:[],&quot;landedCostDetails&quot;:[],&quot;discount&quot;:[],&quot;merchandise&quot;:[],&quot;tip&quot;:[],&quot;delivery&quot;:[],&quot;__typename&quot;:&quot;PolicyFactSet&quot;},&quot;__typename&quot;:&quot;NegotiationContext&quot;},&quot;sessionType&quot;:&quot;CART_API&quot;,&quot;sourceId&quot;:&quot;hWN58P5vnP5f3mFNyIRk9QBu&quot;,&quot;sourceVersion&quot;:null,&quot;checkoutSessionIdentifier&quot;:&quot;a43fb3f45ab275ae35b5bd4648b57dbc&quot;,&quot;checkoutCardsinkCallerIdentificationSignature&quot;:&quot;eyJraWQiOiJ2MSIsImFsZyI6IkhTMjU2In0.eyJjbGllbnRfaWQiOiIyIiwiY2xpZW50X2FjY291bnRfaWQiOiIyNDQyIiwidW5pcXVlX2lkIjoiYTQzZmIzZjQ1YWIyNzVhZTM1YjViZDQ2NDhiNTdkYmMiLCJpYXQiOjE3NjI3ODcxOTV9.CUkOk2NgAi0XSgfDRVEfQgN1MrhcjcH4Yzz3OA4fb50&quot;,&quot;storefrontAnalyticsStartedOrderEventId&quot;:null,&quot;cartReturnUrl&quot;:&quot;https://example.myshopify.com/cart&quot;,&quot;headerLogoUrl&quot;:&quot;https://example.myshopify.com&quot;,&quot;previewScript&quot;:null,&quot;negotiate&quot;:{&quot;result&quot;:{&quot;checkpointData&quot;:null,&quot;queueToken&quot;:&quot;A4LXRJpAePDjsyIICz5HcLwIFCALjUFiICJfnxCGHNJuul9selHo-eD3svscPvIrur0toV5omOuoXcMntSbi31Fd3eJfm5QMUFX8wucp2AsDXo5npw==&quot;,&quot;buyerProposal&quot;:{&quot;buyerIdentity&quot;:{&quot;email&quot;:null,&quot;phone&quot;:null,&quot;customer&quot;:{&quot;__typename&quot;:&quot;GuestProfile&quot;},&quot;__typename&quot;:&quot;FilledBuyerIdentityTerms&quot;},&quot;cartMetafields&quot;:[],&quot;merchandiseDiscount&quot;:{&quot;__typename&quot;:&quot;FilledDiscountTerms&quot;,&quot;acceptUnexpectedDiscounts&quot;:true,&quot;lines&quot;:[]},&quot;deliveryDiscount&quot;:{&quot;__typename&quot;:&quot;FilledDiscountTerms&quot;,&quot;acceptUnexpectedDiscounts&quot;:true,&quot;lines&quot;:[]},&quot;delivery&quot;:{&quot;__typename&quot;:&quot;FilledDeliveryTerms&quot;,&quot;intermediateRates&quot;:false,&quot;progressiveRatesEstimatedTimeUntilCompletion&quot;:0,&quot;shippingRatesStatusToken&quot;:&quot;&quot;,&quot;splitShippingToggle&quot;:false,&quot;deliveryLines&quot;:[]},&quot;merchandise&quot;:{&quot;taxesIncluded&quot;:false,&quot;bwpItems&quot;:false,&quot;merchandiseLines&quot;:[{&quot;stableId&quot;:&quot;a2660d78-fb81-4713-8490-af192076bfad&quot;,&quot;finalSale&quot;:false,&quot;merchandise&quot;:{&quot;__typename&quot;:&quot;ProductVariantMerchandise&quot;,&quot;id&quot;:&quot;gid://shopify/ProductVariantMerchandise/5475&quot;,&quot;digest&quot;:&quot;9cfa9f50fccee16327ebb42f2ac3ce73&quot;,&quot;variantId&quot;:&quot;gid://shopify/ProductVariant/5475&quot;,&quot;title&quot;:&quot;Shopify T-Shirt&quot;,&quot;untranslatedTitle&quot;:&quot;Shopify T-Shirt&quot;,&quot;subtitle&quot;:&quot;Medium&quot;,&quot;untranslatedSubtitle&quot;:&quot;Medium&quot;,&quot;product&quot;:{&quot;id&quot;:&quot;gid://shopify/Product/4450&quot;,&quot;vendor&quot;:&quot;Shopify&quot;,&quot;productType&quot;:&quot;Shirts&quot;,&quot;__typename&quot;:&quot;Product&quot;},&quot;productUrl&quot;:&quot;/products/shopify-t-shirt&quot;,&quot;image&quot;:{&quot;altText&quot;:null,&quot;url&quot;:&quot;https://cdn.shopify.com/s/files/1/0000/2442/products/shopify_shirt.png?v=1155241139&quot;,&quot;one&quot;:&quot;https://cdn.shopify.com/s/files/1/0000/2442/products/shopify_shirt_64x64.png?v=1155241139&quot;,&quot;two&quot;:&quot;https://cdn.shopify.com/s/files/1/0000/2442/products/shopify_shirt_128x128.png?v=1155241139&quot;,&quot;four&quot;:&quot;https://cdn.shopify.com/s/files/1/0000/2442/products/shopify_shirt_256x256.png?v=1155241139&quot;,&quot;__typename&quot;:&quot;Image&quot;},&quot;properties&quot;:[],&quot;requiresShipping&quot;:true,&quot;options&quot;:[{&quot;name&quot;:&quot;Title&quot;,&quot;value&quot;:&quot;Medium&quot;,&quot;__typename&quot;:&quot;ProductVariantOption&quot;}],&quot;sellingPlan&quot;:null,&quot;giftCard&quot;:false},&quot;parentRelationship&quot;:null,&quot;quantity&quot;:{&quot;items&quot;:{&quot;value&quot;:1,&quot;__typename&quot;:&quot;IntValueConstraint&quot;},&quot;__typename&quot;:&quot;ProposalMerchandiseQuantityByItem&quot;},&quot;totalAmount&quot;:{&quot;value&quot;:{&quot;amount&quot;:&quot;19.0&quot;,&quot;currencyCode&quot;:&quot;USD&quot;,&quot;__typename&quot;:&quot;Money&quot;},&quot;__typename&quot;:&quot;MoneyValueConstraint&quot;},&quot;recurringTotal&quot;:null,&quot;lineAllocations&quot;:[{&quot;stableId&quot;:&quot;e08e1d8916da6ea9fb3289ff93b4dac6&quot;,&quot;quantity&quot;:1,&quot;totalAmountBeforeReductions&quot;:{&quot;amount&quot;:&quot;19.0&quot;,&quot;currencyCode&quot;:&quot;USD&quot;,&quot;__typename&quot;:&quot;Money&quot;},&quot;totalAmountAfterDiscounts&quot;:{&quot;amount&quot;:&quot;19.0&quot;,&quot;currencyCode&quot;:&quot;USD&quot;,&quot;__typename&quot;:&quot;Money&quot;},&quot;totalAmountAfterLineDiscounts&quot;:{&quot;amount&quot;:&quot;19.0&quot;,&quot;currencyCode&quot;:&quot;USD&quot;,&quot;__typename&quot;:&quot;Money&quot;},&quot;checkoutPriceAfterDiscounts&quot;:{&quot;amount&quot;:&quot;19.0&quot;,&quot;currencyCode&quot;:&quot;USD&quot;,&quot;__typename&quot;:&quot;Money&quot;},&quot;checkoutPriceAfterLineDiscounts&quot;:{&quot;amount&quot;:&quot;19.0&quot;,&quot;currencyCode&quot;:&quot;USD&quot;,&quot;__typename&quot;:&quot;Money&quot;},&quot;checkoutPriceBeforeReductions&quot;:{&quot;amount&quot;:&quot;19.0&quot;,&quot;currencyCode&quot;:&quot;USD&quot;,&quot;__typename&quot;:&quot;Money&quot;},&quot;unitPrice&quot;:null,&quot;allocations&quot;:[],&quot;__typename&quot;:&quot;LineAllocation&quot;}],&quot;lineComponentsSource&quot;:null,&quot;lineComponents&quot;:[],&quot;legacyFee&quot;:false,&quot;__typename&quot;:&quot;MerchandiseLine&quot;}],&quot;__typename&quot;:&quot;FilledMerchandiseTerms&quot;},&quot;runningTotal&quot;:{&quot;value&quot;:{&quot;amount&quot;:&quot;19.0&quot;,&quot;currencyCode&quot;:&quot;USD&quot;,&quot;__typename&quot;:&quot;Money&quot;},&quot;__typename&quot;:&quot;MoneyValueConstraint&quot;},&quot;total&quot;:{&quot;__typename&quot;:&quot;AnyConstraint&quot;},&quot;checkoutTotalBeforeTaxesAndShipping&quot;:null,&quot;checkoutTotalTaxes&quot;:null,&quot;checkoutTotal&quot;:{&quot;__typename&quot;:&quot;AnyConstraint&quot;},&quot;deferredTotal&quot;:null,&quot;hasOnlyDeferredShipping&quot;:false,&quot;subtotalBeforeTaxesAndShipping&quot;:{&quot;value&quot;:{&quot;amount&quot;:&quot;19.0&quot;,&quot;currencyCode&quot;:&quot;USD&quot;,&quot;__typename&quot;:&quot;Money&quot;},&quot;__typename&quot;:&quot;MoneyValueConstraint&quot;},&quot;legacySubtotalBeforeTaxesShippingAndFees&quot;:{&quot;value&quot;:{&quot;amount&quot;:&quot;19.0&quot;,&quot;currencyCode&quot;:&quot;USD&quot;,&quot;__typename&quot;:&quot;Money&quot;},&quot;__typename&quot;:&quot;MoneyValueConstraint&quot;},&quot;legacyAggregatedMerchandiseTermsAsFees&quot;:[],&quot;attribution&quot;:{&quot;attributions&quot;:[],&quot;__typename&quot;:&quot;Attribution&quot;},&quot;saleAttributions&quot;:{&quot;attributions&quot;:[],&quot;__typename&quot;:&quot;SaleAttributions&quot;},&quot;nonNegotiableTerms&quot;:null,&quot;remote&quot;:null,&quot;__typename&quot;:&quot;Proposal&quot;},&quot;sellerProposal&quot;:{&quot;merchandiseDiscount&quot;:{&quot;__typename&quot;:&quot;FilledDiscountTerms&quot;,&quot;acceptUnexpectedDiscounts&quot;:true,&quot;lines&quot;:[]},&quot;cartMetafields&quot;:[],&quot;deliveryDiscount&quot;:{&quot;__typename&quot;:&quot;FilledDiscountTerms&quot;,&quot;acceptUnexpectedDiscounts&quot;:true,&quot;lines&quot;:[]},&quot;deliveryExpectations&quot;:{&quot;__typename&quot;:&quot;UnavailableTerms&quot;},&quot;memberships&quot;:{&quot;__typename&quot;:&quot;FilledMembershipTerms&quot;,&quot;memberships&quot;:[]},&quot;availableRedeemables&quot;:{&quot;availableRedeemables&quot;:[],&quot;__typename&quot;:&quot;AvailableRedeemables&quot;},&quot;shopCashBalance&quot;:{&quot;__typename&quot;:&quot;UnavailableTerms&quot;,&quot;_singleInstance&quot;:true},&quot;shopPromotion&quot;:{&quot;__typename&quot;:&quot;UnavailableTerms&quot;,&quot;_singleInstance&quot;:true},&quot;shopDiscountOffer&quot;:{&quot;__typename&quot;:&quot;UnavailableTerms&quot;,&quot;_singleInstance&quot;:true},&quot;availableDeliveryAddresses&quot;:[],&quot;mustSelectProvidedAddress&quot;:false,&quot;mustSelectProvidedShippingRate&quot;:false,&quot;canUpdateDiscountCodes&quot;:true,&quot;canUpdateDeliveryAddress&quot;:true,&quot;canUpdateMerchandise&quot;:true,&quot;delivery&quot;:{&quot;__typename&quot;:&quot;UnavailableTerms&quot;},&quot;payment&quot;:{&quot;availablePaymentLines&quot;:[{&quot;placements&quot;:[&quot;PAYMENT_METHOD&quot;],&quot;paymentMethod&quot;:{&quot;__typename&quot;:&quot;AnyStripeSharedTokenPaymentMethod&quot;},&quot;__typename&quot;:&quot;AvailablePaymentLine&quot;}],&quot;paymentLines&quot;:[],&quot;billingAddress&quot;:null,&quot;paymentFlexibilityPaymentTermsTemplate&quot;:null,&quot;depositConfiguration&quot;:null,&quot;__typename&quot;:&quot;FilledPaymentTerms&quot;},&quot;poNumber&quot;:null,&quot;merchandise&quot;:{&quot;taxesIncluded&quot;:false,&quot;bwpItems&quot;:false,&quot;merchandiseLines&quot;:[{&quot;stableId&quot;:&quot;a2660d78-fb81-4713-8490-af192076bfad&quot;,&quot;finalSale&quot;:false,&quot;merchandise&quot;:{&quot;__typename&quot;:&quot;ContextualizedProductVariantMerchandise&quot;,&quot;id&quot;:&quot;gid://shopify/ProductVariantMerchandise/5475&quot;,&quot;digest&quot;:&quot;9cfa9f50fccee16327ebb42f2ac3ce73&quot;,&quot;variantId&quot;:&quot;gid://shopify/ProductVariant/5475&quot;,&quot;title&quot;:&quot;Shopify T-Shirt&quot;,&quot;untranslatedTitle&quot;:&quot;Shopify T-Shirt&quot;,&quot;subtitle&quot;:&quot;Medium&quot;,&quot;untranslatedSubtitle&quot;:&quot;Medium&quot;,&quot;sku&quot;:&quot;&quot;,&quot;price&quot;:{&quot;amount&quot;:&quot;19.0&quot;,&quot;currencyCode&quot;:&quot;USD&quot;,&quot;__typename&quot;:&quot;Money&quot;},&quot;product&quot;:{&quot;id&quot;:&quot;gid://shopify/Product/4450&quot;,&quot;vendor&quot;:&quot;Shopify&quot;,&quot;productType&quot;:&quot;Shirts&quot;,&quot;__typename&quot;:&quot;Product&quot;},&quot;productUrl&quot;:&quot;/products/shopify-t-shirt&quot;,&quot;image&quot;:{&quot;altText&quot;:null,&quot;url&quot;:&quot;https://cdn.shopify.com/s/files/1/0000/2442/products/shopify_shirt.png?v=1155241139&quot;,&quot;one&quot;:&quot;https://cdn.shopify.com/s/files/1/0000/2442/products/shopify_shirt_64x64.png?v=1155241139&quot;,&quot;two&quot;:&quot;https://cdn.shopify.com/s/files/1/0000/2442/products/shopify_shirt_128x128.png?v=1155241139&quot;,&quot;four&quot;:&quot;https://cdn.shopify.com/s/files/1/0000/2442/products/shopify_shirt_256x256.png?v=1155241139&quot;,&quot;__typename&quot;:&quot;Image&quot;},&quot;properties&quot;:[],&quot;requiresShipping&quot;:true,&quot;options&quot;:[{&quot;name&quot;:&quot;Title&quot;,&quot;value&quot;:&quot;Medium&quot;,&quot;__typename&quot;:&quot;ProductVariantOption&quot;}],&quot;sellingPlan&quot;:null,&quot;giftCard&quot;:false,&quot;deferredAmount&quot;:{&quot;amount&quot;:&quot;0.0&quot;,&quot;currencyCode&quot;:&quot;USD&quot;,&quot;__typename&quot;:&quot;Money&quot;}},&quot;quantity&quot;:{&quot;items&quot;:{&quot;value&quot;:0,&quot;__typename&quot;:&quot;IntValueConstraint&quot;},&quot;__typename&quot;:&quot;ProposalMerchandiseQuantityByItem&quot;},&quot;totalAmount&quot;:{&quot;value&quot;:{&quot;amount&quot;:&quot;0.0&quot;,&quot;currencyCode&quot;:&quot;USD&quot;,&quot;__typename&quot;:&quot;Money&quot;},&quot;__typename&quot;:&quot;MoneyValueConstraint&quot;},&quot;recurringTotal&quot;:null,&quot;lineAllocations&quot;:[{&quot;stableId&quot;:&quot;e08e1d8916da6ea9fb3289ff93b4dac6&quot;,&quot;quantity&quot;:0,&quot;totalAmountBeforeReductions&quot;:{&quot;amount&quot;:&quot;0.0&quot;,&quot;currencyCode&quot;:&quot;USD&quot;,&quot;__typename&quot;:&quot;Money&quot;},&quot;totalAmountAfterDiscounts&quot;:{&quot;amount&quot;:&quot;0.0&quot;,&quot;currencyCode&quot;:&quot;USD&quot;,&quot;__typename&quot;:&quot;Money&quot;},&quot;totalAmountAfterLineDiscounts&quot;:{&quot;amount&quot;:&quot;0.0&quot;,&quot;currencyCode&quot;:&quot;USD&quot;,&quot;__typename&quot;:&quot;Money&quot;},&quot;checkoutPriceAfterDiscounts&quot;:{&quot;amount&quot;:&quot;0.0&quot;,&quot;currencyCode&quot;:&quot;USD&quot;,&quot;__typename&quot;:&quot;Money&quot;},&quot;checkoutPriceAfterLineDiscounts&quot;:{&quot;amount&quot;:&quot;0.0&quot;,&quot;currencyCode&quot;:&quot;USD&quot;,&quot;__typename&quot;:&quot;Money&quot;},&quot;checkoutPriceBeforeReductions&quot;:{&quot;amount&quot;:&quot;0.0&quot;,&quot;currencyCode&quot;:&quot;USD&quot;,&quot;__typename&quot;:&quot;Money&quot;},&quot;unitPrice&quot;:null,&quot;allocations&quot;:[],&quot;__typename&quot;:&quot;LineAllocation&quot;}],&quot;lineComponentsSource&quot;:null,&quot;lineComponents&quot;:[],&quot;parentRelationship&quot;:null,&quot;legacyFee&quot;:false,&quot;__typename&quot;:&quot;MerchandiseLine&quot;}],&quot;__typename&quot;:&quot;FilledMerchandiseTerms&quot;},&quot;note&quot;:{&quot;customAttributes&quot;:[],&quot;message&quot;:&quot;&quot;,&quot;__typename&quot;:&quot;Note&quot;},&quot;scriptFingerprint&quot;:{&quot;signature&quot;:null,&quot;signatureUuid&quot;:null,&quot;lineItemScriptChanges&quot;:[],&quot;paymentScriptChanges&quot;:[],&quot;shippingScriptChanges&quot;:[],&quot;__typename&quot;:&quot;ScriptFingerprint&quot;},&quot;transformerFingerprintV2&quot;:null,&quot;buyerIdentity&quot;:{&quot;shopUser&quot;:null,&quot;customer&quot;:{&quot;presentmentCurrency&quot;:&quot;USD&quot;,&quot;countryCode&quot;:&quot;US&quot;,&quot;market&quot;:{&quot;id&quot;:&quot;gid://shopify/Market/528318521&quot;,&quot;handle&quot;:&quot;us&quot;,&quot;__typename&quot;:&quot;Market&quot;},&quot;shippingAddresses&quot;:[],&quot;__typename&quot;:&quot;GuestProfile&quot;},&quot;purchasingCompany&quot;:null,&quot;phone&quot;:null,&quot;email&quot;:null,&quot;marketingConsent&quot;:[],&quot;shopPayOptInPhone&quot;:null,&quot;rememberMe&quot;:false,&quot;__typename&quot;:&quot;FilledBuyerIdentityTerms&quot;},&quot;checkoutCompletionTarget&quot;:&quot;ORDER&quot;,&quot;recurringTotals&quot;:[],&quot;subtotalBeforeTaxesAndShipping&quot;:{&quot;value&quot;:{&quot;amount&quot;:&quot;0.0&quot;,&quot;currencyCode&quot;:&quot;USD&quot;,&quot;__typename&quot;:&quot;Money&quot;},&quot;__typename&quot;:&quot;MoneyValueConstraint&quot;},&quot;legacySubtotalBeforeTaxesShippingAndFees&quot;:{&quot;value&quot;:{&quot;amount&quot;:&quot;0.0&quot;,&quot;currencyCode&quot;:&quot;USD&quot;,&quot;__typename&quot;:&quot;Money&quot;},&quot;__typename&quot;:&quot;MoneyValueConstraint&quot;},&quot;legacyAggregatedMerchandiseTermsAsFees&quot;:[],&quot;legacyRepresentProductsAsFees&quot;:false,&quot;totalSavings&quot;:{&quot;value&quot;:{&quot;amount&quot;:&quot;0.0&quot;,&quot;currencyCode&quot;:&quot;USD&quot;,&quot;__typename&quot;:&quot;Money&quot;},&quot;__typename&quot;:&quot;MoneyValueConstraint&quot;},&quot;runningTotal&quot;:{&quot;value&quot;:{&quot;amount&quot;:&quot;0.0&quot;,&quot;currencyCode&quot;:&quot;USD&quot;,&quot;__typename&quot;:&quot;Money&quot;},&quot;__typename&quot;:&quot;MoneyValueConstraint&quot;},&quot;total&quot;:{&quot;__typename&quot;:&quot;AnyConstraint&quot;},&quot;checkoutTotalBeforeTaxesAndShipping&quot;:null,&quot;checkoutTotalTaxes&quot;:null,&quot;checkoutTotal&quot;:{&quot;__typename&quot;:&quot;AnyConstraint&quot;},&quot;deferredTotal&quot;:null,&quot;hasOnlyDeferredShipping&quot;:false,&quot;subtotalBeforeReductions&quot;:{&quot;value&quot;:{&quot;amount&quot;:&quot;0.0&quot;,&quot;currencyCode&quot;:&quot;USD&quot;,&quot;__typename&quot;:&quot;Money&quot;},&quot;__typename&quot;:&quot;MoneyValueConstraint&quot;},&quot;subtotalAfterMerchandiseDiscounts&quot;:{&quot;value&quot;:{&quot;amount&quot;:&quot;0.0&quot;,&quot;currencyCode&quot;:&quot;USD&quot;,&quot;__typename&quot;:&quot;Money&quot;},&quot;__typename&quot;:&quot;MoneyValueConstraint&quot;},&quot;duty&quot;:{&quot;totalDutyAmount&quot;:null,&quot;totalTaxAndDutyAmount&quot;:{&quot;value&quot;:{&quot;amount&quot;:&quot;0.0&quot;,&quot;currencyCode&quot;:&quot;USD&quot;,&quot;__typename&quot;:&quot;Money&quot;},&quot;__typename&quot;:&quot;MoneyValueConstraint&quot;},&quot;totalAdditionalFeesAmount&quot;:null,&quot;__typename&quot;:&quot;FilledDutyTerms&quot;},&quot;tax&quot;:{&quot;totalTaxAmount&quot;:{&quot;value&quot;:{&quot;amount&quot;:&quot;0.0&quot;,&quot;currencyCode&quot;:&quot;USD&quot;,&quot;__typename&quot;:&quot;Money&quot;},&quot;__typename&quot;:&quot;MoneyValueConstraint&quot;},&quot;totalTaxAmountRange&quot;:null,&quot;totalTaxAndDutyAmount&quot;:{&quot;value&quot;:{&quot;amount&quot;:&quot;0.0&quot;,&quot;currencyCode&quot;:&quot;USD&quot;,&quot;__typename&quot;:&quot;Money&quot;},&quot;__typename&quot;:&quot;MoneyValueConstraint&quot;},&quot;totalAmountIncludedInTarget&quot;:null,&quot;exemptions&quot;:[],&quot;__typename&quot;:&quot;FilledTaxTerms&quot;},&quot;tip&quot;:{&quot;tipSuggestions&quot;:[{&quot;__typename&quot;:&quot;TipSuggestion&quot;,&quot;percentage&quot;:0.15,&quot;amount&quot;:{&quot;value&quot;:{&quot;amount&quot;:&quot;0.0&quot;,&quot;currencyCode&quot;:&quot;USD&quot;,&quot;__typename&quot;:&quot;Money&quot;},&quot;__typename&quot;:&quot;MoneyValueConstraint&quot;}},{&quot;__typename&quot;:&quot;TipSuggestion&quot;,&quot;percentage&quot;:0.18,&quot;amount&quot;:{&quot;value&quot;:{&quot;amount&quot;:&quot;0.0&quot;,&quot;currencyCode&quot;:&quot;USD&quot;,&quot;__typename&quot;:&quot;Money&quot;},&quot;__typename&quot;:&quot;MoneyValueConstraint&quot;}},{&quot;__typename&quot;:&quot;TipSuggestion&quot;,&quot;percentage&quot;:0.2,&quot;amount&quot;:{&quot;value&quot;:{&quot;amount&quot;:&quot;0.0&quot;,&quot;currencyCode&quot;:&quot;USD&quot;,&quot;__typename&quot;:&quot;Money&quot;},&quot;__typename&quot;:&quot;MoneyValueConstraint&quot;}},{&quot;__typename&quot;:&quot;TipSuggestion&quot;,&quot;percentage&quot;:0,&quot;amount&quot;:{&quot;value&quot;:{&quot;amount&quot;:&quot;0.0&quot;,&quot;currencyCode&quot;:&quot;USD&quot;,&quot;__typename&quot;:&quot;Money&quot;},&quot;__typename&quot;:&quot;MoneyValueConstraint&quot;}}],&quot;terms&quot;:{&quot;tipLines&quot;:[],&quot;__typename&quot;:&quot;FilledTipTerms&quot;},&quot;__typename&quot;:&quot;TipWrapper&quot;},&quot;localizationExtension&quot;:{&quot;fields&quot;:[],&quot;__typename&quot;:&quot;LocalizationExtension&quot;},&quot;landedCostDetails&quot;:{&quot;incotermInformation&quot;:null,&quot;__typename&quot;:&quot;LandedCostDetails&quot;},&quot;dutiesIncluded&quot;:false,&quot;nonNegotiableTerms&quot;:null,&quot;optionalDuties&quot;:{&quot;buyerRefusesDuties&quot;:false,&quot;refuseDutiesPermitted&quot;:false,&quot;__typename&quot;:&quot;OptionalDuties&quot;},&quot;attribution&quot;:{&quot;attributions&quot;:[],&quot;__typename&quot;:&quot;Attribution&quot;},&quot;saleAttributions&quot;:{&quot;attributions&quot;:[],&quot;__typename&quot;:&quot;SaleAttributions&quot;},&quot;managedByMarketsPro&quot;:false,&quot;captcha&quot;:null,&quot;cartCheckoutValidation&quot;:null,&quot;alternativePaymentCurrency&quot;:null,&quot;isShippingRequired&quot;:true,&quot;remote&quot;:null,&quot;__typename&quot;:&quot;Proposal&quot;},&quot;__typename&quot;:&quot;NegotiationResultAvailable&quot;},&quot;errors&quot;:[{&quot;code&quot;:&quot;BUYER_IDENTITY_MISSING_CONTACT_METHOD&quot;,&quot;localizedMessage&quot;:&quot;Missing a valid contact method.&quot;,&quot;nonLocalizedMessage&quot;:&quot;Missing a valid contact method.&quot;,&quot;localizedMessageHtml&quot;:&quot;Missing a valid contact method.&quot;,&quot;target&quot;:&quot;$.buyerIdentity&quot;,&quot;__typename&quot;:&quot;UnprocessableTermViolation&quot;},{&quot;code&quot;:&quot;MERCHANDISE_OUT_OF_STOCK&quot;,&quot;localizedMessage&quot;:&quot;Sold out&quot;,&quot;nonLocalizedMessage&quot;:&quot;This item is out of stock.&quot;,&quot;localizedMessageHtml&quot;:&quot;Sold out&quot;,&quot;target&quot;:&quot;$.merchandise.merchandiseLines[0]&quot;,&quot;__typename&quot;:&quot;RemoveTermViolation&quot;},{&quot;code&quot;:&quot;TAX_NEW_TAX_MUST_BE_ACCEPTED&quot;,&quot;localizedMessage&quot;:&quot;Taxes associated to your order have changed. Review and try again.&quot;,&quot;nonLocalizedMessage&quot;:&quot;A new tax line in the seller proposal must be accepted in order to continue.&quot;,&quot;localizedMessageHtml&quot;:&quot;Taxes associated to your order have changed. Review and try again.&quot;,&quot;target&quot;:&quot;$&quot;,&quot;__typename&quot;:&quot;AcceptNewTermViolation&quot;},{&quot;code&quot;:&quot;PAYMENTS_UNACCEPTABLE_PAYMENT_AMOUNT&quot;,&quot;localizedMessage&quot;:&quot;Your order total has changed. Review and try again.&quot;,&quot;nonLocalizedMessage&quot;:&quot;The sum of proposed payments cannot cover the total amount to be paid.&quot;,&quot;localizedMessageHtml&quot;:&quot;Your order total has changed. Review and try again.&quot;,&quot;target&quot;:&quot;$.payment&quot;,&quot;__typename&quot;:&quot;UnprocessableTermViolation&quot;},{&quot;code&quot;:&quot;REQUIRED_ARTIFACTS_UNAVAILABLE&quot;,&quot;localizedMessage&quot;:&quot;&quot;,&quot;nonLocalizedMessage&quot;:&quot;Required artifacts are unavailable.&quot;,&quot;localizedMessageHtml&quot;:null,&quot;__typename&quot;:&quot;RequiredArtifactsUnavailableViolation&quot;}],&quot;__typename&quot;:&quot;NegotiationResultPayload&quot;},&quot;__typename&quot;:&quot;Session&quot;}}}"/><meta name="serialized-graphql-endpoint" content="&quot;https://example.myshopify.com/checkouts/unstable/graphql&quot;"/><meta name="serialized-shop-pay-config" content="{&quot;authorization&quot;:null,&quot;pre_select_installments&quot;:false,&quot;redirect_source&quot;:null,&quot;is_referral&quot;:false,&quot;universal_redirect_indicator&quot;:false,&quot;universal_redirect_enabled&quot;:false,&quot;callback_token&quot;:&quot;eyJhbGciOiJIUzI1NiJ9.eyJpc3MiOiJnaWQ6XC9cL3Nob3BpZnlcL1Nob3BcLzI0NDIiLCJuYmYiOjE3NjI3ODcxOTUsInNlc3Npb25fdG9rZW4iOiJBQUVCbGlJbzZ6OFRwQ0U0RzZFUVpUSkhhQ1lvYTdiZS1tcDdUWHRUNGU4TTVJd3J4a0V6cmNleS15VGh4T2hKUkV5RWdYSVRWUGF6aUZocnlYTmtzYmNVbGNlRUpUbW5IOVlGYXN1ZG13enZfRnBoNFp2Mm44SlFhdW1FUmJuc3JsdXpBdUloOXhCSzVxb2MzZ2hNcnVSbmhNbjhSc1Q5TE5lbFN1d24yaEhOZWpUT2pqZWtVazJzckNIUW54dG55X21KcFVZdHlfdEVQMmFzSGMyaEVhQ2tNZm1kblFOQSIsImV4cCI6MTc2MjgwODc5NSwibGFuZGluZ19wYWdlIjoiXC9jYXJ0XC81NDc1OjEifQ.c8rg7L_Qc8qi5v6tUcAX5W926k3JUUKItbYzYN3ilsE&quot;,&quot;checkout_as_guest_url&quot;:&quot;https://example.myshopify.com/checkouts/cn/hWN58P5vnP5f3mFNyIRk9QBu/en-us?_r=AQABB0r1VsaIauWjUainkAbDmWIjFo7yyKjkx-6A9F1Q&amp;skip_shop_pay=true&quot;,&quot;from_classic&quot;:false,&quot;iframe_token&quot;:&quot;RzMxcU1QV1JyLy90R1ZFZmVQNXlubU4rMXcvVUNHRTJqemNrZHFPMDNqckk2WHZ5RWcyd1lEdGZVOWl2QXBkSS0tODI2Y1IwZ09pbFIycjRnNTlMTS9WQT09--9a9feb3c0dc28791f9832308f3c6529419acd793&quot;,&quot;redirect_url&quot;:&quot;TFdYcmpiK3ZOQ2JnT0lOYndtTDlnMTVmN2Q3R0R4MFg5eGlTTWQrUTZXU1p1UE5jLzhxS3NzUUR4V0JUMGQ2aE43S1AyeitFTGRqQ0dyYWd4RnNHZDFrNmVBMTJwV21GeERUR2t2elE3ZmZDeEdsWEVDNVhuZWpJcEUzUHRmSTl6R2ExV3BURHlUTkg2N3h3MXRORXpudGhUUkxVcmJlSUQ0ZXdzVDVnNm02dkVIbitqSTFZN1FuT0pYOXh4L3I4dU8zaTdVWUdQalZWTnJmVFhVb3BaUnpLS2pLalFHaGxTcHBucVg3S0ttZkhoR1VlWVJDd202VHJYL3Judjhyb1FwVTVIU3lrYktiR0h5R3VabGlZQmRaM2tjbVdFdU1iQ29lSTlYNUkyU2pGNGhvZm9GMW1qRStxdXBLQTU3UnNHS1MvZlZ6aFBtazVjL0J6bWUzSGkvSC96RVFhRzhHNU5BZVhVNWl5WjdWM2FnV0drSjdQcHJhMG9OckxreWQ5S0R4YVRraU1aNEZjd1VEeXBYM0ZaL0dtRzFnTnJHRXlIMFVtdE9ubGo0c28xOTVMQkJORWplQzZmMlE3SHlJTm1aOUJrUEFvNnBkaGFZVFI2UHFQVW0yLzlzdTd0NFh2WmRaYU1KemkwMUlGajJNbFdJR0ovSGRuOEE1SStDY3N1dmlqRmJLb1FQdXFNbEFZUUpXejB2L1U1TlhSclZVU1BnWGZxcXQ0VlJrcmd1ZEFsOGhSWU5hVkdrREV6V0V6ak9TKzFrUUxYaG5EOEx3OWpnUDFIcnIvWkp1UWNVSlB1d1BZNFZIVFpFVFlqZ05ha0x6K0QreHF6WURkMU1GUXZ6UXQ0MVgva0pja3BaRTc0SEJsbzdPMDJvZEc4bUlWRHVTaFFPRjZlM2dKSGRvT1dZMmhpVERNc0hNRmZ2ZXVTYTlOU1hkbGF4MzlkamZHQkJDUDFPTGphci9xTTZzdHFnK08zY3lTbXhJZzRvRnpzMXo3TXRpdEY3bGVBWTlDbXg3NmhHaHZjT2w0eVpNcEVkNDFWWjJFMWh6SmhqWTMrN0RydS92MmlMMkxVRmxxQzBUbCtYREw1QldUTW95V1RYOUV4Uy9xamsrd3haNDVxVStTV09XTnI5YXlrckR6SDRnWVhHZzdlMmRJV2xONUZISUVaRVQwQUkyay85enZSYTF0WmpnY2NaajdMbG1ka1lRR2JlUlFBWWwzdWs2QzJiUzNCaFlzbGUrMHNnQ2plK3JmQzU5MC8vbG1lR1hjWi9vNHJDa1NlbDdkU2lLeXZENm9FcldzSnRpa2MzOGprVGpLZVduclplVT0tLXpjUEV4Y1lvcDQ2WFRwbjY3R2ZJdXc9PQ==--c21c7fd9e8adb99ecb1c7f291354e7677bf25432&quot;,&quot;tracking_unique&quot;:&quot;e3989244-ebd6-40f8-af55-8460f326c30a&quot;,&quot;tracking_visit&quot;:&quot;1e81b0d9-72cb-4324-a64c-5e7f94fdaf30&quot;,&quot;tracking_consent&quot;:&quot;3.AMPS&quot;,&quot;transaction_params&quot;:&quot;encrypted_params=aHJyRGpjbnJySDlDOHc5RzZzMVNMZzFsTDhQOU1SRmZxdGk3L3U5aHQ1b3JmSlBnQUFJNTFSd3ZIeDdhaU53dlR3M2dyeDE4L3ByZlZrVU9YdHJZM0E9PS0tZ2NzRmREdEJ3Ym4vNlZmV0twSFhXUT09--21ecafdbb52a322294cfba408af94c39625b95dd&quot;,&quot;web_url&quot;:&quot;https://example.myshopify.com/checkouts/cn/hWN58P5vnP5f3mFNyIRk9QBu/en-us?_r=AQABB0r1VsaIauWjUainkAbDmWIjFo7yyKjkx-6A9F1Q&amp;skip_shop_pay=true&quot;,&quot;checkout_profile_context&quot;:null,&quot;profile_preview_token&quot;:null}"/><meta name="serialized-client-bundle-info" content="{&quot;browsers&quot;:&quot;baseline&quot;,&quot;format&quot;:&quot;system&quot;,&quot;base&quot;:&quot;/cdn/shopifycloud/checkout-web/assets/&quot;,&quot;cdnBase&quot;:&quot;https://cdn.shopify.com/cdn/shopifycloud/checkout-web/assets/&quot;,&quot;locale&quot;:&quot;en&quot;,&quot;extensionsBase&quot;:&quot;https://extensions.shopifycdn.com/shopifycloud/checkout-web/assets/&quot;}"/><meta name="serialized-receipt" content="{&quot;id&quot;:null,&quot;exists&quot;:false,&quot;inProgress&quot;:false,&quot;orderStatusPageUrl&quot;:null,&quot;shopPay&quot;:false,&quot;processingErrorFailure&quot;:null,&quot;purchaseOrder&quot;:null,&quot;latestReceipt&quot;:{&quot;__typename&quot;:&quot;ReceiptNotFound&quot;}}"/><meta name="serialized-request-id" content="&quot;99c6745eabf3f7a9&quot;"/><meta name="serialized-server-handling" content="&quot;fast&quot;"/><meta name="serialized-server-render" content="&quot;no&quot;"/><meta name="serialized-worker-version" content="&quot;fast&quot;"/><meta name="serialized-session-finished" content="false"/><meta name="serialized-api-client-id" content="580111"/><meta name="serialized-redesign-enabled" content="true"/><meta name="serialized-shop" content="{&quot;id&quot;:&quot;gid://shopify/Shop/2442&quot;,&quot;name&quot;:&quot;example&quot;,&quot;domain&quot;:&quot;example.myshopify.com&quot;,&quot;myshopifyDomain&quot;:&quot;example.myshopify.com&quot;,&quot;origins&quot;:[&quot;https://example.myshopify.com&quot;,&quot;https://example.account.myshopify.com&quot;],&quot;enabledFlags&quot;:[&quot;918f49c8&quot;,&quot;7e9901c5&quot;]}"/><meta name="serialized-login-url" content="&quot;https://example.myshopify.com/account/login?checkout_url=%2Fcheckouts%2Fcn%2FhWN58P5vnP5f3mFNyIRk9QBu%2Fen-us%3F_r%3DAQABqjIc39Hwtua9FfBpjPwDhOdYU35Bi-Fp3JcFyyD5%26cart_link_id%3DjllaeLKt%26locale%3Den-US&quot;"/><meta name="serialized-logout-url" content="&quot;https://example.myshopify.com/account/logout?return_url=%2Fcheckouts%2Fcn%2FhWN58P5vnP5f3mFNyIRk9QBu%2Fen-us%3F_r%3DAQABqjIc39Hwtua9FfBpjPwDhOdYU35Bi-Fp3JcFyyD5%26cart_link_id%3DjllaeLKt%26locale%3Den-US&quot;"/><meta name="serialized-invoice-login-type" content="null"/><meta name="serialized-experiments" content="[{&quot;clientHandle&quot;:&quot;e_438e7fe7d4b9b5ef88f72d72f20eab12&quot;,&quot;variant&quot;:null},{&quot;clientHandle&quot;:&quot;e_e5eef1f760ed55e19c6defbc6ce215af&quot;,&quot;variant&quot;:null},{&quot;clientHandle&quot;:&quot;e_a7634604e418665685ce888d0e7b148c&quot;,&quot;variant&quot;:null},{&quot;clientHandle&quot;:&quot;e_3649cd8839e98272448d131a367710c1&quot;,&quot;variant&quot;:null},{&quot;clientHandle&quot;:&quot;e_cee1818c5dc80a8fb895f03ef76e1d78&quot;,&quot;variant&quot;:null},{&quot;clientHandle&quot;:&quot;e_4b677d9631ac019c71abc14d3be79ecd&quot;,&quot;variant&quot;:null},{&quot;clientHandle&quot;:&quot;e_000f402b6aeaa97ebef9bf44d6615a9b&quot;,&quot;variant&quot;:null}]"/><meta name="serialized-renderer" content="&quot;cloudflare&quot;"/><meta name="serialized-environment" content="{&quot;commitSha&quot;:&quot;0884be4227ff8dbfcf970d9bb3d13c0aae19b379&quot;,&quot;debug&quot;:0,&quot;deployStage&quot;:&quot;production&quot;,&quot;services&quot;:{&quot;core&quot;:{&quot;type&quot;:&quot;production&quot;,&quot;url&quot;:&quot;https://app.shopify.com&quot;},&quot;checkout&quot;:{&quot;type&quot;:&quot;production&quot;,&quot;url&quot;:&quot;https://checkout.shopify.com&quot;},&quot;hostedFields&quot;:{&quot;type&quot;:&quot;production&quot;,&quot;url&quot;:&quot;https://checkout.pci.shopifyinc.com/build/739af4d/card_fields.js&quot;},&quot;shopServer&quot;:{&quot;type&quot;:&quot;production&quot;,&quot;url&quot;:&quot;https://shop.app&quot;},&quot;serverShopApp&quot;:{&quot;type&quot;:&quot;production&quot;,&quot;url&quot;:&quot;https://server.shop.app&quot;},&quot;payShopifyCom&quot;:{&quot;type&quot;:&quot;production&quot;,&quot;url&quot;:&quot;https://pay.shopify.com&quot;},&quot;admin&quot;:{&quot;type&quot;:&quot;production&quot;,&quot;url&quot;:&quot;https://admin.shopify.com&quot;},&quot;shopJS&quot;:{&quot;type&quot;:&quot;production&quot;,&quot;url&quot;:&quot;/cdn/shopifycloud/shop-js&quot;},&quot;webPixelsManager&quot;:{&quot;type&quot;:&quot;production&quot;,&quot;url&quot;:&quot;/cdn/wpm&quot;},&quot;webPixelsManagerExtensions&quot;:{&quot;type&quot;:&quot;production&quot;,&quot;url&quot;:&quot;https://extensions.shopifycdn.com&quot;},&quot;trekkie&quot;:{&quot;type&quot;:&quot;production&quot;,&quot;url&quot;:&quot;/cdn&quot;},&quot;portableWallets&quot;:{&quot;type&quot;:&quot;production&quot;,&quot;url&quot;:&quot;/cdn&quot;},&quot;atlas&quot;:{&quot;type&quot;:&quot;production&quot;,&quot;url&quot;:&quot;https://atlas.shopifysvc.com&quot;}}}"/><div id="app"></div><style>
  .client-terminal-error-page {
    position: relative;
    display: flex;
    flex-direction: row;
    align-items: center;
    min-height: 100vh;
    margin: 0;
    padding: 12rem;

    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica,
      Arial, sans-serif, 'Apple Color Emoji', 'Segoe UI Emoji', 'Segoe UI Symbol';
    font-size: 1.4rem;
    font-weight: 400;
    line-height: 1.3;
    color: hsl(0, 0%, 33%);
    background: hsl(0, 0%, 100%);
  }

  @media screen and (max-width: 500px) {
    .client-terminal-error-page {
      padding: 2rem;
    }
  }

  .client-terminal-error-page h1 {
    font-size: 2.8rem;
    color: hsl(0, 0%, 30%);
  }

  .client-terminal-error-page p {
    font-size: 1.4rem;
    margin: 1.3rem 0;
  }

  .client-terminal-error-page a {
    display: inline-block;
    padding: 1.2rem 2.5rem;
    border: 1px solid hsl(0, 0%, 49%);
    border-radius: 6px;
    margin: 1.2rem 0;

    font-size: 1.5rem;
    color: hsl(0, 0%, 39%);
    text-decoration: none;
    transition: border-color 0.2s ease-in;
  }

  .client-terminal-error-page a:hover {
    color: hsl(0, 0%, 20%);
    border-color: hsl(0, 0%, 20%);
  }

  .client-terminal-error-page__text--subdued {
    font-size: 1rem;
  }
</style><div id="terminal-error-page" style="display:none;" class="client-terminal-error-page"><h1>There was a problem with our checkout</h1><p>Refresh this page or try again in a few minutes</p><p><a href="javascript:window.location.reload()" class="client-terminal-error-page__cta">Refresh Page</a></p><div class="client-terminal-error-page__stack-trace"></div><p class="client-terminal-error-page__text--subdued">Request ID: 99c6745eabf3f7a9</p></div><script>
  (function () {
    var location = new URL(window.location);

    ["skip_fade_in","amazonCheckoutSessionId","promiseId","amazon_cancelled"].forEach(
      function (paramName) {
        location.searchParams.delete(paramName);
      }
    );

    window.history.replaceState(null, document.title, location);
  })();
</script><script>
  Object.defineProperty(window, Symbol.for('Shopify.checkout.htmlAvailable'), {
    value: true,
    writable: true,
    configurable: true,
    enumerable: false,
  });
  document.dispatchEvent(new Event('checkout:htmlavailable'));
</script></body></html>